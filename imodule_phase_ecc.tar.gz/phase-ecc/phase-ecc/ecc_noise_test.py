#!/usr/bin/env python3
"""
CW4: So sanh ECC vs Plain duoi tan cong nhieu.
Chung minh ECC giup giai ma dung hon khi co nhieu.
"""
import numpy as np
import scipy.io.wavfile as wavfile
import csv
import os
import sys

sys.path.insert(0, '.')
import encoder_lib
from hamming_ecc import encode_message_hamming, decode_message_hamming

os.makedirs("results", exist_ok=True)
os.makedirs("output", exist_ok=True)

input_file = "input/audio_original.wav"
message = "SECRET"
num_chars = len(message)

print("=" * 65)
print("[*] CW4: SO SANH ECC vs PLAIN DUOI TAN CONG NHIEU")
print("=" * 65)

# BUOC 1: Tao stego plain (khong ECC)
res_plain = encoder_lib.encode(input_file, message, seg_len=4096, start_bin=1500)
plain_file = "output/stego_plain.wav"
encoder_lib.save_wav(res_plain["output"], res_plain["fs"], plain_file, res_plain["orig_dtype"])

# BUOC 2: Tao stego ECC
ecc_bits = encode_message_hamming(message)
n_ecc_chars = int(np.ceil(len(ecc_bits) / 8))
padded = np.pad(ecc_bits, (0, n_ecc_chars*8 - len(ecc_bits)))
ecc_bytes = np.packbits(padded)
ecc_fake_msg = bytes(ecc_bytes).decode('latin-1')

res_ecc = encoder_lib.encode(input_file, ecc_fake_msg, seg_len=4096, start_bin=1500)
ecc_file = "output/stego_ecc_test.wav"
encoder_lib.save_wav(res_ecc["output"], res_ecc["fs"], ecc_file, res_ecc["orig_dtype"])

# BUOC 3: Doc lai du lieu goc cua 2 file stego
sr_plain, data_plain = wavfile.read(plain_file)
sr_ecc, data_ecc = wavfile.read(ecc_file)

sigma_list = [50, 100, 200, 500, 1000, 2000, 5000]

print(f"\n{'Sigma':<8} {'Plain OK':<12} {'ECC OK':<10} {'ECC Fixed'}")
print("-" * 45)

with open("results/ecc_noise.csv", "w", newline='') as f:
    writer = csv.writer(f)
    writer.writerow(["sigma", "plain_ok", "ecc_ok", "ecc_corrections"])

    for sigma in sigma_list:
        temp = "output/temp_noise_test.wav"

        # Test PLAIN
        noise = np.random.normal(0, sigma, data_plain.shape)
        attacked = np.clip(data_plain + noise, -32768, 32767).astype(np.int16)
        wavfile.write(temp, sr_plain, attacked)
        dec_p = encoder_lib.decode(temp, num_chars, seg_len=4096, start_bin=1500)
        plain_ok = (dec_p.get("decoded", "") == message)

        # Test ECC
        noise_e = np.random.normal(0, sigma, data_ecc.shape)
        attacked_e = np.clip(data_ecc + noise_e, -32768, 32767).astype(np.int16)
        wavfile.write(temp, sr_ecc, attacked_e)
        dec_e = encoder_lib.decode(temp, n_ecc_chars, seg_len=4096, start_bin=1500)

        # Giai ma ECC tu raw bits
        raw_e = dec_e.get("decoded", "")
        while len(raw_e) < n_ecc_chars:
            raw_e += ' '
        recovered = np.unpackbits(
            np.frombuffer(raw_e[:n_ecc_chars].encode('latin-1'), dtype=np.uint8)
        )[:len(ecc_bits)]
        decoded_ecc, corrections = decode_message_hamming(recovered, num_chars)
        ecc_ok = (decoded_ecc == message)

        writer.writerow([sigma, plain_ok, ecc_ok, corrections])
        print(f"{sigma:<8} {'True' if plain_ok else 'False':<12} {'True' if ecc_ok else 'False':<10} {corrections}")

print(f"\n[*] Ket qua da luu vao: results/ecc_noise.csv")
print("[*] Hay chay lenh 'checkwork' de kiem tra CW4.")
