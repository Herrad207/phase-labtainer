#!/usr/bin/env python3
"""
Hamming(7,4) Error Correction Code cho Lab 11.
Sinh vien nghien cuu va su dung module nay de bao ve tin hieu pha.
"""
import numpy as np
import os

os.makedirs("results", exist_ok=True)

# ===================================================
# PHAN 1: MA HOA HAMMING(7,4)
# ===================================================
# Ma tran sinh (Generator matrix) cho Hamming(7,4)
# Moi 4 bit du lieu duoc ma hoa thanh 7 bit (them 3 bit kiem tra chan le)
G = np.array([
    [1, 0, 0, 0, 1, 1, 0],
    [0, 1, 0, 0, 1, 0, 1],
    [0, 0, 1, 0, 0, 1, 1],
    [0, 0, 0, 1, 1, 1, 1]
], dtype=np.uint8)

# Ma tran kiem tra chan le (Parity check matrix)
H = np.array([
    [1, 1, 0, 1, 1, 0, 0],
    [1, 0, 1, 1, 0, 1, 0],
    [0, 1, 1, 1, 0, 0, 1]
], dtype=np.uint8)

# Bang tra cuu syndrome -> vi tri loi (1-indexed, 0 = khong loi)
SYNDROME_TABLE = {
    (0,0,0): 0,  # Khong loi
    (1,1,0): 1,  # Loi tai bit 1
    (1,0,1): 2,  # Loi tai bit 2
    (0,1,1): 3,  # Loi tai bit 3
    (1,1,1): 4,  # Loi tai bit 4
    (1,0,0): 5,  # Loi tai bit 5
    (0,1,0): 6,  # Loi tai bit 6
    (0,0,1): 7,  # Loi tai bit 7
}

def hamming_encode_nibble(data_bits):
    """
    Ma hoa 4 bit du lieu thanh 7 bit Hamming(7,4).
    
    Args:
        data_bits: list/array cua 4 bit [d1, d2, d3, d4]
    Returns:
        array cua 7 bit [d1, d2, d3, d4, p1, p2, p3]
    """
    d = np.array(data_bits[:4], dtype=np.uint8)
    codeword = (d @ G) % 2
    return codeword

def hamming_decode_nibble(received_bits):
    """
    Giai ma va sua loi 7 bit Hamming(7,4).
    
    Args:
        received_bits: list/array cua 7 bit
    Returns:
        (data_bits, corrected, error_pos)
        - data_bits: 4 bit du lieu goc
        - corrected: True neu da sua duoc loi
        - error_pos: vi tri loi (0 = khong loi, 1-7 = vi tri bit loi)
    """
    r = np.array(received_bits[:7], dtype=np.uint8)
    syndrome = tuple((H @ r) % 2)
    
    error_pos = SYNDROME_TABLE.get(syndrome, 0)
    corrected = False
    
    if error_pos > 0:
        r[error_pos - 1] ^= 1  # Sua bit loi
        corrected = True
    
    # Trich xuat 4 bit du lieu (4 bit dau)
    data_bits = r[:4]
    return data_bits, corrected, error_pos

def encode_message_hamming(message):
    """
    Ma hoa toan bo chuoi tin nhan bang Hamming(7,4).
    Moi byte (8 bit) duoc chia thanh 2 nibble (4 bit), moi nibble -> 7 bit.
    
    Args:
        message: chuoi van ban
    Returns:
        array bit da ma hoa ECC
    """
    raw_bits = np.unpackbits(np.frombuffer(message.encode('utf-8'), dtype=np.uint8))
    encoded = []
    for i in range(0, len(raw_bits), 4):
        nibble = raw_bits[i:i+4]
        if len(nibble) < 4:
            nibble = np.pad(nibble, (0, 4 - len(nibble)))
        codeword = hamming_encode_nibble(nibble)
        encoded.extend(codeword.tolist())
    return np.array(encoded, dtype=np.uint8)

def decode_message_hamming(encoded_bits, num_chars):
    """
    Giai ma va sua loi toan bo chuoi bit ECC.
    
    Args:
        encoded_bits: array bit da ma hoa ECC
        num_chars: so ky tu can giai ma
    Returns:
        (decoded_str, corrections_made)
    """
    num_nibbles = num_chars * 2  # moi char = 2 nibbles
    decoded_bits = []
    corrections = 0
    
    for i in range(num_nibbles):
        start = i * 7
        chunk = encoded_bits[start:start+7]
        if len(chunk) < 7:
            break
        data_bits, corrected, error_pos = hamming_decode_nibble(chunk)
        decoded_bits.extend(data_bits.tolist())
        if corrected:
            corrections += 1
    
    bits_arr = np.array(decoded_bits[:num_chars*8], dtype=np.uint8)
    if len(bits_arr) < num_chars * 8:
        bits_arr = np.pad(bits_arr, (0, num_chars*8 - len(bits_arr)))
    
    chars = bits_arr.reshape((-1, 8)).dot(1 << np.arange(7, -1, -1)).astype(np.uint8)
    decoded = ''.join(chr(c) for c in chars if 32 <= c <= 126)
    return decoded, corrections

# ===================================================
# PHAN 2: DEMO + KIEM TRA
# ===================================================
if __name__ == "__main__":
    message = "SECRET"
    print("=" * 55)
    print("[*] DEMO HAMMING(7,4) ERROR CORRECTION CODE")
    print("=" * 55)

    # 1. Ma hoa
    encoded = encode_message_hamming(message)
    print(f"[+] Tin goc     : '{message}'")
    print(f"[+] Bit goc     : {message.encode().hex()} ({len(message)*8} bit)")
    print(f"[+] Bit sau ECC : {len(encoded)} bit (ti le 7/4 = {len(encoded)}/{len(message)*8})")

    # 2. Giai ma khong co loi
    decoded, corrections = decode_message_hamming(encoded, len(message))
    print(f"\n[+] Giai ma (khong loi): '{decoded}' - Khop: {decoded == message}")

    # 3. Tao loi nhan tao o bit thu 3
    encoded_with_error = encoded.copy()
    encoded_with_error[2] ^= 1  # Flip bit 3
    decoded_err, corrections_err = decode_message_hamming(encoded_with_error, len(message))
    print(f"[+] Giai ma (co 1 bit loi): '{decoded_err}' - Sua duoc: {corrections_err} nibble - Khop: {decoded_err == message}")

    # 4. Ghi ket qua
    with open("results/hamming_test.txt", "w") as f:
        f.write(f"original:{message}\n")
        f.write(f"encoded_bits:{len(encoded)}\n")
        f.write(f"decoded_clean:{decoded}\n")
        f.write(f"match_clean:{decoded == message}\n")
        f.write(f"decoded_with_error:{decoded_err}\n")
        f.write(f"corrections_made:{corrections_err}\n")
        f.write(f"match_corrected:{decoded_err == message}\n")

    print(f"\n[*] Da ghi ket qua vao: results/hamming_test.txt")
    print(f"[*] Hay chay lenh 'checkwork' de kiem tra CW2.")
