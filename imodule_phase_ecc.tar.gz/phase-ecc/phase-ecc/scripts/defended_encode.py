#!/usr/bin/env python3
"""
CW8: Defended Encoder - Tich hop ECC + Sync Marker.
Su dung: python3 scripts/defended_encode.py input.wav "message" output.wav
"""
import numpy as np
import scipy.io.wavfile as wavfile
import argparse
import os
import sys

# Them thu muc cha vao path de import
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import encoder_lib
from hamming_ecc import encode_message_hamming, decode_message_hamming

# SYNC MARKER (giong sync_marker.py)
SYNC_PATTERN = np.array([1,0,1,0,1,1,0,1], dtype=np.uint8)

def defended_encode(input_wav, message, output_wav, seg_len=4096, start_bin=1500):
    """
    Encode co ECC + Sync Marker.
    Layout bit trong phase: [SYNC 8-bit] [ECC_ENCODED_BITS]
    """
    # 1. ECC encode
    ecc_bits = encode_message_hamming(message)
    
    # 2. Them sync marker phia truoc
    full_bits = np.concatenate([SYNC_PATTERN, ecc_bits])
    
    # 3. Chuyen full_bits thanh "ky tu" de encoder_lib xu ly
    n_chars = int(np.ceil(len(full_bits) / 8))
    padded = np.pad(full_bits, (0, n_chars * 8 - len(full_bits)))
    packed = np.packbits(padded)
    fake_msg = bytes(packed).decode('latin-1')
    
    # 4. Phase encode
    res = encoder_lib.encode(input_wav, fake_msg, seg_len=seg_len, start_bin=start_bin)
    if res["error"]:
        return False, f"Loi encode: {res['error']}"
    
    encoder_lib.save_wav(res["output"], res["fs"], output_wav, res["orig_dtype"])
    return True, f"Da luu: {output_wav} (sync+ECC, {len(full_bits)} bit tong cong)"

def defended_decode(stego_wav, num_chars, seg_len=4096, start_bin=1500):
    """
    Decode co ECC + Sync Marker.
    """
    sr, data = wavfile.read(stego_wav)
    data_f = data.astype(np.float64)
    
    n_segs = int(np.floor(len(data_f) / seg_len))
    if n_segs == 0:
        return "", False, "Audio qua ngan"
    
    audio_segs = data_f[:n_segs * seg_len].reshape((n_segs, seg_len))
    freqs = np.fft.fft(audio_segs)
    phases = np.angle(freqs)
    
    # ECC bits can: num_chars * 8 bit data * 7/4 overhead
    n_ecc_chars = int(np.ceil(num_chars * 2 * 7 / 8))  # moi char=2 nibbles, moi nibble=7bit
    total_bits_needed = 8 + n_ecc_chars * 8  # sync + ecc payload
    
    all_bits = np.array([1 if phases[0, start_bin + i] > 0 else 0
                         for i in range(total_bits_needed + 16)])
    
    # Tim sync
    sync_offset = None
    for offset in range(len(all_bits) - 8):
        if np.array_equal(all_bits[offset:offset+8], SYNC_PATTERN):
            sync_offset = offset + 8
            break
    
    if sync_offset is None:
        return "", False, "Khong tim thay sync marker"
    
    # Doc ECC bits
    ecc_payload = all_bits[sync_offset:sync_offset + n_ecc_chars * 8]
    
    # ECC decode
    decoded, corrections = decode_message_hamming(ecc_payload, num_chars)
    return decoded, True, f"OK (sua {corrections} nibble)"


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Defended Phase Encoder (ECC + Sync)")
    parser.add_argument("input", help="File WAV dau vao")
    parser.add_argument("message", help="Tin nhan can nhung")
    parser.add_argument("output", help="File WAV stego dau ra")
    parser.add_argument("--seg_len", type=int, default=4096)
    parser.add_argument("--start_bin", type=int, default=1500)
    args = parser.parse_args()
    
    ok, msg = defended_encode(args.input, args.message, args.output, args.seg_len, args.start_bin)
    print(f"[{'+'if ok else '-'}] {msg}")
    
    if ok:
        decoded, found, status = defended_decode(args.output, len(args.message), args.seg_len, args.start_bin)
        match = (decoded == args.message)
        print(f"[+] Self-test: '{decoded}' - {status} - Khop: {match}")
