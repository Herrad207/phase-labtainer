#!/usr/bin/env python3
"""
CW5 & CW6: Sync Marker - Chong lech khung FFT do cat mau (Crop Attack).

Khi cat N mau dau, decoder bi lech khung va doc sai vi tri bit.
Giai phap: chen mot bit-pattern "chum neo" (sync marker) de xac dinh 
chinh xac diem bat dau cua du lieu that.
"""
import numpy as np
import scipy.io.wavfile as wavfile
import csv
import os
import sys

sys.path.insert(0, '.')
import encoder_lib

os.makedirs("results", exist_ok=True)
os.makedirs("output", exist_ok=True)

# SYNC MARKER: chuoi 8 bit co pattern dac biet, kho xuat hien ngau nhien
SYNC_PATTERN = np.array([1,0,1,0,1,1,0,1], dtype=np.uint8)  # 0xAD

def embed_with_sync(audio_data, fs, message, seg_len=4096, start_bin=1500):
    """
    Nhung du lieu voi sync marker phia truoc.
    Layout: [SYNC_MARKER 8 bit] + [MESSAGE bits]
    """
    raw_bits = np.unpackbits(np.frombuffer(message.encode('utf-8'), dtype=np.uint8))
    full_bits = np.concatenate([SYNC_PATTERN, raw_bits])
    
    data = audio_data.astype(np.float64)
    n_segs = int(np.floor(len(data) / seg_len))
    audio_segs = data[:n_segs * seg_len].reshape((n_segs, seg_len))
    freqs = np.fft.fft(audio_segs)
    mags = np.abs(freqs)
    phases = np.angle(freqs)
    
    carrier_mag = 10000000.0
    for i, bit in enumerate(full_bits):
        if i >= (seg_len // 2 - start_bin): break
        new_phase = np.pi/2 if bit == 1 else -np.pi/2
        phases[0, start_bin + i] = new_phase
        phases[0, seg_len - (start_bin + i)] = -new_phase
        mags[0, start_bin + i] = carrier_mag
        mags[0, seg_len - (start_bin + i)] = carrier_mag
    
    freqs_new = mags * np.exp(1j * phases)
    audio_segs_new = np.fft.ifft(freqs_new).real
    output = np.copy(data)
    output[:n_segs * seg_len] = audio_segs_new.flatten()
    return output

def decode_with_sync(audio_data, num_chars, seg_len=4096, start_bin=1500):
    """
    Giai ma co sync marker: tim vi tri sync truoc, roi doc du lieu that.
    """
    data = audio_data.astype(np.float64)
    n_segs = int(np.floor(len(data) / seg_len))
    if n_segs == 0:
        return "", False
    
    audio_segs = data[:n_segs * seg_len].reshape((n_segs, seg_len))
    freqs = np.fft.fft(audio_segs)
    phases = np.angle(freqs)
    
    # Doc tat ca bit tu segment 0
    total_bits_needed = 8 + num_chars * 8  # sync + data
    all_bits = np.array([1 if phases[0, start_bin + i] > 0 else 0
                         for i in range(total_bits_needed + 8)])
    
    # Tim sync marker
    sync_found = False
    sync_offset = 0
    for offset in range(len(all_bits) - 8):
        if np.array_equal(all_bits[offset:offset+8], SYNC_PATTERN):
            sync_found = True
            sync_offset = offset + 8  # Du lieu bat dau ngay sau marker
            break
    
    if not sync_found:
        return "", False
    
    # Doc du lieu that
    data_bits = all_bits[sync_offset:sync_offset + num_chars * 8]
    if len(data_bits) < num_chars * 8:
        return "", False
    
    chars = data_bits.reshape((-1, 8)).dot(1 << np.arange(7, -1, -1)).astype(np.uint8)
    decoded = ''.join(chr(c) for c in chars if 32 <= c <= 126)
    return decoded, True


# =====================================================================
# CHAY DEMO
# =====================================================================
if __name__ == "__main__":
    print("=" * 65)
    print("[*] CW5: SYNC MARKER - XAC DINH DIEM BAT DAU DU LIEU")
    print("=" * 65)

    input_file = "input/audio_original.wav"
    sr, audio = wavfile.read(input_file)
    message = "SECRET"

    # 1. Embed voi sync marker
    synced_audio = embed_with_sync(audio, sr, message)
    stego_sync = "output/stego_sync.wav"
    encoder_lib.save_wav(synced_audio, sr, stego_sync, audio.dtype)
    print(f"[+] Da tao file stego co sync marker: {stego_sync}")

    # 2. Giai ma khong crop
    synced_sr, synced_data = wavfile.read(stego_sync)
    decoded, found = decode_with_sync(synced_data, len(message))
    is_match = (decoded == message) and found

    print(f"[+] Giai ma (khong crop): '{decoded}' - Sync found: {found} - Khop: {is_match}")

    with open("results/sync_test.txt", "w") as f:
        f.write(f"original:{message}\n")
        f.write(f"decoded:{decoded}\n")
        f.write(f"sync_found:{found}\n")
        f.write(f"match:{is_match}\n")

    print(f"\n[*] CW6: SO SANH PLAIN vs SYNC DUOI CROP ATTACK")
    print("=" * 65)

    # Plain stego (khong sync)
    res_plain = encoder_lib.encode(input_file, message, seg_len=4096, start_bin=1500)
    plain_file = "output/stego_plain_crop.wav"
    encoder_lib.save_wav(res_plain["output"], res_plain["fs"], plain_file, res_plain["orig_dtype"])

    crop_values = [0, 512, 1024, 2048, 4096, 8192]

    print(f"\n{'Crop N':<10} {'Plain OK':<12} {'Sync OK'}")
    print("-" * 35)

    with open("results/sync_crop.csv", "w", newline='') as f:
        writer = csv.writer(f)
        writer.writerow(["crop_n", "plain_ok", "sync_ok"])

        for crop_n in crop_values:
            # Test PLAIN
            sr_p, data_p = wavfile.read(plain_file)
            attacked_p = data_p[crop_n:]
            wavfile.write("output/temp_crop_plain.wav", sr_p, attacked_p)
            dec_p = encoder_lib.decode("output/temp_crop_plain.wav", len(message), seg_len=4096, start_bin=1500)
            plain_ok = (dec_p.get("decoded", "") == message)

            # Test SYNC
            attacked_s = synced_data[crop_n:]
            wavfile.write("output/temp_crop_sync.wav", synced_sr, attacked_s)
            sr_s2, data_s2 = wavfile.read("output/temp_crop_sync.wav")
            sync_decoded, sync_found2 = decode_with_sync(data_s2, len(message))
            sync_ok = (sync_decoded == message) and sync_found2

            writer.writerow([crop_n, plain_ok, sync_ok])
            print(f"{crop_n:<10} {'True' if plain_ok else 'False':<12} {'True' if sync_ok else 'False'}")

    print(f"\n[*] Ket qua CW5 da luu: results/sync_test.txt")
    print(f"[*] Ket qua CW6 da luu: results/sync_crop.csv")
    print("[*] Hay chay lenh 'checkwork' de kiem tra CW5 va CW6.")
