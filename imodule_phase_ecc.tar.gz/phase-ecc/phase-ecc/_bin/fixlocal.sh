#!/bin/bash
#
#  This script will be run after parameterization has completed, e.g., 
#  use this to compile source code that has been parameterized.
#  The container user password will be passed as the first argument,
#  (the user ID is the second parameter)
#
cd $HOME

# Chay script tao file am thanh moi cho lab ECC
python3 setup_ecc.py

# Xoa file setup de sinh vien khong bi roi mat
rm setup_ecc.py
EOF
