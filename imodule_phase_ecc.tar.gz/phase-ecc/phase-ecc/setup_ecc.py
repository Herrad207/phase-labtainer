#!/usr/bin/env python3
"""Tao file am thanh moi cho Lab 11 - Phase ECC."""
import numpy as np
import scipy.io.wavfile as wavfile
import sys
import os

sys.path.insert(0, '.')
from encoder_lib import encode, save_wav, decode

# 1. Dam bao thu muc ton tai
os.makedirs("input", exist_ok=True)
os.makedirs("results", exist_ok=True)
os.makedirs("output", exist_ok=True)
os.makedirs("scripts", exist_ok=True)

sr = 44100
t = np.arange(sr * 2) / sr

# 2. Xu ly thong minh cho Labtainers va Test Local
try:
    ecc_amp1 = PARAM_AMP_1
    ecc_amp2 = PARAM_AMP_2
except NameError:
    ecc_amp1 = 10000
    ecc_amp2 = 5000

# 3. Tao am thanh nen voi nhieu trang
music = (ecc_amp1 * np.sin(2 * np.pi * 440 * t) +
         ecc_amp2 * np.sin(2 * np.pi * 880 * t) +
         500 * np.random.randn(len(t)))

audio = np.clip(music, -32768, 32767).astype(np.int16)
wavfile.write("input/audio_original.wav", sr, audio)

# 4. Nhung ma bi mat chuan
res = encode("input/audio_original.wav", "SECRET", seg_len=4096, start_bin=1500)
if res["error"] is None:
    save_wav(res["output"], res["fs"], "input/stego_standard.wav", res["orig_dtype"])
    print("[+] Khoi tao thanh cong: input/stego_standard.wav")
else:
    print(f"[-] Loi ma hoa: {res['error']}")

# 5. Self-test
dec = decode("input/stego_standard.wav", 6, seg_len=4096, start_bin=1500)
if dec["error"] is None:
    is_match = (dec['decoded'] == 'SECRET')
    with open("input/verify.txt", "w") as f:
        f.write(f"decoded:{dec['decoded']}\nmatch:{is_match}\n")
    print(f"[+] Kiem dinh: Giai ma ra '{dec['decoded']}' - Khop: {is_match}")
else:
    print(f"[-] Loi giai ma: {dec['error']}")

print("[+] San sang cho Lab 11!")
