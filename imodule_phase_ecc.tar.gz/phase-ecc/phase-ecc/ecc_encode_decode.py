#!/usr/bin/env python3
"""
CW3: Ma hoa ECC + nhung vao pha + giai ma hoan toan.
Chung minh vong lap encode -> stego -> decode -> ECC_decode.
"""
import numpy as np
import scipy.io.wavfile as wavfile
import os
import sys

sys.path.insert(0, '.')
import encoder_lib
from hamming_ecc import encode_message_hamming, decode_message_hamming

os.makedirs("results", exist_ok=True)
os.makedirs("output", exist_ok=True)

input_file = "input/audio_original.wav"
stego_ecc_file = "output/stego_ecc.wav"
message = "SECRET"
num_chars = len(message)

print("=" * 60)
print("[*] CW3: VONG LAP ECC ENCODE -> PHASE STEGO -> DECODE")
print("=" * 60)

# BUOC 1: Ma hoa ECC
ecc_bits = encode_message_hamming(message)
print(f"[+] Tin goc: '{message}' ({num_chars*8} bit)")
print(f"[+] Sau ECC: {len(ecc_bits)} bit (Hamming 7/4, overhead x1.75)")

# BUOC 2: Chuyen ECC bits thanh "fake message" de nhung vao phase
# Trick: tao chuoi ky tu dai hon de chua het ECC bits
# Moi 8 bit ECC = 1 "ky tu ECC" (co the la ky tu khong in duoc)
n_ecc_chars = int(np.ceil(len(ecc_bits) / 8))
# Pad ecc_bits len boi 8
padded = np.pad(ecc_bits, (0, n_ecc_chars*8 - len(ecc_bits)))
ecc_bytes = np.packbits(padded)
ecc_fake_msg = bytes(ecc_bytes).decode('latin-1')

# BUOC 3: Nhung vao file am thanh
res = encoder_lib.encode(input_file, ecc_fake_msg, seg_len=4096, start_bin=1500)
if res["error"]:
    print(f"[-] Loi encode: {res['error']}")
    sys.exit(1)

encoder_lib.save_wav(res["output"], res["fs"], stego_ecc_file, res["orig_dtype"])
print(f"[+] Da tao stego ECC: {stego_ecc_file}")

# BUOC 4: Giai ma raw bits tu phase
dec_raw = encoder_lib.decode(stego_ecc_file, n_ecc_chars, seg_len=4096, start_bin=1500)
if dec_raw["error"]:
    print(f"[-] Loi decode phase: {dec_raw['error']}")
    sys.exit(1)

# Lay lai ECC bits tu ky tu giai ma
raw_chars = dec_raw["decoded"]
# Pad neu can
while len(raw_chars) < n_ecc_chars:
    raw_chars += ' '
recovered_ecc_bits = np.unpackbits(
    np.frombuffer(raw_chars[:n_ecc_chars].encode('latin-1'), dtype=np.uint8)
)[:len(ecc_bits)]

# BUOC 5: Giai ma Hamming
decoded_msg, corrections = decode_message_hamming(recovered_ecc_bits, num_chars)
is_match = (decoded_msg == message)

print(f"[+] Giai ma ECC: '{decoded_msg}' - So nibble sua loi: {corrections}")
print(f"[+] Khop voi goc: {is_match}")

# Ghi ket qua
with open("results/ecc_decode.txt", "w") as f:
    f.write(f"original:{message}\n")
    f.write(f"ecc_bits_total:{len(ecc_bits)}\n")
    f.write(f"n_ecc_chars:{n_ecc_chars}\n")
    f.write(f"decoded:{decoded_msg}\n")
    f.write(f"corrections:{corrections}\n")
    f.write(f"match:{is_match}\n")

print(f"\n[*] Da ghi ket qua vao: results/ecc_decode.txt")
print("[*] Hay chay lenh 'checkwork' de kiem tra CW3.")
