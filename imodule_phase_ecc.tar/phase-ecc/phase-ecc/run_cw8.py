#!/usr/bin/env python3
"""
CW8: Kiem tra dau cuoi (E2E) Defended Encoder.
Chay thu encode + decode voi ECC va Sync Marker day du.
"""
import os
import sys

sys.path.insert(0, '.')
from scripts.defended_encode import defended_encode, defended_decode

os.makedirs("results", exist_ok=True)
os.makedirs("output", exist_ok=True)

input_wav = "input/audio_original.wav"
output_wav = "output/stego_defended.wav"
message = "SECRET"

print("=" * 60)
print("[*] CW8: KIEM TRA DAU CUOI (E2E) DEFENDED ENCODER")
print("=" * 60)

# 1. Encode
ok, msg_encode = defended_encode(input_wav, message, output_wav)
print(f"[{'+'if ok else '-'}] Encode: {msg_encode}")

if not ok:
    print("[-] Dung vi loi encode!")
    sys.exit(1)

# 2. Decode dung
decoded, found, status = defended_decode(output_wav, len(message))
match = (decoded == message)
print(f"[+] Decode dung: '{decoded}' - {status} - Khop: {match}")

# 3. Ghi ket qua
with open("results/defended_e2e.txt", "w") as f:
    f.write(f"original:{message}\n")
    f.write(f"encoded:True\n")
    f.write(f"decoded:{decoded}\n")
    f.write(f"sync_found:{found}\n")
    f.write(f"match:{match}\n")
    f.write(f"decode_status:{status}\n")

print(f"\n[*] Da ghi ket qua vao: results/defended_e2e.txt")
print("[*] Hay chay lenh 'checkwork' de kiem tra CW8.")
