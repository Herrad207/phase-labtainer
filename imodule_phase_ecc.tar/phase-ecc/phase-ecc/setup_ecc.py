#!/usr/bin/env python3
"""
Tao file am thanh khoi tao cho Lab 11 - Phase ECC.
Chi tao: input/ - KHONG tao results/ hay output/
(Moi script CW se tu tao folder cua no khi sinh vien chay)
"""
import numpy as np
import scipy.io.wavfile as wavfile
import sys, os

sys.path.insert(0, '.')
from encoder_lib import encode, save_wav, decode

# Chi tao input/ - KHONG tao results/ output/ scripts/
os.makedirs("input", exist_ok=True)

sr = 44100
t = np.arange(sr * 2) / sr

try:
    ecc_amp1 = PARAM_AMP_1
    ecc_amp2 = PARAM_AMP_2
except NameError:
    ecc_amp1 = 10000
    ecc_amp2 = 5000

music = (ecc_amp1 * np.sin(2 * np.pi * 440 * t) +
         ecc_amp2 * np.sin(2 * np.pi * 880 * t) +
         500 * np.random.randn(len(t)))

audio = np.clip(music, -32768, 32767).astype(np.int16)
wavfile.write("input/audio_original.wav", sr, audio)

res = encode("input/audio_original.wav", "SECRET", seg_len=4096, start_bin=1500)
if res["error"] is None:
    save_wav(res["output"], res["fs"], "input/stego_standard.wav", res["orig_dtype"])
    print("[+] Khoi tao thanh cong: input/stego_standard.wav")
else:
    print(f"[-] Loi ma hoa: {res['error']}")

dec = decode("input/stego_standard.wav", 6, seg_len=4096, start_bin=1500)
if dec["error"] is None:
    is_match = (dec['decoded'] == 'SECRET')
    with open("input/verify.txt", "w") as f:
        f.write(f"decoded:{dec['decoded']}\nmatch:{is_match}\n")
    print(f"[+] Kiem dinh: '{dec['decoded']}' - Khop: {is_match}")
else:
    print(f"[-] Loi giai ma: {dec['error']}")

print("[+] San sang cho Lab 11!")
