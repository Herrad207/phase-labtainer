#!/usr/bin/env python3
"""
CW3: Ma hoa ECC + nhung vao pha + giai ma hoan toan.
Fix: encode/decode bits truc tiep vao phase, bo qua filter ASCII printable.
"""
import numpy as np
import scipy.io.wavfile as wavfile
import os, sys

sys.path.insert(0, '.')
from hamming_ecc import encode_message_hamming, decode_message_hamming

os.makedirs("results", exist_ok=True)
os.makedirs("output", exist_ok=True)

SEG_LEN   = 4096
START_BIN = 1500
CARRIER   = 10000000.0

def embed_bits(input_wav, bits, output_wav):
    fs, data = wavfile.read(input_wav)
    orig = data.dtype
    if data.ndim > 1: data = data[:, 0]
    data = data.astype(np.float64)
    n = int(np.floor(len(data) / SEG_LEN))
    segs = data[:n*SEG_LEN].reshape((n, SEG_LEN))
    F = np.fft.fft(segs)
    M, P = np.abs(F), np.angle(F)
    for i, b in enumerate(bits):
        if i >= SEG_LEN//2 - START_BIN: break
        ph = np.pi/2 if b else -np.pi/2
        P[0, START_BIN+i] = ph;  P[0, SEG_LEN-(START_BIN+i)] = -ph
        M[0, START_BIN+i] = CARRIER; M[0, SEG_LEN-(START_BIN+i)] = CARRIER
    out = np.copy(data)
    out[:n*SEG_LEN] = np.fft.ifft(M*np.exp(1j*P)).real.flatten()
    if orig == np.int16: out = np.clip(out, -32768, 32767)
    wavfile.write(output_wav, fs, out.astype(orig))

def extract_bits(wav, n_bits):
    _, data = wavfile.read(wav)
    if data.ndim > 1: data = data[:, 0]
    data = data.astype(np.float64)
    n = int(np.floor(len(data) / SEG_LEN))
    P = np.angle(np.fft.fft(data[:n*SEG_LEN].reshape((n, SEG_LEN))))
    return np.array([1 if P[0, START_BIN+i] > 0 else 0 for i in range(n_bits)], dtype=np.uint8)

# ── MAIN ──────────────────────────────────────────────────────
message = "SECRET"
print("="*60)
print("[*] CW3: VONG LAP ECC ENCODE -> PHASE STEGO -> DECODE")
print("="*60)

ecc_bits = encode_message_hamming(message)
print(f"[+] Tin goc: '{message}' ({len(message)*8} bit)")
print(f"[+] Sau ECC: {len(ecc_bits)} bit (overhead x1.75)")

embed_bits("input/audio_original.wav", ecc_bits, "output/stego_ecc.wav")
print(f"[+] Da tao: output/stego_ecc.wav")

recovered = extract_bits("output/stego_ecc.wav", len(ecc_bits))
ok_bits = np.array_equal(recovered, ecc_bits)
print(f"[+] Bits round-trip match: {ok_bits}")

decoded, corr = decode_message_hamming(recovered, len(message))
match = (decoded == message)
print(f"[+] Giai ma: '{decoded}' | Sua: {corr} nibble | Khop: {match}")

with open("results/ecc_decode.txt", "w") as f:
    f.write(f"original:{message}\n")
    f.write(f"ecc_bits_total:{len(ecc_bits)}\n")
    f.write(f"phase_bits_match:{ok_bits}\n")
    f.write(f"decoded:{decoded}\n")
    f.write(f"corrections:{corr}\n")
    f.write(f"match:{match}\n")

print(f"\n[*] Ghi: results/ecc_decode.txt")
print("[*] Hay chay 'checkwork' de kiem tra CW3.")
