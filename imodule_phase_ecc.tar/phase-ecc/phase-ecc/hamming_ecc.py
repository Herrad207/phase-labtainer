#!/usr/bin/env python3
"""
CW2: Tim hieu Hamming(7,4) Error Correction Code.

Nhiem vu: Dien vao cac cho trong (???) trong bai tap ben duoi.
Khong duoc chay thu truoc - hay suy nghi, tinh tay truoc, roi kiem tra.
"""
import numpy as np
import os

os.makedirs("results", exist_ok=True)

# ===================================================
# PHAN 1: KIEN THUC CO SO
# ===================================================
# Ma tran sinh Hamming(7,4):
#   moi 4 bit du lieu [d1,d2,d3,d4] duoc ma hoa thanh 7 bit
#   codeword = data @ G  (mod 2)
G = np.array([
    [1, 0, 0, 0, 1, 1, 0],
    [0, 1, 0, 0, 1, 0, 1],
    [0, 0, 1, 0, 0, 1, 1],
    [0, 0, 0, 1, 1, 1, 1]
], dtype=np.uint8)

H = np.array([
    [1, 1, 0, 1, 1, 0, 0],
    [1, 0, 1, 1, 0, 1, 0],
    [0, 1, 1, 1, 0, 0, 1]
], dtype=np.uint8)

SYNDROME_TABLE = {
    (0,0,0): 0,
    (1,1,0): 1, (1,0,1): 2, (0,1,1): 3, (1,1,1): 4,
    (1,0,0): 5, (0,1,0): 6, (0,0,1): 7,
}

def hamming_encode_nibble(data_bits):
    d = np.array(data_bits[:4], dtype=np.uint8)
    return (d @ G) % 2

def hamming_decode_nibble(received_bits):
    r = np.array(received_bits[:7], dtype=np.uint8)
    syndrome = tuple((H @ r) % 2)
    error_pos = SYNDROME_TABLE.get(syndrome, 0)
    corrected = False
    if error_pos > 0:
        r[error_pos - 1] ^= 1
        corrected = True
    return r[:4], corrected, error_pos

def encode_message_hamming(message):
    raw_bits = np.unpackbits(np.frombuffer(message.encode('utf-8'), dtype=np.uint8))
    encoded = []
    for i in range(0, len(raw_bits), 4):
        nibble = raw_bits[i:i+4]
        if len(nibble) < 4:
            nibble = np.pad(nibble, (0, 4 - len(nibble)))
        encoded.extend(hamming_encode_nibble(nibble).tolist())
    return np.array(encoded, dtype=np.uint8)

def decode_message_hamming(encoded_bits, num_chars):
    num_nibbles = num_chars * 2
    decoded_bits = []
    corrections = 0
    for i in range(num_nibbles):
        start = i * 7
        chunk = encoded_bits[start:start+7]
        if len(chunk) < 7:
            break
        data_bits, corrected, _ = hamming_decode_nibble(chunk)
        decoded_bits.extend(data_bits.tolist())
        if corrected:
            corrections += 1
    bits_arr = np.array(decoded_bits[:num_chars*8], dtype=np.uint8)
    if len(bits_arr) < num_chars * 8:
        bits_arr = np.pad(bits_arr, (0, num_chars*8 - len(bits_arr)))
    chars = bits_arr.reshape((-1, 8)).dot(1 << np.arange(7, -1, -1)).astype(np.uint8)
    decoded = ''.join(chr(c) for c in chars if 32 <= c <= 126)
    return decoded, corrections

# ===================================================
# PHAN 2: BAI TAP - SINH VIEN DIEN VAO CHO TRONG
# ===================================================
print("=" * 60)
print("  CW2: BAI TAP HAMMING(7,4) - DIEN VAO CHO TRONG")
print("=" * 60)
print()
print("Ky tu 'S' = 0x53 = 01010011 (nhi phan)")
print("Nibble 1 (4 bit dau): [0, 1, 0, 1]")
print("Nibble 2 (4 bit sau): [0, 0, 1, 1]")
print()

answers = {}

# ── Bai 1: Ma hoa thu cong ──────────────────────────────────
print("-" * 60)
print("BAI 1: MA HOA THU CONG")
print("-" * 60)
print("Cho nibble = [0, 1, 0, 1], ma tran G nhu sau:")
print("  G = [[1,0,0,0,1,1,0],")
print("       [0,1,0,0,1,0,1],")
print("       [0,0,1,0,0,1,1],")
print("       [0,0,0,1,1,1,1]]")
print()
print("Codeword = [0,1,0,1] @ G  (mod 2)")
print("         = 0*row0 + 1*row1 + 0*row2 + 1*row3  (mod 2)")
print("         = [0,1,0,0,1,0,1] XOR [0,0,0,1,1,1,1]  (mod 2)")
print("         = ???")
print()

while True:
    ans = input("[?] Nhap 7 bit codeword (vi du: 0101011): ").strip()
    if len(ans) == 7 and all(c in '01' for c in ans):
        break
    print("    [!] Vui long nhap dung 7 chu so 0 hoac 1!")

user_cw = [int(c) for c in ans]
correct_cw = hamming_encode_nibble([0,1,0,1]).tolist()
bai1_ok = (user_cw == correct_cw)
answers['bai1_codeword'] = ans
answers['bai1_correct'] = correct_cw

if bai1_ok:
    print(f"    [+] DUNG! Codeword = {correct_cw}")
else:
    print(f"    [-] Chua dung. Dap an: {correct_cw}")
    print(f"        Tinh lai: row1=[0,1,0,0,1,0,1], row3=[0,0,0,1,1,1,1]")
    print(f"        XOR tung vi tri: {correct_cw}")
print()

# ── Bai 2: Phat hien vi tri loi ──────────────────────────────
print("-" * 60)
print("BAI 2: PHAT HIEN LOI BANG SYNDROME")
print("-" * 60)
print("Received (co loi): r = [0, 1, 0, 1, 0, 0, 1]")
print("                        d1 d2 d3 d4 p1 p2 p3")
print()
print("Syndrome s = H @ r  (mod 2)")
print("Ma tran H:")
print("  H = [[1,1,0,1,1,0,0],")
print("       [1,0,1,1,0,1,0],")
print("       [0,1,1,1,0,0,1]]")
print()
print("Tinh:")
print("  s[0] = r[0]^r[1]^r[3]^r[4] = ?")
print("  s[1] = r[0]^r[2]^r[3]^r[5] = ?")
print("  s[2] = r[1]^r[2]^r[3]^r[6] = ?")
print()

while True:
    ans2 = input("[?] Nhap syndrome (3 bit, vi du: 101): ").strip()
    if len(ans2) == 3 and all(c in '01' for c in ans2):
        break
    print("    [!] Vui long nhap dung 3 chu so 0 hoac 1!")

received = [0,1,0,1,0,0,1]
correct_syndrome = tuple((H @ np.array(received, dtype=np.uint8)) % 2)
user_syndrome = tuple(int(c) for c in ans2)
bai2_ok = (user_syndrome == correct_syndrome)
answers['bai2_syndrome'] = ans2
answers['bai2_correct'] = ''.join(str(b) for b in correct_syndrome)

if bai2_ok:
    print(f"    [+] DUNG! Syndrome = {list(correct_syndrome)}")
    error_pos = SYNDROME_TABLE.get(correct_syndrome, 0)
    print(f"    [+] Tra bang: loi tai bit thu {error_pos}")
else:
    print(f"    [-] Chua dung. Dap an: {list(correct_syndrome)}")
    print(f"        s[0]=0^1^1^0=0, s[1]=0^0^1^0=1, s[2]=1^0^1^1=1")
print()

# ── Bai 3: Overhead ECC ─────────────────────────────────────
print("-" * 60)
print("BAI 3: TINH OVERHEAD")
print("-" * 60)
print("Tin nhan 'SECRET' = 6 ky tu = 48 bit du lieu.")
print()
print("Hamming(7,4): moi 4 bit du lieu -> 7 bit luu tru.")
print("Moi BYTE (8 bit) = 2 nibble -> 2x7 = ??? bit luu tru")
print("Toan bo 'SECRET': 48 bit -> ??? bit sau ECC")
print()

while True:
    try:
        ans3 = int(input("[?] So bit sau khi ECC 'SECRET' (48 bit): "))
        break
    except ValueError:
        print("    [!] Nhap so nguyen!")

correct_bits = len(encode_message_hamming("SECRET"))
bai3_ok = (ans3 == correct_bits)
answers['bai3_ecc_bits'] = ans3
answers['bai3_correct'] = correct_bits

if bai3_ok:
    print(f"    [+] DUNG! 48 bit x (7/4) = {correct_bits} bit")
else:
    print(f"    [-] Chua dung. 48 / 4 nibble = 12 nibble, 12 x 7 = {correct_bits} bit")
print()

# ── Bai 4: Cau hoi nhan thuc ────────────────────────────────
print("-" * 60)
print("BAI 4: LY DO DUNG ECC TRONG STEGANOGRAPHY")
print("-" * 60)
print("Khi nhung tin hieu vao goc pha FFT va bi tan cong nhieu,")
print("hien tuong gi xay ra voi cac bit du lieu?")
print()
print("  A. Tat ca bit bi xoa sach (decode ra chuoi rong)")
print("  B. Mot so bit bi flip ngau nhien (0->1 hoac 1->0)")
print("  C. Cac bit bi dao nguoc theo thu tu")
print("  D. Khong co gi thay doi (pha rat on dinh)")
print()
ans4 = input("[?] Chon dap an (A/B/C/D): ").strip().upper()
answers['bai4_noise_effect'] = ans4
bai4_ok = (ans4 == 'B')

if bai4_ok:
    print("    [+] DUNG! Nhieu Gaussian lam lech goc pha => mot so bit bi flip")
    print("        ECC Hamming(7,4) co the SUA DUOC neu <= 1 bit loi / 7 bit block")
else:
    print("    [-] Chua dung. Dap an dung la B.")
    print("        Nhieu Gaussian lam lech goc pha ngau nhien => bit flip")
print()

print("-" * 60)
print("BAI 5: DIEM YEU CUA ECC")
print("-" * 60)
print("Hamming(7,4) chi sua duoc toi da may bit loi trong 1 block 7 bit?")
print()
print("  A. 1 bit loi   B. 2 bit loi   C. 3 bit loi   D. Khong gioi han")
print()
ans5 = input("[?] Chon dap an (A/B/C/D): ").strip().upper()
answers['bai5_ecc_limit'] = ans5
bai5_ok = (ans5 == 'A')

if bai5_ok:
    print("    [+] DUNG! Hamming(7,4) chi SUA DUOC 1 bit loi / 7 bit block")
    print("        Neu 2+ bit loi trong 1 block => giai ma sai, khong phat hien duoc")
else:
    print("    [-] Chua dung. Dap an dung la A (1 bit).")
print()

# ── Ket qua ──────────────────────────────────────────────────
print("=" * 60)
score = sum([bai1_ok, bai2_ok, bai3_ok, bai4_ok, bai5_ok])
print(f"  KET QUA: {score}/5 cau dung")
print("=" * 60)
print()

# Chay demo chinh thuc de ghi file
encoded = encode_message_hamming("SECRET")
decoded_clean, _ = decode_message_hamming(encoded, 6)

encoded_err = encoded.copy(); encoded_err[2] ^= 1
decoded_err, corr_err = decode_message_hamming(encoded_err, 6)

with open("results/hamming_test.txt", "w") as f:
    f.write(f"original:SECRET\n")
    f.write(f"encoded_bits:{len(encoded)}\n")
    f.write(f"decoded_clean:{decoded_clean}\n")
    f.write(f"match_clean:{decoded_clean == 'SECRET'}\n")
    f.write(f"decoded_with_error:{decoded_err}\n")
    f.write(f"corrections_made:{corr_err}\n")
    f.write(f"match_corrected:{decoded_err == 'SECRET'}\n")
    f.write(f"quiz_score:{score}/5\n")
    f.write(f"bai1_ok:{bai1_ok}\n")
    f.write(f"bai2_ok:{bai2_ok}\n")
    f.write(f"bai3_ok:{bai3_ok}\n")
    f.write(f"bai4_ok:{bai4_ok}\n")
    f.write(f"bai5_ok:{bai5_ok}\n")

print(f"[*] Da ghi ket qua vao: results/hamming_test.txt")
print("[*] Hay chay lenh 'checkwork' de kiem tra CW2.")
