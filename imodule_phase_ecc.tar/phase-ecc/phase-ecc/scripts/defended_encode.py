#!/usr/bin/env python3
"""
CW8: Defended Encoder - Tich hop ECC + Multi-Segment Sync.
Su dung: python3 scripts/defended_encode.py input.wav "message" output.wav
"""
import numpy as np
import scipy.io.wavfile as wavfile
import argparse, os, sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from hamming_ecc import encode_message_hamming, decode_message_hamming

SEG_LEN   = 4096
START_BIN = 1500
CARRIER   = 10000000.0
SYNC_PAT  = np.array([1,0,1,0,1,1,0,1], dtype=np.uint8)

def _embed(data, bits, n_segs):
    segs = data[:n_segs*SEG_LEN].reshape((n_segs, SEG_LEN))
    F = np.fft.fft(segs); M, P = np.abs(F), np.angle(F)
    for si in range(n_segs):
        for i, b in enumerate(bits):
            if i >= SEG_LEN//2 - START_BIN: break
            ph = np.pi/2 if b else -np.pi/2
            P[si, START_BIN+i] = ph; P[si, SEG_LEN-(START_BIN+i)] = -ph
            M[si, START_BIN+i] = CARRIER; M[si, SEG_LEN-(START_BIN+i)] = CARRIER
    out = np.copy(data)
    out[:n_segs*SEG_LEN] = np.fft.ifft(M*np.exp(1j*P)).real.flatten()
    return out

def defended_encode(input_wav, message, output_wav):
    """ECC encode + Sync Marker + multi-segment embed."""
    ecc_bits = encode_message_hamming(message)
    full_bits = np.concatenate([SYNC_PAT, ecc_bits])

    fs, data = wavfile.read(input_wav)
    orig = data.dtype
    if data.ndim > 1: data = data[:, 0]
    data = data.astype(np.float64)
    n = int(np.floor(len(data) / SEG_LEN))
    if n == 0:
        return False, "Audio qua ngan"
    if len(full_bits) >= SEG_LEN//2 - START_BIN:
        return False, "Tin nhan qua dai cho segment"

    out = _embed(data, full_bits, n)
    if orig == np.int16: out = np.clip(out, -32768, 32767)
    wavfile.write(output_wav, fs, out.astype(orig))
    return True, f"Da luu: {output_wav} ({len(full_bits)} bit: sync+ECC)"

def defended_decode(stego_wav, num_chars):
    """Tim sync trong tung segment, ECC decode bits sau sync."""
    _, data = wavfile.read(stego_wav)
    if data.ndim > 1: data = data[:, 0]
    data = data.astype(np.float64)
    n = int(np.floor(len(data) / SEG_LEN))
    if n == 0: return "", False, "Audio qua ngan"

    ecc_len = num_chars * 2 * 7   # moi char=2 nibbles, moi nibble=7 bit
    total_read = len(SYNC_PAT) + ecc_len
    segs = data[:n*SEG_LEN].reshape((n, SEG_LEN))
    P = np.angle(np.fft.fft(segs))

    for si in range(n):
        sync_bits = np.array([1 if P[si, START_BIN+i] > 0 else 0
                               for i in range(len(SYNC_PAT))], dtype=np.uint8)
        if np.array_equal(sync_bits, SYNC_PAT):
            ecc_bits = np.array([1 if P[si, START_BIN+len(SYNC_PAT)+i] > 0 else 0
                                  for i in range(ecc_len)], dtype=np.uint8)
            decoded, corr = decode_message_hamming(ecc_bits, num_chars)
            return decoded, True, f"OK (sua {corr} nibble)"

    return "", False, "Khong tim thay sync marker"


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Defended Phase Encoder")
    parser.add_argument("input",   help="File WAV dau vao")
    parser.add_argument("message", help="Tin nhan can nhung")
    parser.add_argument("output",  help="File WAV stego dau ra")
    args = parser.parse_args()

    ok, msg = defended_encode(args.input, args.message, args.output)
    print(f"[{'+'if ok else '-'}] {msg}")
    if ok:
        decoded, found, status = defended_decode(args.output, len(args.message))
        print(f"[+] Self-test: '{decoded}' - {status} - Khop: {decoded==args.message}")
