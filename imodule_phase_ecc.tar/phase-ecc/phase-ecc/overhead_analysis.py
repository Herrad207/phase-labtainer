#!/usr/bin/env python3
"""
CW7: Phan tich danh doi chi phi (Overhead Tradeoff) cua ECC.
ECC tang kha nang chong loi nhung giam dung luong chua thong tin.
"""
import numpy as np
import scipy.io.wavfile as wavfile
import os
import sys

sys.path.insert(0, '.')
import encoder_lib
from hamming_lib import encode_message_hamming

os.makedirs("results", exist_ok=True)

input_file = "input/audio_original.wav"

try:
    sr, data = wavfile.read(input_file)
except FileNotFoundError:
    print(f"[!] Loi: Khong tim thay {input_file}")
    sys.exit(1)

# Tinh toan suc chua
seg_len = 4096
start_bin = 1500
n_segs = int(np.floor(len(data) / seg_len))

# Tong so bit co the nhung trong 1 segment (S0)
max_bits_per_seg = seg_len // 2 - start_bin - 1

# PLAIN: max chars
plain_max_chars = max_bits_per_seg // 8
print(f"[*] PHAN TICH DUNG LUONG - PLAIN vs ECC")
print(f"    Tham so: seg_len={seg_len}, start_bin={start_bin}")
print(f"    Max bits trong S0: {max_bits_per_seg}")
print(f"    Plain: {plain_max_chars} ky tu toi da ({max_bits_per_seg} bit)")

# ECC Hamming(7,4): moi 4 bit du lieu -> 7 bit luu tru
# Nen moi byte (8 bit) -> 2 nibbles -> 2x7=14 bit luu tru
ecc_overhead_ratio = 7 / 4  # = 1.75
ecc_max_bits_data = int(max_bits_per_seg / ecc_overhead_ratio)
ecc_max_chars = ecc_max_bits_data // 8

print(f"    ECC(7,4): {ecc_max_chars} ky tu toi da ({ecc_max_bits_data} bit du lieu, luu {int(ecc_max_bits_data * ecc_overhead_ratio)} bit)")
print(f"    Mat mat dung luong: {plain_max_chars - ecc_max_chars} ky tu ({(1 - ecc_max_chars/plain_max_chars)*100:.1f}%)")
print(f"    Loi ich: co the sua loi 1 bit/nibble (chong nhieu hieu qua)")

# Tim max chars thuc te bang thu encode tang dan
print(f"\n[*] Kiem tra thuc te (encode tang dan, dung khi loi)...")

plain_actual = 0
for n in range(1, plain_max_chars + 5):
    test_msg = "A" * n
    res = encoder_lib.encode(input_file, test_msg, seg_len=seg_len, start_bin=start_bin)
    if res["error"]:
        break
    dec = encoder_lib.decode("input/stego_standard.wav", n, seg_len=seg_len, start_bin=start_bin)
    # Chi can encode khong loi la ok
    plain_actual = n

ecc_actual = 0
for n in range(1, ecc_max_chars + 5):
    test_msg = "A" * n
    ecc_bits = encode_message_hamming(test_msg)
    n_ecc_chars = int(np.ceil(len(ecc_bits) / 8))
    padded = np.pad(ecc_bits, (0, n_ecc_chars*8 - len(ecc_bits)))
    ecc_bytes = np.packbits(padded)
    ecc_fake_msg = bytes(ecc_bytes).decode('latin-1')
    res = encoder_lib.encode(input_file, ecc_fake_msg, seg_len=seg_len, start_bin=start_bin)
    if res["error"]:
        break
    ecc_actual = n

# Ghi ket qua
with open("results/overhead.txt", "w") as f:
    f.write(f"seg_len:{seg_len}\n")
    f.write(f"start_bin:{start_bin}\n")
    f.write(f"max_bits_s0:{max_bits_per_seg}\n")
    f.write(f"plain_capacity:{plain_actual}\n")
    f.write(f"ecc_capacity:{ecc_actual}\n")
    f.write(f"ecc_overhead:{ecc_overhead_ratio}\n")
    f.write(f"capacity_loss_pct:{(1 - ecc_actual/max(plain_actual,1))*100:.1f}\n")
    f.write(f"ecc_benefit:Sua_loi_1bit_per_nibble\n")

print(f"\n[+] Plain capacity (thuc te): {plain_actual} ky tu")
print(f"[+] ECC capacity  (thuc te): {ecc_actual} ky tu")
print(f"[+] Mat mat      : {plain_actual - ecc_actual} ky tu")
print(f"\n[*] Da ghi ket qua vao: results/overhead.txt")
print("[*] Hay chay lenh 'checkwork' de kiem tra CW7.")
