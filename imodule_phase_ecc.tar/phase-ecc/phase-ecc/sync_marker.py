#!/usr/bin/env python3
"""
CW5 & CW6: Sync Marker - sinh vien tu kham pha crop boundary.

CW5: Chay auto - hieu co che sync marker.
CW6: Sinh vien TU NHAP crop_n, tu tim ra quy luat boi so SEG_LEN.
"""
import numpy as np
import scipy.io.wavfile as wavfile
import csv, os, sys

sys.path.insert(0, '.')
import encoder_lib

os.makedirs("results", exist_ok=True)
os.makedirs("output", exist_ok=True)

SEG_LEN   = 4096
START_BIN = 1500
CARRIER   = 10000000.0
SYNC_PAT  = np.array([1,0,1,0,1,1,0,1], dtype=np.uint8)
SYNC_LEN  = len(SYNC_PAT)

def embed_multi_sync(input_wav, message, output_wav):
    raw = np.unpackbits(np.frombuffer(message.encode(), dtype=np.uint8))
    bits = np.concatenate([SYNC_PAT, raw])
    fs, data = wavfile.read(input_wav)
    orig = data.dtype
    if data.ndim > 1: data = data[:, 0]
    data = data.astype(np.float64)
    n = int(np.floor(len(data) / SEG_LEN))
    segs = data[:n*SEG_LEN].reshape((n, SEG_LEN))
    F = np.fft.fft(segs); M, P = np.abs(F), np.angle(F)
    for si in range(n):
        for i, b in enumerate(bits):
            if i >= SEG_LEN//2 - START_BIN: break
            ph = np.pi/2 if b else -np.pi/2
            P[si, START_BIN+i] = ph; P[si, SEG_LEN-(START_BIN+i)] = -ph
            M[si, START_BIN+i] = CARRIER; M[si, SEG_LEN-(START_BIN+i)] = CARRIER
    out = np.copy(data)
    out[:n*SEG_LEN] = np.fft.ifft(M*np.exp(1j*P)).real.flatten()
    if orig == np.int16: out = np.clip(out, -32768, 32767)
    wavfile.write(output_wav, fs, out.astype(orig))

def decode_multi_sync(stego_wav, num_chars):
    _, data = wavfile.read(stego_wav)
    if data.ndim > 1: data = data[:, 0]
    data = data.astype(np.float64)
    n = int(np.floor(len(data) / SEG_LEN))
    if n == 0: return "", False
    segs = data[:n*SEG_LEN].reshape((n, SEG_LEN))
    P = np.angle(np.fft.fft(segs))
    for si in range(n):
        sync_bits = np.array([1 if P[si, START_BIN+i] > 0 else 0
                               for i in range(SYNC_LEN)], dtype=np.uint8)
        if np.array_equal(sync_bits, SYNC_PAT):
            data_bits = np.array([1 if P[si, START_BIN+SYNC_LEN+i] > 0 else 0
                                   for i in range(num_chars*8)])
            chars = data_bits.reshape((-1,8)).dot(1<<np.arange(7,-1,-1)).astype(np.uint8)
            return ''.join(chr(c) for c in chars if 32<=c<=126), True
    return "", False

message = "SECRET"

# ═══════════════════════════════════════════════════════════════
# CW5: AUTO — hieu co che sync
# ═══════════════════════════════════════════════════════════════
print("="*65)
print("[*] CW5: SYNC MARKER - CO CHE HOAT DONG")
print("="*65)
print(f"[-] Sync Pattern: {SYNC_PAT.tolist()}  (0xAD)")
print(f"[-] Layout: [8-bit SYNC][message bits] nhung vao TUNG segment")
print(f"[-] Decoder: quet tung segment, tim sync pattern, roi doc data")
print()

embed_multi_sync("input/audio_original.wav", message, "output/stego_sync.wav")
print(f"[+] Da tao: output/stego_sync.wav")

decoded, found = decode_multi_sync("output/stego_sync.wav", len(message))
match = (decoded == message) and found
print(f"[+] Test giai ma (crop=0): '{decoded}' | sync_found={found} | khop={match}")

with open("results/sync_test.txt", "w") as f:
    f.write(f"original:{message}\n")
    f.write(f"decoded:{decoded}\n")
    f.write(f"sync_found:{found}\n")
    f.write(f"match:{match}\n")

# ═══════════════════════════════════════════════════════════════
# CW6: INTERACTIVE — sinh vien kham pha crop boundary
# ═══════════════════════════════════════════════════════════════
print()
print("="*65)
print("[*] CW6: KHAM PHA CROP BOUNDARY (TU THU NGHIEM)")
print("="*65)
print(f"[-] SEG_LEN = {SEG_LEN} mau (mot khung FFT)")
print(f"[-] 2 file stego da san:")
print(f"    output/stego_plain_crop.wav  -- Plain (khong sync)")
print(f"    output/stego_sync.wav        -- Co sync marker")
print()
print("[-] NHIEM VU: Thu cac gia tri crop_n khac nhau.")
print("              Tim ra: khi nao Sync song sot ma Plain khong?")
print("              Quy luat gi quyet dinh sync hoat dong?")
print(f"[-] Goi y: Thu: 0, 100, 512, 1000, 4096, 5000, 8192, 9000, 12288")
print("[-] Go 'q' khi da hieu quy luat, roi tra loi cau hoi.")
print("="*65 + "\n")

# Plain stego
res_p = encoder_lib.encode("input/audio_original.wav", message, seg_len=SEG_LEN, start_bin=START_BIN)
encoder_lib.save_wav(res_p["output"], res_p["fs"], "output/stego_plain_crop.wav", res_p["orig_dtype"])

sr_p, data_p = wavfile.read("output/stego_plain_crop.wav")
sr_s, data_s = wavfile.read("output/stego_sync.wav")

results_cw6 = []

while True:
    user_input = input("[?] Nhap crop_n (so mau cat bo dau file, hoac 'q'): ").strip()

    if user_input.lower() in ['q', 'quit', 'exit']:
        break
    if not user_input:
        continue
    try:
        crop_n = int(user_input)
        if crop_n < 0:
            print("    [!] crop_n phai >= 0!\n"); continue
    except ValueError:
        print("    [!] Nhap so nguyen!\n"); continue

    # Test plain
    attacked_p = data_p[crop_n:]
    if len(attacked_p) == 0:
        print("    [!] Cat het roi, khong con gi de test!\n"); continue
    wavfile.write("output/tmp_cp6.wav", sr_p, attacked_p)
    dp = encoder_lib.decode("output/tmp_cp6.wav", len(message), seg_len=SEG_LEN, start_bin=START_BIN)
    plain_ok = (dp.get("decoded","") == message)

    # Test sync
    attacked_s = data_s[crop_n:]
    wavfile.write("output/tmp_cs6.wav", sr_s, attacked_s)
    dec_s, found_s = decode_multi_sync("output/tmp_cs6.wav", len(message))
    sync_ok = (dec_s == message) and found_s

    aligned = (crop_n % SEG_LEN == 0)
    results_cw6.append((crop_n, plain_ok, sync_ok))

    p_str = "SONG SOT" if plain_ok else "GUC NGA "
    s_str = "SONG SOT" if sync_ok  else "GUC NGA "
    hint = f"(boi so {SEG_LEN})" if aligned else f"(du {crop_n % SEG_LEN} so voi boi so {SEG_LEN})"
    print(f"    crop={crop_n:<6} | Plain:[{p_str}] | Sync:[{s_str}] | {hint}")
    print("-"*65)

if not results_cw6:
    print("[!] Chua nhap crop nao.")
    sys.exit(0)

# ── Cau hoi rut ra quy luat ────────────────────────────────
print()
print("="*65)
print("[*] BUOC 2: RUT RA QUY LUAT")
print("="*65)
print()
print("Khi nao Sync song sot ma Plain thi khong?")
print("  A. Khi crop_n < 1000")
print("  B. Khi crop_n la boi so cua SEG_LEN (4096)")
print("  C. Khi crop_n chan")
print("  D. Khong co quy luat, ngau nhien")
print()
ans_rule = input("[?] Chon dap an (A/B/C/D): ").strip().upper()
rule_ok = (ans_rule == 'B')

if rule_ok:
    print(f"    [+] DUNG! Sync chi hoat dong khi crop_n la BOI SO cua SEG_LEN={SEG_LEN}")
    print(f"        Vi: FFT tinh tren bloc chinh xac {SEG_LEN} mau.")
    print(f"        Neu crop_n khong aligned => bloc bi tron 2 segment => FFT sai => sync mat.")
else:
    print(f"    [-] Chua dung. Dap an la B.")
    print(f"        Thu lai voi crop_n = 4096, 8192, 12288 (boi so SEG_LEN) => Sync luon OK.")
    print(f"        Thu crop_n = 100, 512, 5000 (khong aligned) => Sync cung fail nhu Plain.")
print()

print("Tai sao Plain luon fail khi crop_n > 0 du la aligned?")
print("  A. Plain khong co sync, nen bat dau doc tu bin 1500 cua bloc MOI (sai vi tri)")
print("  B. Plain bi mat du lieu")
print("  C. Plain chi hoat dong tren file goc")
print("  D. Plain khong ho tro FFT")
print()
ans_plain = input("[?] Chon dap an (A/B/C/D): ").strip().upper()
plain_ok_reason = (ans_plain == 'A')

if plain_ok_reason:
    print("    [+] DUNG! Plain decoder bat dau tu S0 (bloc dau tien sau khi crop).")
    print("        S0 moi la phan AUDIO GOC, khong chua tin hieu da nhung.")
    print("        Sync decoder quet het cac segment, tim thay bloc CHUA NHUNG thuc su.")
else:
    print("    [-] Dap an A. Plain khong biet vi tri tin hieu, Sync tim duoc do co anchor.")
print()

# ── Ghi ket qua ───────────────────────────────────────────
with open("results/sync_crop.csv", "w", newline='') as f:
    writer = csv.writer(f)
    writer.writerow(["crop_n", "plain_ok", "sync_ok"])
    for row in results_cw6:
        writer.writerow(row)

with open("results/sync_analysis.txt", "w") as f:
    f.write(f"total_tests:{len(results_cw6)}\n")
    f.write(f"rule_understood:{rule_ok}\n")
    f.write(f"plain_reason_ok:{plain_ok_reason}\n")
    aligned_sync_pass = sum(1 for cn,p,s in results_cw6 if cn % SEG_LEN == 0 and cn > 0 and s)
    f.write(f"aligned_crop_sync_pass:{aligned_sync_pass}\n")

print(f"[*] Ghi: results/sync_test.txt")
print(f"[*] Ghi: results/sync_crop.csv  ({len(results_cw6)} dong)")
print(f"[*] Ghi: results/sync_analysis.txt")
print("[*] Hay chay lenh 'checkwork' de kiem tra CW5 va CW6.")
