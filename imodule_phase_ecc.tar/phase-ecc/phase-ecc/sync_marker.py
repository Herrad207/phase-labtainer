#!/usr/bin/env python3
"""
CW5 & CW6: Sync Marker - chong lech khung FFT.

Kien thuc quan trong:
  - Sync chi hoat dong khi crop la BOI SO cua SEG_LEN (4096 mau)
  - Vi FFT duoc tinh tren cung bloc [0:4096], [4096:8192],...
  - Crop khong aligned => bloc bi tron 2 segment => FFT khac => sync mat
  - Giai phap: embed sync vao NHIEU segment (S0, S1, S2, ...) 
    => crop align (cat dung 4096, 8192, ...) van tim duoc sync tu segment tiep theo
"""
import numpy as np
import scipy.io.wavfile as wavfile
import csv, os, sys

sys.path.insert(0, '.')
import encoder_lib

os.makedirs("results", exist_ok=True)
os.makedirs("output", exist_ok=True)

SEG_LEN   = 4096
START_BIN = 1500
CARRIER   = 10000000.0
SYNC_PAT  = np.array([1,0,1,0,1,1,0,1], dtype=np.uint8)  # 0xAD
SYNC_LEN  = len(SYNC_PAT)

def embed_multi_sync(input_wav, message, output_wav):
    """Nhung sync + message vao TAT CA segment de tang kha nang song sot."""
    raw = np.unpackbits(np.frombuffer(message.encode(), dtype=np.uint8))
    bits = np.concatenate([SYNC_PAT, raw])
    fs, data = wavfile.read(input_wav)
    orig = data.dtype
    if data.ndim > 1: data = data[:, 0]
    data = data.astype(np.float64)
    n = int(np.floor(len(data) / SEG_LEN))
    segs = data[:n*SEG_LEN].reshape((n, SEG_LEN))
    F = np.fft.fft(segs); M, P = np.abs(F), np.angle(F)
    # Embed vao tat ca segment
    for seg_idx in range(n):
        for i, b in enumerate(bits):
            if i >= SEG_LEN//2 - START_BIN: break
            ph = np.pi/2 if b else -np.pi/2
            P[seg_idx, START_BIN+i] = ph
            P[seg_idx, SEG_LEN-(START_BIN+i)] = -ph
            M[seg_idx, START_BIN+i] = CARRIER
            M[seg_idx, SEG_LEN-(START_BIN+i)] = CARRIER
    out = np.copy(data)
    out[:n*SEG_LEN] = np.fft.ifft(M*np.exp(1j*P)).real.flatten()
    if orig == np.int16: out = np.clip(out, -32768, 32767)
    wavfile.write(output_wav, fs, out.astype(orig))

def decode_multi_sync(stego_wav, num_chars):
    """Tim sync trong tung segment. Chi hoat dong neu crop la boi so SEG_LEN."""
    _, data = wavfile.read(stego_wav)
    if data.ndim > 1: data = data[:, 0]
    data = data.astype(np.float64)
    n = int(np.floor(len(data) / SEG_LEN))
    if n == 0: return "", False
    segs = data[:n*SEG_LEN].reshape((n, SEG_LEN))
    P = np.angle(np.fft.fft(segs))
    for si in range(n):
        sync_bits = np.array([1 if P[si, START_BIN+i] > 0 else 0
                               for i in range(SYNC_LEN)], dtype=np.uint8)
        if np.array_equal(sync_bits, SYNC_PAT):
            data_bits = np.array([1 if P[si, START_BIN+SYNC_LEN+i] > 0 else 0
                                   for i in range(num_chars*8)])
            chars = data_bits.reshape((-1,8)).dot(1 << np.arange(7,-1,-1)).astype(np.uint8)
            decoded = ''.join(chr(c) for c in chars if 32 <= c <= 126)
            return decoded, True
    return "", False

# ═══════════════════════════════════════════════════════════════
# CW5: SYNC MARKER - khong crop
# ═══════════════════════════════════════════════════════════════
message = "SECRET"
print("="*65)
print("[*] CW5: SYNC MARKER (MULTI-SEGMENT EMBED)")
print("="*65)

embed_multi_sync("input/audio_original.wav", message, "output/stego_sync.wav")
print(f"[+] Da tao: output/stego_sync.wav (sync nhung vao tat ca segment)")

decoded, found = decode_multi_sync("output/stego_sync.wav", len(message))
match = (decoded == message) and found
print(f"[+] Giai ma (khong crop): '{decoded}' | sync={found} | khop={match}")

with open("results/sync_test.txt", "w") as f:
    f.write(f"original:{message}\n")
    f.write(f"decoded:{decoded}\n")
    f.write(f"sync_found:{found}\n")
    f.write(f"match:{match}\n")

# ═══════════════════════════════════════════════════════════════
# CW6: SYNC vs CROP (crop phai la boi so SEG_LEN)
# ═══════════════════════════════════════════════════════════════
print(f"\n[*] CW6: SO SANH PLAIN vs SYNC DUOI CROP")
print("="*65)
print("[!] Chu y: crop 0/4096/8192/12288 = aligned (boi so SEG_LEN=4096)")
print("[!] Crop 512/1000/... khong aligned => ca 2 phuong phap deu fail\n")

res_p = encoder_lib.encode("input/audio_original.wav", message,
                            seg_len=SEG_LEN, start_bin=START_BIN)
encoder_lib.save_wav(res_p["output"], res_p["fs"],
                     "output/stego_plain_crop.wav", res_p["orig_dtype"])

sr_p, data_p = wavfile.read("output/stego_plain_crop.wav")
sr_s, data_s = wavfile.read("output/stego_sync.wav")

# Crop values: 0 va cac boi so SEG_LEN, them 1 truong hop khong aligned
crop_vals = [0, 4096, 8192, 12288, 20480, 512]

print(f"{'Crop N':<10} {'Plain OK':<12} {'Sync OK':<12} {'Ghi chu'}")
print("-"*55)

with open("results/sync_crop.csv", "w", newline='') as f:
    writer = csv.writer(f)
    writer.writerow(["crop_n", "plain_ok", "sync_ok"])
    for crop_n in crop_vals:
        # Plain
        attacked_p = data_p[crop_n:]
        wavfile.write("output/tmp_cp.wav", sr_p, attacked_p)
        dp = encoder_lib.decode("output/tmp_cp.wav", len(message),
                                 seg_len=SEG_LEN, start_bin=START_BIN)
        plain_ok = (dp.get("decoded","") == message)

        # Sync
        attacked_s = data_s[crop_n:]
        wavfile.write("output/tmp_cs.wav", sr_s, attacked_s)
        dec_s, found_s = decode_multi_sync("output/tmp_cs.wav", len(message))
        sync_ok = (dec_s == message) and found_s

        note = "aligned" if crop_n % SEG_LEN == 0 else "KHONG aligned"
        writer.writerow([crop_n, plain_ok, sync_ok])
        print(f"{crop_n:<10} {'True' if plain_ok else 'False':<12} "
              f"{'True' if sync_ok else 'False':<12} {note}")

print(f"\n[*] Ghi: results/sync_test.txt")
print(f"[*] Ghi: results/sync_crop.csv")
print("[*] Hay chay 'checkwork' de kiem tra CW5 va CW6.")
