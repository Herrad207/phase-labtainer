#!/bin/bash
cd $HOME

# Tao session token moi moi lan container khoi dong
# Token nay se duoc nhung vao tat ca file results
# => Ngan chan viec dung lai results cu tu session truoc
python3 -c "import uuid; print(str(uuid.uuid4())[:8])" > .lab_token
TOKEN=$(cat .lab_token)
echo "[+] Session token: $TOKEN"

# Xoa results cu de dam bao sinh vien phai lam lai
rm -rf results/ output/
mkdir -p results output

# Tao file am thanh moi
python3 setup_ecc.py

rm -f setup_ecc.py
