#!/usr/bin/env python3
"""
CW1: Mo phong truyen dan mat mat (Lossy Transmission Simulation).
Gia lap nhieu mp3-like, resample va crop de do do ben vung cua Phase Coding.
"""
import numpy as np
import scipy.io.wavfile as wavfile
import scipy.signal as signal
import encoder_lib
import csv
import os
import sys

os.makedirs("results", exist_ok=True)
os.makedirs("output", exist_ok=True)

input_file = "input/stego_standard.wav"
output_csv = "results/lossy_sim.csv"

try:
    samplerate, data = wavfile.read(input_file)
except FileNotFoundError:
    print(f"[!] Loi: Khong tim thay {input_file}. Hay chay setup_ecc.py truoc!")
    sys.exit(1)

# Cac kich ban mat mat
scenarios = [
    {
        "name": "mp3_sim_low",
        "desc": "Gia lap nen MP3 chat luong thap (nhieu manh sigma=200)",
        "action": "noise",
        "sigma": 200
    },
    {
        "name": "mp3_sim_med",
        "desc": "Gia lap nen MP3 chat luong trung binh (sigma=100)",
        "action": "noise",
        "sigma": 100
    },
    {
        "name": "resample_22050",
        "desc": "Resample: 44100 -> 22050 -> 44100 (mat tin hieu cao)",
        "action": "resample",
        "target_sr": 22050
    },
    {
        "name": "resample_16000",
        "desc": "Resample: 44100 -> 16000 -> 44100 (mat nhieu)",
        "action": "resample",
        "target_sr": 16000
    },
    {
        "name": "resample_48000",
        "desc": "Resample: 44100 -> 48000 -> 44100 (upscale roi ha)",
        "action": "resample",
        "target_sr": 48000
    },
    {
        "name": "crop_1000",
        "desc": "Cat 1000 sample dau (lech khung FFT nhe)",
        "action": "crop",
        "crop_n": 1000
    },
    {
        "name": "crop_4096",
        "desc": "Cat 4096 sample dau (mat dung 1 segment)",
        "action": "crop",
        "crop_n": 4096
    },
]

print("\n" + "=" * 65)
print("[*] CW1: MO PHONG TRUYEN DAN MAT MAT (LOSSY SIMULATION)")
print("=" * 65)

with open(output_csv, mode='w', newline='') as f:
    writer = csv.writer(f)
    writer.writerow(["scenario", "attack_type", "param", "decode_ok", "decoded_text"])

    for sc in scenarios:
        temp_file = f"output/temp_{sc['name']}.wav"
        
        if sc["action"] == "noise":
            noise = np.random.normal(0, sc["sigma"], data.shape)
            attacked = np.clip(data + noise, -32768, 32767).astype(np.int16)
            wavfile.write(temp_file, samplerate, attacked)
            param = f"sigma={sc['sigma']}"

        elif sc["action"] == "resample":
            tsr = sc["target_sr"]
            n_new = int(len(data) * tsr / samplerate)
            downsampled = signal.resample(data, n_new).astype(np.int16)
            # Resample ve lai 44100
            n_orig = int(n_new * samplerate / tsr)
            restored = signal.resample(downsampled, n_orig).astype(np.int16)
            wavfile.write(temp_file, samplerate, restored)
            param = f"via_{tsr}Hz"

        elif sc["action"] == "crop":
            attacked = data[sc["crop_n"]:]
            wavfile.write(temp_file, samplerate, attacked)
            param = f"crop={sc['crop_n']}"

        dec = encoder_lib.decode(temp_file, 6, seg_len=4096, start_bin=1500)
        decoded = dec.get("decoded", "")
        ok = (decoded == "SECRET") and (dec.get("error") is None)

        writer.writerow([sc["name"], sc["action"], param, ok, decoded])

        status = "[+] SONG SOT" if ok else "[-] GUC NGA "
        print(f"  {status} | {sc['name']:<20} | {param:<15} | '{decoded}'")

print(f"\n[*] Ket qua da luu vao: {output_csv}")
print("[*] Hay chay lenh 'checkwork' de kiem tra CW1.")
