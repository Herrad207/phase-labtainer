#!/usr/bin/env python3
"""CW4: So sanh ECC vs Plain duoi tan cong nhieu."""
import numpy as np
import scipy.io.wavfile as wavfile
import csv, os, sys

sys.path.insert(0, '.')
import encoder_lib
from hamming_ecc import encode_message_hamming, decode_message_hamming

os.makedirs("results", exist_ok=True)
os.makedirs("output", exist_ok=True)

SEG_LEN   = 4096
START_BIN = 1500
CARRIER   = 10000000.0
message   = "SECRET"

def embed_bits(input_wav, bits, output_wav):
    fs, data = wavfile.read(input_wav)
    orig = data.dtype
    if data.ndim > 1: data = data[:, 0]
    data = data.astype(np.float64)
    n = int(np.floor(len(data) / SEG_LEN))
    segs = data[:n*SEG_LEN].reshape((n, SEG_LEN))
    F = np.fft.fft(segs); M, P = np.abs(F), np.angle(F)
    for i, b in enumerate(bits):
        if i >= SEG_LEN//2 - START_BIN: break
        ph = np.pi/2 if b else -np.pi/2
        P[0, START_BIN+i] = ph; P[0, SEG_LEN-(START_BIN+i)] = -ph
        M[0, START_BIN+i] = CARRIER; M[0, SEG_LEN-(START_BIN+i)] = CARRIER
    out = np.copy(data)
    out[:n*SEG_LEN] = np.fft.ifft(M*np.exp(1j*P)).real.flatten()
    if orig == np.int16: out = np.clip(out, -32768, 32767)
    wavfile.write(output_wav, fs, out.astype(orig))
    return fs

def extract_bits(wav, n_bits):
    _, data = wavfile.read(wav)
    if data.ndim > 1: data = data[:, 0]
    data = data.astype(np.float64)
    n = int(np.floor(len(data) / SEG_LEN))
    P = np.angle(np.fft.fft(data[:n*SEG_LEN].reshape((n, SEG_LEN))))
    return np.array([1 if P[0, START_BIN+i] > 0 else 0 for i in range(n_bits)], dtype=np.uint8)

# Tao 2 file stego
res_plain = encoder_lib.encode("input/audio_original.wav", message, seg_len=SEG_LEN, start_bin=START_BIN)
encoder_lib.save_wav(res_plain["output"], res_plain["fs"], "output/stego_plain.wav", res_plain["orig_dtype"])

ecc_bits = encode_message_hamming(message)
embed_bits("input/audio_original.wav", ecc_bits, "output/stego_ecc_test.wav")

sr_p, data_p = wavfile.read("output/stego_plain.wav")
sr_e, data_e = wavfile.read("output/stego_ecc_test.wav")

sigma_list = [50, 100, 200, 500, 1000, 2000, 5000]

print("="*65)
print("[*] CW4: SO SANH ECC vs PLAIN DUOI TAN CONG NHIEU")
print("="*65)
print(f"\n{'Sigma':<8} {'Plain OK':<12} {'ECC OK':<10} {'ECC Fixed'}")
print("-"*45)

with open("results/ecc_noise.csv", "w", newline='') as f:
    writer = csv.writer(f)
    writer.writerow(["sigma", "plain_ok", "ecc_ok", "ecc_corrections"])

    for sigma in sigma_list:
        tmp = "output/tmp_noise.wav"
        # Plain
        noise = np.random.normal(0, sigma, data_p.shape)
        attacked = np.clip(data_p + noise, -32768, 32767).astype(np.int16)
        wavfile.write(tmp, sr_p, attacked)
        dp = encoder_lib.decode(tmp, len(message), seg_len=SEG_LEN, start_bin=START_BIN)
        plain_ok = (dp.get("decoded","") == message)

        # ECC
        noise_e = np.random.normal(0, sigma, data_e.shape)
        attacked_e = np.clip(data_e + noise_e, -32768, 32767).astype(np.int16)
        wavfile.write(tmp, sr_e, attacked_e)
        rec = extract_bits(tmp, len(ecc_bits))
        dec_ecc, corr = decode_message_hamming(rec, len(message))
        ecc_ok = (dec_ecc == message)

        writer.writerow([sigma, plain_ok, ecc_ok, corr])
        print(f"{sigma:<8} {'True' if plain_ok else 'False':<12} {'True' if ecc_ok else 'False':<10} {corr}")

print(f"\n[*] Ghi: results/ecc_noise.csv")
print("[*] Hay chay 'checkwork' de kiem tra CW4.")
