#!/usr/bin/env python3
"""
CW4: Tim nguong nhieu ECC - sinh vien tu nhap sigma va kham pha.

Nhiem vu:
  1. Thu cac muc sigma khac nhau, quan sat khi nao Plain fail truoc ECC
  2. Tim sigma_plain_max: sigma lon nhat Plain con decode dung
  3. Tim sigma_ecc_max:   sigma lon nhat ECC con decode dung
  4. Giai thich: tai sao ECC chiu duoc nhieu tot hon Plain
"""
import numpy as np
import scipy.io.wavfile as wavfile
import csv, os, sys

sys.path.insert(0, '.')
import encoder_lib
from hamming_lib import encode_message_hamming, decode_message_hamming

os.makedirs("results", exist_ok=True)
os.makedirs("output", exist_ok=True)

SEG_LEN   = 4096
START_BIN = 1500
CARRIER   = 10000000.0
message   = "SECRET"

# ── Ham noi bo ──────────────────────────────────────────────
def embed_bits(input_wav, bits, output_wav):
    fs, data = wavfile.read(input_wav)
    orig = data.dtype
    if data.ndim > 1: data = data[:, 0]
    data = data.astype(np.float64)
    n = int(np.floor(len(data) / SEG_LEN))
    segs = data[:n*SEG_LEN].reshape((n, SEG_LEN))
    F = np.fft.fft(segs); M, P = np.abs(F), np.angle(F)
    for i, b in enumerate(bits):
        if i >= SEG_LEN//2 - START_BIN: break
        ph = np.pi/2 if b else -np.pi/2
        P[0, START_BIN+i] = ph; P[0, SEG_LEN-(START_BIN+i)] = -ph
        M[0, START_BIN+i] = CARRIER; M[0, SEG_LEN-(START_BIN+i)] = CARRIER
    out = np.copy(data)
    out[:n*SEG_LEN] = np.fft.ifft(M*np.exp(1j*P)).real.flatten()
    if orig == np.int16: out = np.clip(out, -32768, 32767)
    wavfile.write(output_wav, fs, out.astype(orig))
    return fs

def extract_bits(wav, n_bits):
    _, data = wavfile.read(wav)
    if data.ndim > 1: data = data[:, 0]
    data = data.astype(np.float64)
    n = int(np.floor(len(data) / SEG_LEN))
    P = np.angle(np.fft.fft(data[:n*SEG_LEN].reshape((n, SEG_LEN))))
    return np.array([1 if P[0, START_BIN+i] > 0 else 0 for i in range(n_bits)], dtype=np.uint8)

def test_sigma(sigma, data_plain, sr_plain, data_ecc, sr_ecc, ecc_bits):
    tmp = "output/tmp_noise_cw4.wav"
    # Plain
    noise = np.random.normal(0, sigma, data_plain.shape)
    wavfile.write(tmp, sr_plain, np.clip(data_plain+noise,-32768,32767).astype(np.int16))
    dp = encoder_lib.decode(tmp, len(message), seg_len=SEG_LEN, start_bin=START_BIN)
    plain_ok = (dp.get("decoded","") == message)
    # ECC
    noise_e = np.random.normal(0, sigma, data_ecc.shape)
    wavfile.write(tmp, sr_ecc, np.clip(data_ecc+noise_e,-32768,32767).astype(np.int16))
    rec = extract_bits(tmp, len(ecc_bits))
    dec_ecc, corr = decode_message_hamming(rec, len(message))
    ecc_ok = (dec_ecc == message)
    return plain_ok, ecc_ok, corr

# ── Tao stego ───────────────────────────────────────────────
res_p = encoder_lib.encode("input/audio_original.wav", message, seg_len=SEG_LEN, start_bin=START_BIN)
encoder_lib.save_wav(res_p["output"], res_p["fs"], "output/stego_plain.wav", res_p["orig_dtype"])
ecc_bits = encode_message_hamming(message)
embed_bits("input/audio_original.wav", ecc_bits, "output/stego_ecc_cw4.wav")

sr_p, data_p = wavfile.read("output/stego_plain.wav")
sr_e, data_e = wavfile.read("output/stego_ecc_cw4.wav")

# ── Giao dien sinh vien ─────────────────────────────────────
print("\n" + "="*65)
print("[*] CW4: TIM NGUONG NHIEU - PLAIN vs ECC (PHASE CODING)")
print("="*65)
print(f"[-] 2 file stego da san:")
print(f"    output/stego_plain.wav   -- Phase coding thuan (khong ECC)")
print(f"    output/stego_ecc_cw4.wav -- Phase coding + Hamming(7,4)")
print(f"[-] Nhap sigma de test ca 2 phuong phap voi cung muc nhieu.")
print(f"[-] Muc tieu: Tim sigma_plain_max va sigma_ecc_max (nguong con decode dung).")
print(f"[-] Go 'q' khi xong, roi nhap nguong ban tim duoc.")
print("="*65 + "\n")

results = []

while True:
    user_input = input("[?] Nhap Sigma (so duong, hoac 'q' de ket thuc): ").strip()

    if user_input.lower() in ['q', 'quit', 'exit']:
        break
    if not user_input:
        continue
    try:
        sigma = float(user_input)
        if sigma < 0:
            print("    [!] Sigma phai duong!\n"); continue
    except ValueError:
        print("    [!] Nhap so hop le!\n"); continue

    plain_ok, ecc_ok, corr = test_sigma(sigma, data_p, sr_p, data_e, sr_e, ecc_bits)
    results.append((sigma, plain_ok, ecc_ok, corr))

    p_str = "SONG SOT" if plain_ok else "GUC NGA "
    e_str = "SONG SOT" if ecc_ok   else "GUC NGA "
    print(f"    sigma={sigma:<8.0f} | Plain: [{p_str}] | ECC: [{e_str}] (sua {corr} nibble)")
    print("-"*65)

if not results:
    print("[!] Chua nhap sigma nao. Thoat.")
    sys.exit(0)

# ── Nhap nguong ─────────────────────────────────────────────
print()
print("="*65)
print("[*] BUOC 2: NHAP NGUONG BAN TIM DUOC")
print("="*65)
print("    (Nguong = sigma lon nhat ma phuong phap do con giai ma DUNG)")
print()

while True:
    try:
        sigma_plain_max = float(input("[?] sigma_plain_max (Plain con ok): "))
        break
    except ValueError:
        print("    [!] Nhap so!")

while True:
    try:
        sigma_ecc_max = float(input("[?] sigma_ecc_max   (ECC con ok):   "))
        break
    except ValueError:
        print("    [!] Nhap so!")

# ── Giai thich ─────────────────────────────────────────────
print()
print("="*65)
print("[*] BUOC 3: GIAI THICH")
print("="*65)
print("Tai sao ECC chiu duoc nhieu tot hon Plain?")
print("  A. Vi ECC dung carrier_mag lon hon")
print("  B. Vi ECC co the sua 1 bit loi trong moi 7-bit block")
print("  C. Vi ECC nhung o tan so cao hon")
print("  D. Vi ECC dung nhieu segment hon")
print()
ans = input("[?] Chon dap an (A/B/C/D): ").strip().upper()
explain_ok = (ans == 'B')
if explain_ok:
    print("    [+] DUNG! Hamming(7,4) sua duoc 1 bit flip/block")
    print("        Nhieu nhe => it bit flip => ECC tu sua => decode dung")
    print("        Nhieu manh => nhieu bit flip / block => ECC qua tai => fail")
else:
    print("    [-] Dap an B moi dung.")
    print("        ECC sua 1 bit loi/block, Plain khong co co che sua loi nao.")
print()

# ── Ghi ket qua ─────────────────────────────────────────────
import os as _os
_write_header = not _os.path.exists("results/ecc_noise.csv") or _os.path.getsize("results/ecc_noise.csv") == 0
with open("results/ecc_noise.csv", "a", newline='') as f:
    writer = csv.writer(f)
    if _write_header:
        writer.writerow(["sigma", "plain_ok", "ecc_ok", "ecc_corrections"])
    for s, p, e, c in sorted(results, key=lambda x: x[0]):
        writer.writerow([s, p, e, c])

with open("results/ecc_noise_analysis.txt", "w") as f:
    f.write(f"total_tests:{len(results)}\n")
    f.write(f"sigma_plain_max_claimed:{sigma_plain_max}\n")
    f.write(f"sigma_ecc_max_claimed:{sigma_ecc_max}\n")
    f.write(f"ecc_better_than_plain:{sigma_ecc_max >= sigma_plain_max}\n")
    f.write(f"explain_ok:{explain_ok}\n")

print(f"[*] Ghi: results/ecc_noise.csv ({len(results)} dong)")
print(f"[*] Ghi: results/ecc_noise_analysis.txt")
print("[*] Hay chay lenh 'checkwork' de kiem tra CW4.")
