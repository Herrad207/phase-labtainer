#!/usr/bin/env python3
"""
CW6: Key-based Embedding - SHA256(password) -> PRNG -> chon segment.

Demo ro rang: dung key -> giai ma dung, sai key -> rac.
"""
import numpy as np
import hashlib, os, sys

sys.path.insert(0, '.')
from spread_lib import spread_encode, spread_decode, key_to_seg_order

os.makedirs("results", exist_ok=True)
os.makedirs("output", exist_ok=True)

message    = "SECRET"
bits       = np.unpackbits(np.frombuffer(message.encode(), dtype=np.uint8))
correct_pw = "mykey123"
wrong_pws  = ["wrongkey", "password", "12345678", "hacker01"]

print("\n" + "="*65)
print("[*] CW6: KEY-BASED EMBEDDING (SHA256 + PRNG)")
print("="*65)
print("[-] SHA256(password) -> seed -> numpy RandomState -> chon segment")
print()

# Hien thi co che
seed_bytes = hashlib.sha256(correct_pw.encode()).digest()
seed       = int.from_bytes(seed_bytes[:8], 'big') % (2**31)
rng        = np.random.RandomState(seed)

print("[*] VI DU CO CHE:")
print(f"    password        = '{correct_pw}'")
print(f"    SHA256(password) = {seed_bytes.hex()[:32]}...")
print(f"    seed (64-bit)   = {seed}")

# Lay so segment tu audio
import scipy.io.wavfile as wavfile
_, data = wavfile.read("input/audio_original.wav")
n_segs = len(data) // 4096

segs_chosen = key_to_seg_order(correct_pw, n_segs, 6)
print(f"    Segment duoc chon (trong {n_segs} seg): {segs_chosen.tolist()}")
print()

# Encode
print("[*] Dang encode voi key...")
res = spread_encode("input/audio_original.wav", bits,
                    "output/stego_keyed.wav", password=correct_pw)
print(f"[+] Da tao: output/stego_keyed.wav")
print(f"    Segment thuc te dung: {res['segments_used']}")
print()

# Decode voi nhieu key khac nhau
print("[*] KIEM TRA DECODE VOI CAC KEY KHAC NHAU:")
print()
print(f"  {'Password':<16} {'Decoded':<12} {'Khop?':<8} {'Nhan xet'}")
print("  " + "-"*55)

results = {}
for pw in [correct_pw] + wrong_pws:
    dec = spread_decode("output/stego_keyed.wav", len(bits), password=pw)
    match = (dec["decoded"] == message)
    note = "<<< DUNG KEY" if pw == correct_pw else ""
    print(f"  {repr(pw):<16} {repr(dec['decoded']):<12} {str(match):<8} {note}")
    results[pw] = {"decoded": dec["decoded"], "match": match}

dec_correct = results[correct_pw]
dec_wrong   = results[wrong_pws[0]]

print()
print(f"  [i] Dung key '{correct_pw}' => '{dec_correct['decoded']}' (khop: {dec_correct['match']})")
print(f"  [i] Sai key  => rac, vi doc SAI segment => bit ngau nhien")
print(f"  [i] Khong gian key SHA256 = 2^256 ~ 10^77 => brute force bat kha thi")

# Ghi ket qua
with open("results/keyed.txt", "w") as f:
    f.write(f"password:{correct_pw}\n")
    f.write(f"correct_key_decoded:{dec_correct['decoded']}\n")
    f.write(f"correct_key_match:{dec_correct['match']}\n")
    f.write(f"wrong_key_decoded:{dec_wrong['decoded']}\n")
    f.write(f"wrong_key_match:{dec_wrong['match']}\n")

print(f"\n[*] Ghi: results/keyed.txt")
print("[*] Hay chay lenh 'checkwork' de kiem tra CW6.\n")
