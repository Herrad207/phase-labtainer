#!/usr/bin/env python3
"""
CW6: Key-based Embedding - dung SHA256(password) -> PRNG -> chon segment.
Sinh vien hieu tai sao key-based an toan hon sequential.
"""
import numpy as np
import hashlib, os, sys

sys.path.insert(0, '.')
from spread_lib import spread_encode, spread_decode

os.makedirs("results", exist_ok=True)
os.makedirs("output", exist_ok=True)

message = "SECRET"
bits = np.unpackbits(np.frombuffer(message.encode(), dtype=np.uint8))
correct_pw = "mykey123"
wrong_pw   = "wrongkey"

print("="*65)
print("[*] CW6: KEY-BASED EMBEDDING (SHA256 + PRNG)")
print("="*65)
print("Thay vi dung S0,S1,...,S5 (sequential), key-based dung")
print("SHA256(password) -> seed -> PRNG -> chon segment ngau nhien.")
print()

# Giai thich co che
print("-"*65)
print("CO CHE KEY-BASED:")
print("  seed_bytes = SHA256(password)")
print("  seed = int.from_bytes(seed_bytes[:8], 'big')")
print("  rng = np.random.RandomState(seed)")
print("  seg_indices = rng.choice(n_segs, size=n_chunks, replace=False)")
print()
print("Vi du voi password='mykey123':")
seed_bytes = hashlib.sha256(correct_pw.encode()).digest()
seed = int.from_bytes(seed_bytes[:8], 'big') % (2**31)
rng = np.random.RandomState(seed)
example_indices = np.sort(rng.choice(21, size=6, replace=False))
print(f"  SHA256 = {seed_bytes.hex()[:16]}...")
print(f"  seed   = {seed}")
print(f"  Segment duoc chon (trong 21 seg): {example_indices.tolist()}")
print()

# Cau hoi nhan thuc
print("-"*65)
print("BAI 1: Neu attacker khong biet password, ho co the decode duoc khong?")
print("  A. Co - ho chi can thu tat ca N! permutation cua segment")
print("  B. Khong - khong gian key SHA256 la 2^256, khong the brute force")
print("  C. Co - segment vi tri la co dinh nen de doan")
print("  D. Khong biet")
print()
ans1 = input("[?] Chon dap an (A/B/C/D): ").strip().upper()
ok1 = (ans1 == 'B')
if ok1:
    print("    [+] DUNG! SHA256 cho 2^256 key space - khong the brute force.")
else:
    print("    [-] Dap an B. SHA256 = 256-bit key space = 1.15 x 10^77 kha nang.")
print()

# Thuc hanh
print("="*65)
print("[*] THUC HANH: ENCODE + DECODE VOI DUNG/SAI KEY")
print("="*65)

# Encode voi correct key
res = spread_encode("input/audio_original.wav", bits,
                    "output/stego_keyed.wav", password=correct_pw)
if res.get("error"):
    print(f"[-] Loi encode: {res['error']}"); sys.exit(1)
print(f"[+] Encode voi password='{correct_pw}'")
print(f"    Segment duoc chon: {res['segments_used']}")
print()

# Decode dung key
dec_correct = spread_decode("output/stego_keyed.wav", len(bits), password=correct_pw)
match_correct = (dec_correct["decoded"] == message)
print(f"[+] Decode voi key DUNG '{correct_pw}': '{dec_correct['decoded']}' | Khop: {match_correct}")

# Decode sai key
dec_wrong = spread_decode("output/stego_keyed.wav", len(bits), password=wrong_pw)
match_wrong = (dec_wrong["decoded"] == message)
print(f"[+] Decode voi key SAI  '{wrong_pw}': '{dec_wrong['decoded']}' | Khop: {match_wrong}")

# Cau hoi su kien
print()
print("-"*65)
print("BAI 2: Dung sai key decode ra chuoi ngau nhien.")
print("Chuoi nay co phai la plain text khong? Tai sao?")
print("  A. Co - PRNG co the tinh ra dung ky tu")
print("  B. Khong - doc sai segment -> bit ngau nhien -> ky tu ASCII ngau nhien")
print("  C. Phu thuoc vao noi dung audio")
print()
ans2 = input("[?] Chon dap an (A/B/C/D): ").strip().upper()
ok2 = (ans2 == 'B')
if ok2:
    print("    [+] DUNG! Sai key -> doc sai vi tri -> bit ngau nhien -> rac.")
else:
    print("    [-] Dap an B. Sai key chon sai segment -> bit doc la nhieu.")
print()

with open("results/keyed.txt", "w") as f:
    f.write(f"password:{correct_pw}\n")
    f.write(f"correct_key_decoded:{dec_correct['decoded']}\n")
    f.write(f"correct_key_match:{match_correct}\n")
    f.write(f"wrong_key_decoded:{dec_wrong['decoded']}\n")
    f.write(f"wrong_key_match:{match_wrong}\n")
    f.write(f"bai1_ok:{ok1}\n")
    f.write(f"bai2_ok:{ok2}\n")

print(f"[*] Ghi: results/keyed.txt")
print("[*] Hay chay 'checkwork' de kiem tra CW6.")
