#!/usr/bin/env python3
"""
CW6: Key-based Embedding - SHA256 + PRNG permutation.

Sinh vien tu nhap password, quan sat:
  - Dung password -> decode dung
  - Sai password  -> decode sai/rac
"""
import numpy as np
import os, sys

sys.path.insert(0, '.')
import keyed_lib

os.makedirs("results", exist_ok=True)
os.makedirs("output", exist_ok=True)

message  = "SECRET"
PASSWORD = "mykey123"

print("=" * 60)
print("[*] CW6: KEY-BASED EMBEDDING")
print("=" * 60)
print(f"[-] Co che: SHA256(password) -> seed -> permutation cua {keyed_lib.MAX_BINS} bin")
print(f"[-] Bit i nhung vao bin permutation[i] thay vi bin START_BIN+i")
print(f"[-] Khong biet password -> khong biet vi tri bit -> decode sai")
print()

# Encode voi password co dinh
res = keyed_lib.keyed_encode("input/audio_original.wav", message, "output/stego_keyed.wav", PASSWORD)
if res["error"]:
    print(f"[-] Loi encode: {res['error']}"); sys.exit(1)
print(f"[+] Da encode '{message}' voi password='{PASSWORD}'")
print()

# ── Buoc 1: Decode voi dung password ─────────────────────────
print("-" * 60)
print("BUOC 1: Decode voi DUNG password")
print("-" * 60)
user_pwd = input(f"[?] Nhap password de decode (goi y: '{PASSWORD}'): ").strip()
d_correct = keyed_lib.keyed_decode("output/stego_keyed.wav", len(message), user_pwd)
match_correct = (d_correct.get("decoded","") == message) and (user_pwd == PASSWORD)
print(f"[+] Password='{user_pwd}' -> Decode: '{d_correct.get('decoded','')}' | Khop: {d_correct.get('decoded','') == message}")
print()

# ── Buoc 2: Sinh vien tu nhap sai password ────────────────────
print("-" * 60)
print("BUOC 2: Decode voi SAI password")
print("-" * 60)
print(f"(Password dung la '{PASSWORD}' - hay nhap bat ky password sai nao)")
wrong_pwd = input("[?] Nhap mot password SAI: ").strip()
if not wrong_pwd: wrong_pwd = "wrongkey"
d_wrong = keyed_lib.keyed_decode("output/stego_keyed.wav", len(message), wrong_pwd)
match_wrong = (d_wrong.get("decoded","") == message)
print(f"[+] Password='{wrong_pwd}' -> Decode: '{d_wrong.get('decoded','')}' | Khop: {match_wrong}")
print()

# ── Cau hoi ly thuyet ─────────────────────────────────────────
print("-" * 60)
print("Cau hoi: Tai sao sai password lai decode ra ky tu rac?")
print("  A. File bi hu hong")
print("  B. Sai password tao permutation khac -> doc sai bin -> phase ngau nhien -> ky tu rac")
print("  C. He thong tu xoa tin nhan")
print("  D. AES encryption bi loi")
print()
ans = input("[?] Chon (A/B/C/D): ").strip().upper()
q_ok = (ans == 'B')
if q_ok:
    print("    [+] DUNG! Permutation khac -> doc phase o sai vi tri -> bit ngau nhien -> ASCII rac")
else:
    print("    [-] Dap an B. Permutation phu thuoc vao password via SHA256.")
print()

# ── Ghi ket qua ──────────────────────────────────────────────
with open("results/keyed.txt", "w") as f:
    f.write(f"password_used:{PASSWORD}\n")
    f.write(f"correct_key_decoded:{d_correct.get('decoded','')}\n")
    f.write(f"correct_key_match:{d_correct.get('decoded','') == message}\n")
    f.write(f"wrong_key_tried:{wrong_pwd}\n")
    f.write(f"wrong_key_decoded:{d_wrong.get('decoded','')}\n")
    f.write(f"wrong_key_match:{match_wrong}\n")
    f.write(f"concept_ok:{q_ok}\n")

print(f"[*] Ghi: results/keyed.txt")
print("[*] Hay chay 'checkwork' de kiem tra CW6.")
