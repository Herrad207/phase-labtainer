"""
keyed_lib.py - Key-based embedding dung SHA256 + PRNG.
Bit i duoc nhung vao bin permutation[i] thay vi bin START_BIN+i.
"""
import numpy as np
import scipy.io.wavfile as wavfile
import hashlib

SEG_LEN   = 4096
START_BIN = 1500
CARRIER   = 10000000.0
MAX_BINS  = SEG_LEN // 2 - START_BIN - 1   # so bin kha dung


def key_to_permutation(password, n_bits):
    """
    SHA256(password) -> seed -> numpy PRNG -> permutation cua n_bits vi tri.
    Permutation[i] = offset tu START_BIN -> bin thuc te = START_BIN + permutation[i]
    """
    digest = hashlib.sha256(password.encode('utf-8')).hexdigest()
    seed = int(digest[:8], 16)  # 32-bit seed tu 8 hex dau
    rng = np.random.RandomState(seed)
    perm = rng.permutation(MAX_BINS)[:n_bits]
    return perm


def keyed_encode(input_wav, message, output_wav, password):
    """
    Encode voi key: bit i nhung vao bin (START_BIN + permutation[i]).
    Chi nhung vao S0 (segment 0) - key bao ve bang bin permutation.
    """
    fs, data = wavfile.read(input_wav)
    orig_dtype = data.dtype
    if data.ndim > 1: data = data[:, 0]
    data = data.astype(np.float64)

    bits = np.unpackbits(np.frombuffer(message.encode('utf-8'), dtype=np.uint8))
    n_bits = len(bits)

    if n_bits > MAX_BINS:
        return {"error": f"Tin nhan qua dai ({n_bits} bit > {MAX_BINS})", "output": None}

    perm = key_to_permutation(password, n_bits)
    n_segs = int(np.floor(len(data) / SEG_LEN))

    segs = data[:n_segs * SEG_LEN].reshape((n_segs, SEG_LEN))
    F = np.fft.fft(segs)
    M, P = np.abs(F), np.angle(F)

    for i, b in enumerate(bits):
        bin_offset = int(perm[i])
        bin_idx = START_BIN + bin_offset
        if bin_idx >= SEG_LEN // 2: continue
        ph = np.pi / 2 if b else -np.pi / 2
        P[0, bin_idx] = ph
        P[0, SEG_LEN - bin_idx] = -ph
        M[0, bin_idx] = CARRIER
        M[0, SEG_LEN - bin_idx] = CARRIER

    out = np.copy(data)
    out[:n_segs * SEG_LEN] = np.fft.ifft(M * np.exp(1j * P)).real.flatten()
    if orig_dtype == np.int16:
        out = np.clip(out, -32768, 32767)
    wavfile.write(output_wav, fs, out.astype(orig_dtype))
    return {"error": None, "output": out, "fs": fs, "orig_dtype": orig_dtype}


def keyed_decode(stego_wav, num_chars, password):
    """Decode voi key: doc phase tai cac bin theo permutation."""
    fs, data = wavfile.read(stego_wav)
    if data.ndim > 1: data = data[:, 0]
    data = data.astype(np.float64)

    n_bits = num_chars * 8
    perm = key_to_permutation(password, n_bits)
    n_segs = int(np.floor(len(data) / SEG_LEN))
    if n_segs == 0:
        return {"error": "Audio qua ngan", "decoded": ""}

    P = np.angle(np.fft.fft(
        data[:n_segs * SEG_LEN].reshape((n_segs, SEG_LEN))
    ))

    bits = []
    for i in range(n_bits):
        bin_idx = START_BIN + int(perm[i])
        if bin_idx >= SEG_LEN // 2:
            bits.append(0)
            continue
        bits.append(1 if P[0, bin_idx] > 0 else 0)

    bits_arr = np.array(bits, dtype=np.uint8)
    chars = bits_arr.reshape((-1, 8)).dot(1 << np.arange(7, -1, -1)).astype(np.uint8)
    decoded = ''.join(chr(c) for c in chars if 32 <= c <= 126)
    return {"error": None, "decoded": decoded}
