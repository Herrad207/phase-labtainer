#!/usr/bin/env python3
"""
CW4: Spread vs S0-only duoi Crop Attack.

Nhap crop_n -> xem ca hai phuong phap song sot hay guc nga.
Giong crop_attack.py (Lab 10) nhung co them cot spread_ok.
"""
import numpy as np
import scipy.io.wavfile as wavfile
import csv, os, sys

sys.path.insert(0, '.')
from encoder_lib import encode, decode, save_wav
from spread_lib import spread_encode, spread_decode, _read_wav

os.makedirs("results", exist_ok=True)
os.makedirs("output", exist_ok=True)

message = "SECRET"
bits    = np.unpackbits(np.frombuffer(message.encode(), dtype=np.uint8))
output_csv = "results/spread_crop.csv"

# Tao 2 file stego
res_s0 = encode("input/audio_original.wav", message, seg_len=4096, start_bin=1500)
save_wav(res_s0["output"], res_s0["fs"],
         "output/stego_s0_crop.wav", res_s0["orig_dtype"])

res_sp = spread_encode("input/audio_original.wav", bits,
                       "output/stego_spread_crop.wav")

fs, data_s0, _ = _read_wav("output/stego_s0_crop.wav")
_, data_sp, _  = _read_wav("output/stego_spread_crop.wav")

# Khoi tao CSV
with open(output_csv, "w", newline='') as f:
    csv.writer(f).writerow(["crop_n", "s0only_ok", "spread_ok"])

print("\n" + "="*65)
print("[*] CW4: SPREAD vs S0-ONLY DUOI CROP ATTACK")
print("="*65)
print(f"[-] 2 file stego da san:")
print(f"    output/stego_s0_crop.wav   -- S0-only (48 bit trong S0)")
print(f"    output/stego_spread_crop.wav -- Spread (8 bit/segment, S0-S5)")
print()
print("[-] Nhap so mau muon cat bo o dau file de test ca 2 phuong phap.")
print("[-] Goi y thu: 0 / 1000 / 4096 / 8192 / 12288 / 24576 / 25000")
print("[-] Go 'q' de thoat.")
print("="*65 + "\n")

while True:
    user_input = input("[?] Nhap crop_n (so mau cat dau): ").strip()

    if user_input.lower() in ['q', 'quit', 'exit']:
        print("\n[*] Da thoat. Hay chay lenh 'checkwork'.\n")
        break
    if not user_input:
        continue
    try:
        crop_n = int(user_input)
        if crop_n < 0:
            print("    [!] crop_n phai >= 0!\n"); continue
    except ValueError:
        print("    [!] Nhap so nguyen!\n"); continue

    # S0-only
    attacked_s0 = data_s0[crop_n:]
    if len(attacked_s0) < 4096:
        print("    [!] Cat qua nhieu, khong du 1 segment!\n"); continue
    wavfile.write("output/tmp_s0_crop.wav", fs, attacked_s0)
    dec_s0 = decode("output/tmp_s0_crop.wav", len(message),
                    seg_len=4096, start_bin=1500)
    s0_ok = (dec_s0.get("decoded","") == message)

    # Spread
    attacked_sp = data_sp[crop_n:]
    wavfile.write("output/tmp_sp_crop.wav", fs, attacked_sp)
    dec_sp = spread_decode("output/tmp_sp_crop.wav", len(bits))
    sp_ok  = (dec_sp["decoded"] == message)

    # Ghi CSV (append)
    with open(output_csv, "a", newline='') as f:
        csv.writer(f).writerow([crop_n, s0_ok, sp_ok])

    # In ket qua
    segs_lost = crop_n // 4096
    s0_str = "[+] SONG SOT" if s0_ok  else "[-] GUC NGA "
    sp_str = "[+] SONG SOT" if sp_ok  else "[-] GUC NGA "
    print(f"    crop={crop_n:<6} (~{segs_lost} seg bi mat)"
          f" | S0-only: {s0_str} | Spread: {sp_str}")
    remainder = crop_n % 4096
    segs_lost = crop_n // 4096

    if not s0_ok and sp_ok:
        print(f"         ^^^ Spread song sot nhung S0-only khong!")
        if crop_n < 4096 and crop_n > 0:
            print(f"             Ly do: Spread chi doc 8 bin (1500..1507) moi segment.")
            print(f"             S0-only doc 48 bin (1500..1547) - cac bin cao de bi lech phase.")
            print(f"             Lech nho ({crop_n} mau) anh huong bin cao hon bin thap.")
    elif not s0_ok and not sp_ok and crop_n > 0:
        if remainder == 0:
            print(f"         ^^^ Crop {segs_lost} segment chinh xac => lech khung FFT => ca hai guc.")
            print(f"             Spread can Sync Marker (Lab 11) de chiu duoc crop kieu nay.")
        else:
            print(f"         ^^^ Crop khong aligned ({remainder} mau le) => lech khung FFT => ca hai guc.")
    print("-"*65)

print(f"[*] Ghi: {output_csv}")
print("[*] Hay chay lenh 'checkwork' de kiem tra CW4.\n")
