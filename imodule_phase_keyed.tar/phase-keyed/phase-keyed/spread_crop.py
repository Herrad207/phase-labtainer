#!/usr/bin/env python3
"""
CW4: Spread vs S0-only duoi Crop Attack.
Sinh vien tu nhap crop_n, kham pha nguong chiu dung.
"""
import numpy as np
import scipy.io.wavfile as wavfile
import csv, os, sys

sys.path.insert(0, '.')
from encoder_lib import encode, decode, save_wav
from spread_lib import spread_encode, spread_decode, _read_wav

os.makedirs("results", exist_ok=True)
os.makedirs("output", exist_ok=True)

message = "SECRET"
bits = np.unpackbits(np.frombuffer(message.encode(), dtype=np.uint8))

# Tao 2 file stego
res_s0 = encode("input/audio_original.wav", message, seg_len=4096, start_bin=1500)
save_wav(res_s0["output"], res_s0["fs"], "output/stego_s0_crop.wav", res_s0["orig_dtype"])
spread_encode("input/audio_original.wav", bits, "output/stego_spread_crop.wav")

fs, data_s0, _ = _read_wav("output/stego_s0_crop.wav")
_, data_sp, _ = _read_wav("output/stego_spread_crop.wav")

print("="*65)
print("[*] CW4: SPREAD vs S0-ONLY DUOI CROP ATTACK (TU THU NGHIEM)")
print("="*65)
print("Spread phan tan tin vao S0, S1, S2, S3, S4, S5.")
print("Neu cat S0 (crop >= 4096 mau), S0-only mat het.")
print("Spread van con S1..S5 => co the giai ma duoc!")
print()
print("[-] NHIEM VU: Thu cac gia tri crop_n, tim nguong chiu dung")
print("    Goi y: 0, 1000, 4096, 8192, 12288, 16384, 24576")
print("[-] Go 'q' khi xong, roi tra loi cau hoi.")
print("="*65 + "\n")

results = []

while True:
    ui = input("[?] Nhap crop_n (so mau cat dau, hoac 'q'): ").strip()
    if ui.lower() in ['q', 'quit']: break
    try:
        crop_n = int(ui)
        if crop_n < 0: print("    [!] crop_n >= 0!\n"); continue
    except ValueError:
        print("    [!] Nhap so nguyen!\n"); continue

    # S0-only
    attacked_s0 = data_s0[crop_n:]
    if len(attacked_s0) == 0: print("    [!] Cat het roi!\n"); continue
    wavfile.write("output/tmp_crop_s0.wav", fs, attacked_s0)
    dec_s0 = decode("output/tmp_crop_s0.wav", len(message), seg_len=4096, start_bin=1500)
    s0_ok = (dec_s0.get("decoded","") == message)

    # Spread
    attacked_sp = data_sp[crop_n:]
    wavfile.write("output/tmp_crop_sp.wav", fs, attacked_sp)
    dec_sp = spread_decode("output/tmp_crop_sp.wav", len(bits))
    sp_ok = (dec_sp["decoded"] == message)

    results.append((crop_n, s0_ok, sp_ok))
    segs_lost = crop_n // 4096
    p = "SONG SOT" if s0_ok else "GUC NGA "
    s = "SONG SOT" if sp_ok  else "GUC NGA "
    print(f"    crop={crop_n:<6} (mat ~{segs_lost} seg) | S0:[{p}] | Spread:[{s}]")
    print("-"*65)

if not results:
    print("[!] Chua nhap crop nao."); sys.exit(0)

print()
print("="*65)
print("[*] PHAN TICH KET QUA")
print("="*65)
print("Spread song sot khi crop nhieu hon S0-only.")
print("Tai sao? Vi Spread con cac segment S1..S5 sau khi mat S0.")
print()
print("Spread bat dau fail khi crop_n >= ???")
print("  A. 4096  (cat het S0)")
print("  B. 8192  (cat S0 + S1)")
print("  C. 24576 (cat S0..S5 het, khong con segment nao)")
print("  D. 0     (bat dau fail ngay)")
print()
ans = input("[?] Chon dap an (A/B/C/D): ").strip().upper()
# Spread dung S0-S5, cat het 6 segment = 6*4096=24576 mau -> fail
ok = (ans == 'C')
if ok:
    print("    [+] DUNG! Spread dung 6 segment (S0..S5), phai cat het 6*4096=24576 mau moi fail.")
else:
    print("    [-] Chua dung. Dap an C: cat 24576 mau = cat het S0..S5 => Spread moi fail.")
print()

with open("results/spread_crop.csv", "w", newline='') as f:
    writer = csv.writer(f)
    writer.writerow(["crop_n", "s0only_ok", "spread_ok"])
    for row in results:
        writer.writerow(row)

with open("results/spread_crop_analysis.txt", "w") as f:
    f.write(f"total_tests:{len(results)}\n")
    f.write(f"analysis_ok:{ok}\n")
    spread_wins = sum(1 for _, s0, sp in results if sp and not s0)
    f.write(f"spread_wins_over_s0:{spread_wins}\n")

print(f"[*] Ghi: results/spread_crop.csv ({len(results)} dong)")
print("[*] Hay chay 'checkwork' de kiem tra CW4.")
