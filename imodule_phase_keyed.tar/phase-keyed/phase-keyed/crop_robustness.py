#!/usr/bin/env python3
"""
CW4: So sanh S0-only vs Spread duoi Crop Attack.

Sinh vien tu nhap crop_n, kham pha gia tri nao spread song sot hon S0-only.
"""
import numpy as np
import scipy.io.wavfile as wavfile
import csv, os, sys

sys.path.insert(0, '.')
import encoder_lib, spread_lib

os.makedirs("results", exist_ok=True)
os.makedirs("output", exist_ok=True)

SEG_LEN = 4096
message = "SECRET"

# Tao 2 file stego
encoder_lib.save_wav(
    encoder_lib.encode("input/audio_original.wav", message, seg_len=SEG_LEN, start_bin=1500)["output"],
    44100, "output/stego_s0_crop.wav", np.int16
)
spread_lib.spread_encode("input/audio_original.wav", message, "output/stego_spread_crop.wav", bits_per_seg=8)

sr_s0, data_s0 = wavfile.read("output/stego_s0_crop.wav")
sr_sp, data_sp = wavfile.read("output/stego_spread_crop.wav")

print("=" * 65)
print("[*] CW4: CROP ROBUSTNESS - S0-ONLY vs SPREAD")
print("=" * 65)
print(f"[-] SEG_LEN = {SEG_LEN}")
print("[-] S0-only: tin nam trong segment 0")
print("[-] Spread : tin phan tan vao nhieu segment co khoang cach deu")
print()
print("Nhiem vu: Thu cac muc crop_n, tim ra:")
print("  - S0-only fail tu crop_n = ?")
print("  - Spread fail tu crop_n = ?")
print("  - Quy luat gi quyet dinh spread song sot?")
print(f"Goi y: Thu 0, 4096, 8192, 16384, 20000, 40000, ...")
print("Go 'q' khi da hieu, roi tra loi cau hoi.")
print("=" * 65 + "\n")

results = []

while True:
    raw = input("[?] Nhap crop_n (hoac 'q'): ").strip()
    if raw.lower() in ['q', 'quit']: break
    try:
        crop_n = int(raw)
        if crop_n < 0: print("    [!] Phai >= 0"); continue
    except ValueError:
        print("    [!] Nhap so nguyen!"); continue

    # S0-only
    att_s0 = data_s0[crop_n:]
    if len(att_s0) == 0: print("    [!] Cat het roi!"); continue
    wavfile.write("output/tmp_c_s0.wav", sr_s0, att_s0)
    d_s0 = encoder_lib.decode("output/tmp_c_s0.wav", len(message), seg_len=SEG_LEN, start_bin=1500)
    s0_ok = (d_s0.get("decoded","") == message)

    # Spread
    att_sp = data_sp[crop_n:]
    wavfile.write("output/tmp_c_sp.wav", sr_sp, att_sp)
    d_sp = spread_lib.spread_decode("output/tmp_c_sp.wav", len(message), bits_per_seg=8)
    sp_ok = (d_sp.get("decoded","") == message)

    results.append((crop_n, s0_ok, sp_ok))
    aligned_s0 = (crop_n % SEG_LEN == 0)
    print(f"    crop={crop_n:<7} | S0:[{'SONG SOT' if s0_ok else 'GUC NGA '}] | Spread:[{'SONG SOT' if sp_ok else 'GUC NGA '}]"
          f"{' (aligned)' if aligned_s0 else ''}")
    print("-" * 65)

if not results:
    print("[!] Chua nhap gi."); sys.exit(0)

# Cau hoi
print()
print("=" * 65)
print("[*] CAU HOI RUT RA QUY LUAT")
print("=" * 65)
print("Khi nao Spread song sot crop ma S0-only khong?")
print("  A. Khi crop_n < SEG_LEN (S0 con nguyen)")
print("  B. Khi crop_n >= SEG_LEN nhung cac segment sau van con nguyen")
print("  C. Spread luon fail khi crop")
print("  D. Ngau nhien")
print()
ans = input("[?] Chon (A/B/C/D): ").strip().upper()
q_ok = (ans == 'B')
if q_ok:
    print("    [+] DUNG! Spread luu bit vao nhieu segment voi spacing deu.")
    print("        Crop cat S0 nhung cac segment sau (S_spacing, S_2spacing,...) van nguyen.")
    print("        Decoder tim dung cac segment do => decode duoc.")
else:
    print("    [-] Dap an B. Spread dung spacing => bit ton tai o cac segment sau S0.")

with open("results/spread_crop.csv", "w", newline='') as f:
    writer = csv.writer(f)
    writer.writerow(["crop_n", "s0only_ok", "spread_ok"])
    for row in results:
        writer.writerow(row)

with open("results/spread_crop_analysis.txt", "w") as f:
    f.write(f"total_tests:{len(results)}\n")
    f.write(f"rule_understood:{q_ok}\n")
    better = sum(1 for _,s,p in results if not s and p)
    f.write(f"cases_spread_better:{better}\n")

print(f"\n[*] Ghi: results/spread_crop.csv ({len(results)} dong)")
print("[*] Hay chay 'checkwork' de kiem tra CW4.")
