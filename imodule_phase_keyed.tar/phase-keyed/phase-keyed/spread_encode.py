#!/usr/bin/env python3
"""
CW1: Spread Spectrum Encoding - sinh vien tu chon bits_per_seg.

Nhiem vu:
  Nhung 'SECRET' vao file am thanh bang spread encoding.
  Thu 2 gia tri bits_per_seg, ghi lai so segment dung.
  Giai thich sự khac biet so voi S0-only.
"""
import numpy as np
import os, sys

sys.path.insert(0, '.')
import spread_lib

os.makedirs("results", exist_ok=True)
os.makedirs("output", exist_ok=True)

message = "SECRET"
n_bits  = len(message) * 8

print("=" * 60)
print("[*] CW1: SPREAD SPECTRUM ENCODING")
print("=" * 60)
print(f"[-] Tin nhan: '{message}' = {n_bits} bit")
print(f"[-] S0-only: tat ca {n_bits} bit vao 1 segment")
print(f"[-] Spread : phan tan bit vao nhieu segment")
print()
print("Tham so bits_per_seg = so bit/byte nhung vao MOI segment:")
print("  bits_per_seg=8  -> can ceil(48/8)=6 segment")
print("  bits_per_seg=1  -> can 48 segment (interleaving)")
print()

# ── Thu 1: sinh vien chon bits_per_seg ──────────────────────
while True:
    try:
        bps = int(input("[?] Nhap bits_per_seg (1-8): "))
        if 1 <= bps <= 8: break
        print("    [!] Nhap so tu 1 den 8!")
    except ValueError:
        print("    [!] Nhap so nguyen!")

res = spread_lib.spread_encode(
    "input/audio_original.wav", message,
    "output/stego_spread.wav", bits_per_seg=bps
)

if res["error"]:
    print(f"[-] Loi: {res['error']}")
    sys.exit(1)

dec = spread_lib.spread_decode("output/stego_spread.wav", len(message), bits_per_seg=bps)
match = (dec.get("decoded", "") == message)
print(f"[+] Encode xong: dung {res['n_groups']} segment (spacing={res['spacing']})")
print(f"[+] Decode: '{dec.get('decoded','')}' | Khop: {match}")

# ── Thu 2: auto chay bits_per_seg=8 de luu file chinh ────────
res8 = spread_lib.spread_encode(
    "input/audio_original.wav", message,
    "output/stego_spread.wav", bits_per_seg=8
)
dec8 = spread_lib.spread_decode("output/stego_spread.wav", len(message), bits_per_seg=8)
match8 = (dec8.get("decoded", "") == message)

# ── Cau hoi nhan thuc ────────────────────────────────────────
print()
print("-" * 60)
print("Cau hoi: Spread encoding giup gi so voi S0-only?")
print("  A. Giam kich thuoc file")
print("  B. Phan tan thay doi ra nhieu segment -> kho phat hien hon")
print("  C. Tang toc do encode")
print("  D. Giam so bit can nhung")
print()
ans = input("[?] Chon (A/B/C/D): ").strip().upper()
q_ok = (ans == 'B')
if q_ok:
    print("    [+] DUNG! Spread phan tan thay doi FFT ra nhieu segment")
    print("        => thay doi moi segment nho hon, kho phat hien hon steganalysis")
else:
    print("    [-] Dap an B. Spread lam giam 'vet' tren moi segment rieng le.")
print()

# ── Ghi ket qua ──────────────────────────────────────────────
with open("results/spread_basic.txt", "w") as f:
    f.write(f"message:{message}\n")
    f.write(f"bits_per_seg_chosen:{bps}\n")
    f.write(f"n_groups_used:{res['n_groups']}\n")
    f.write(f"segment_spacing:{res['spacing']}\n")
    f.write(f"decoded:{dec8.get('decoded','')}\n")
    f.write(f"match:{match8}\n")
    f.write(f"concept_ok:{q_ok}\n")

print(f"[*] Ghi: results/spread_basic.txt")
print(f"[*] Ghi: output/stego_spread.wav")
print("[*] Hay chay 'checkwork' de kiem tra CW1.")
