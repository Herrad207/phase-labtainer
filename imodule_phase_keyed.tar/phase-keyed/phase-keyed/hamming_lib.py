"""
hamming_lib.py - Thu vien Hamming(7,4) thuan tuy (khong co interactive).
Import module nay trong cac script khac thay vi hamming_ecc.py.
"""
import numpy as np

G = np.array([
    [1,0,0,0,1,1,0],[0,1,0,0,1,0,1],[0,0,1,0,0,1,1],[0,0,0,1,1,1,1]
], dtype=np.uint8)

H = np.array([
    [1,1,0,1,1,0,0],[1,0,1,1,0,1,0],[0,1,1,1,0,0,1]
], dtype=np.uint8)

SYNDROME_TABLE = {
    (0,0,0):0,(1,1,0):1,(1,0,1):2,(0,1,1):3,
    (1,1,1):4,(1,0,0):5,(0,1,0):6,(0,0,1):7,
}

def hamming_encode_nibble(data_bits):
    return (np.array(data_bits[:4],dtype=np.uint8) @ G) % 2

def hamming_decode_nibble(received_bits):
    r = np.array(received_bits[:7],dtype=np.uint8)
    syndrome = tuple((H @ r) % 2)
    error_pos = SYNDROME_TABLE.get(syndrome,0)
    corrected = False
    if error_pos > 0:
        r[error_pos-1] ^= 1; corrected = True
    return r[:4], corrected, error_pos

def encode_message_hamming(message):
    raw = np.unpackbits(np.frombuffer(message.encode('utf-8'),dtype=np.uint8))
    enc = []
    for i in range(0,len(raw),4):
        nb = raw[i:i+4]
        if len(nb)<4: nb=np.pad(nb,(0,4-len(nb)))
        enc.extend(hamming_encode_nibble(nb).tolist())
    return np.array(enc,dtype=np.uint8)

def decode_message_hamming(encoded_bits, num_chars):
    num_nibbles = num_chars*2
    dec=[]; corrections=0
    for i in range(num_nibbles):
        chunk = encoded_bits[i*7:(i+1)*7]
        if len(chunk)<7: break
        db,corr,_=hamming_decode_nibble(chunk)
        dec.extend(db.tolist())
        if corr: corrections+=1
    bits=np.array(dec[:num_chars*8],dtype=np.uint8)
    if len(bits)<num_chars*8: bits=np.pad(bits,(0,num_chars*8-len(bits)))
    chars=bits.reshape((-1,8)).dot(1<<np.arange(7,-1,-1)).astype(np.uint8)
    return ''.join(chr(c) for c in chars if 32<=c<=126), corrections
