#!/usr/bin/env python3
"""
QUIZ TONG HOP - Chay SAU KHI da hoan thanh CW1-7.

5 cau hoi rut ra tu ket qua thuc hanh.
Khong can biet dap an truoc - hay nhin lai output cac CW truoc do.
"""
import os, sys

os.makedirs("results", exist_ok=True)

# Kiem tra sinh vien da lam cac CW chua
missing = []
for f, cw in [("results/spread_basic.txt",    "CW1"),
              ("results/spread_snr.csv",       "CW2"),
              ("results/spread_capacity.txt",  "CW3"),
              ("results/spread_crop.csv",      "CW4"),
              ("results/interleave_test.csv",  "CW5"),
              ("results/keyed.txt",            "CW6"),
              ("results/keyspace.txt",         "CW7")]:
    if not os.path.exists(f):
        missing.append(cw)

if missing:
    print(f"\n[!] Ban chua hoan thanh: {', '.join(missing)}")
    print(f"    Hay chay cac script tuong ung truoc khi lam quiz.")
    print(f"    Thu tu: spread_basic.py -> spread_snr.py -> spread_capacity.py")
    print(f"            -> spread_crop.py -> interleave_test.py")
    print(f"            -> keyed_embed.py -> brute_force.py\n")
    sys.exit(1)

# Doc ket qua tu cac CW de dat cau hoi phu hop
def read_kv(path):
    d = {}
    try:
        for line in open(path):
            line = line.strip()
            if ':' in line:
                k, v = line.split(':', 1)
                d[k.strip()] = v.strip()
    except: pass
    return d

snr_data = {}
try:
    import csv
    for row in csv.DictReader(open("results/spread_snr.csv")):
        snr_data[row['method']] = float(row['snr_db'])
except: pass

cap_data  = read_kv("results/spread_capacity.txt")
key_data  = read_kv("results/keyed.txt")
bf_data   = read_kv("results/keyspace.txt")

s0_max  = cap_data.get("s0only_max_chars", "?")
sp_max  = cap_data.get("spread_max_chars", "?")
fp_rate = bf_data.get("false_positive_rate", "?")
wrong_decoded = key_data.get("wrong_key_decoded", "?")

answers = {}

print("\n" + "="*65)
print("  QUIZ TONG HOP - LAB 13: SPREAD + KEY-BASED")
print("="*65)
print("Tra loi dua tren ket qua ban da quan sat o CW1-7.\n")

# Cau 1 - tu CW2
snr_s0 = snr_data.get('s0only', 0)
snr_sp = snr_data.get('spread', 0)
winner = "S0-only" if snr_s0 >= snr_sp else "Spread"
print("-"*65)
print(f"[Cau 1] Tu ket qua CW2:")
print(f"  S0-only SNR = {snr_s0:.2f} dB | Spread SNR = {snr_sp:.2f} dB")
print(f"  Tai sao {winner} co SNR cao hon?")
print(f"  A. Vi {winner} dung it segment hon => it mau bi anh huong")
print(f"  B. Vi {winner} dung nhieu segment hon => nang luong bien doi phan tan mong hon")
print(f"  C. SNR phu thuoc vao noi dung tin nhan, khong phu thuoc phuong phap")
print(f"  D. Vi {winner} dung carrier_mag lon hon")
print()
a1 = input("[?] Chon dap an (A/B/C/D): ").strip().upper()
answers['CW2_SNR'] = a1
correct1 = 'A' if winner == 'S0-only' else 'B'
ok1 = (a1 == correct1)
print(f"  [{'+'if ok1 else '-'}] {'DUNG' if ok1 else f'Chua dung. Dap an: {correct1}'}.")
if winner == "S0-only":
    print(f"  S0-only tap trung bien doi vao 1 segment => it mau thay doi => SNR cao hon.")
else:
    print(f"  Spread phan tan bien doi mong hon tren moi segment => SNR cao hon.")
print()

# Cau 2 - tu CW3
print("-"*65)
print(f"[Cau 2] Tu ket qua CW3:")
print(f"  S0-only dung luong thuc te = {s0_max} ky tu")
print(f"  Spread  dung luong thuc te = {sp_max} ky tu")
print(f"  Tai sao Spread chua duoc nhieu ky tu hon?")
print(f"  A. Vi Spread dung thuat toan nen tot hon")
print(f"  B. Vi Spread tan dung nhieu segment hon, moi segment chua 1 byte")
print(f"  C. Vi S0-only bi gioi han boi kich thuoc bin cua FFT")
print(f"  D. Ca B va C deu dung")
print()
a2 = input("[?] Chon dap an (A/B/C/D): ").strip().upper()
answers['CW3_CAPACITY'] = a2
ok2 = (a2 == 'D')
print(f"  [{'+'if ok2 else '-'}] {'DUNG' if ok2 else 'Chua dung. Dap an: D'}.")
print(f"  S0-only bi gioi han boi so bin trong 1 segment (= {s0_max} ky tu).")
print(f"  Spread dung {sp_max} segment x 1 byte/segment = {sp_max} ky tu.")
print()

# Cau 3 - tu CW4
print("-"*65)
print(f"[Cau 3] Tu ket qua CW4 (crop attack):")
print(f"  Spread dung S0-S5 (6 segment, moi segment = 4096 mau).")
print(f"  O muc crop nao thi Spread bat dau fail hoan toan?")
print(f"  A. crop >= 4096  (cat het S0)")
print(f"  B. crop >= 8192  (cat S0 + S1)")
print(f"  C. crop >= 24576 (cat het S0..S5)")
print(f"  D. crop >= 1     (cat bat ky mau nao cung fail)")
print()
a3 = input("[?] Chon dap an (A/B/C/D): ").strip().upper()
answers['CW4_CROP'] = a3
ok3 = (a3 == 'C')
print(f"  [{'+'if ok3 else '-'}] {'DUNG' if ok3 else 'Chua dung. Dap an: C'}.")
print(f"  Spread dung S0-S5, phai cat het 6 x 4096 = 24576 mau moi mat het tin hieu.")
print()

# Cau 4 - tu CW6
print("-"*65)
print(f"[Cau 4] Tu ket qua CW6 (key-based):")
print(f"  Decode voi sai key cho ra: '{wrong_decoded}'")
print(f"  Tai sao sai key tao ra chuoi nhu vay?")
print(f"  A. Vi PRNG bi loi khi dung sai seed")
print(f"  B. Vi sai key chon sai segment => doc bit tu vi tri sai => bit ngau nhien => ky tu rac")
print(f"  C. Vi am thanh bi nhieu trong qua trinh encode")
print(f"  D. Vi SHA256 bi va cham hash")
print()
a4 = input("[?] Chon dap an (A/B/C/D): ").strip().upper()
answers['CW6_WRONG_KEY'] = a4
ok4 = (a4 == 'B')
print(f"  [{'+'if ok4 else '-'}] {'DUNG' if ok4 else 'Chua dung. Dap an: B'}.")
print(f"  Sai key -> PRNG tao sai seed -> chon sai segment -> doc bit ngau nhien -> rac.")
print()

# Cau 5 - tu CW7 + tong hop
print("-"*65)
print(f"[Cau 5] Tu ket qua CW7 + tong hop toan lab:")
print(f"  False positive rate = {fp_rate}% sau 1000 lan thu.")
print(f"  Secure encoder cua Lab 13 ket hop nhung ky thuat nao?")
print(f"  A. Hamming ECC + Volume change")
print(f"  B. Spread Spectrum + Key-based (SHA256 + PRNG)")
print(f"  C. Sync Marker + Crop Attack")
print(f"  D. Noise Attack + Resample")
print()
a5 = input("[?] Chon dap an (A/B/C/D): ").strip().upper()
answers['CW8_SECURE'] = a5
ok5 = (a5 == 'B')
print(f"  [{'+'if ok5 else '-'}] {'DUNG' if ok5 else 'Chua dung. Dap an: B'}.")
print(f"  Lab 13 xay dung: Spread (phan tan, chong crop) + Key-based (bao mat bang SHA256).")
print()

# Ket qua tong hop
score = sum([ok1, ok2, ok3, ok4, ok5])
print("="*65)
print(f"  KET QUA QUIZ: {score}/5 cau dung")
if score == 5:
    print("  Xuat sac! Ban da hieu day du noi dung Lab 13.")
elif score >= 3:
    print("  Kha. Hay xem lai cac CW chua hieu.")
else:
    print("  Hay chay lai cac script CW va xem output truoc khi lam quiz.")
print("="*65)
print()

# Ghi ket qua
with open("results/answers.txt", "w") as f:
    for k, v in answers.items():
        f.write(f"{k}:{v}\n")
    f.write(f"score:{score}/5\n")

print(f"[*] Ghi: results/answers.txt")
print("[*] Hay chay lenh 'checkwork' de kiem tra diem.\n")
