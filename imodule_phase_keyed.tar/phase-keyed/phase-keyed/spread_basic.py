#!/usr/bin/env python3
"""
CW1: Spread Spectrum co ban - phan tan bit vao nhieu segment.

Nhiem vu: Thay vi nhung tat ca 48 bit vao S0,
          phan tan: byte 0 -> S0, byte 1 -> S1, ..., byte 5 -> S5.
          Moi segment chi chua 8 bit.
"""
import numpy as np
import scipy.io.wavfile as wavfile
import sys, os

sys.path.insert(0, '.')
from spread_lib import spread_encode, spread_decode, compute_snr

os.makedirs("results", exist_ok=True)
os.makedirs("output", exist_ok=True)

message = "SECRET"
bits = np.unpackbits(np.frombuffer(message.encode(), dtype=np.uint8))
n_bits = len(bits)

print("="*65)
print("[*] CW1: SPREAD SPECTRUM CO BAN")
print("="*65)
print(f"[-] Tin nhan: '{message}' = {n_bits} bit")
print(f"[-] S0-only: tat ca {n_bits} bit vao segment 0 (bin 1500..1547)")
print(f"[-] Spread : phan tan {n_bits//8} byte, moi byte vao 1 segment rieng")
print(f"             byte 0 -> S0 (bin 1500..1507)")
print(f"             byte 1 -> S1 (bin 1500..1507)")
print(f"             ...")
print()

# Cau hoi nhan thuc truoc khi chay
print("-"*65)
print("BAI 1: Loi ich chinh cua Spread Spectrum la gi?")
print("  A. Tang toc do ma hoa")
print("  B. Tang kha nang chong crop (mat segment dau)")
print("  C. Giam kich thuoc file")
print("  D. Tang so bit ma hoa moi segment")
print()
ans1 = input("[?] Chon dap an (A/B/C/D): ").strip().upper()
ok1 = (ans1 == 'B')
print(f"    [{'+'if ok1 else '-'}] {'DUNG' if ok1 else 'Chua dung'} - Spread phan tan tin hieu, mat 1 segment khong mat het tin")
print()

print("-"*65)
print("BAI 2: Neu audio co 21 segment (21 * 4096 mau),")
print("       spread 48 bit (6 byte) dung toi da bao nhieu segment?")
print()
ans2 = input("[?] Nhap so segment: ").strip()
try: ok2 = (int(ans2) == 6)
except: ok2 = False
print(f"    [{'+'if ok2 else '-'}] {'DUNG' if ok2 else 'Chua dung'} - 48 bit / 8 bit per seg = 6 segment")
print()

# Thuc hanh
print("="*65)
print("[*] THUC HANH: ENCODE + DECODE")
print("="*65)

res = spread_encode("input/audio_original.wav", bits, "output/stego_spread.wav")
if res["error"]:
    print(f"[-] Loi encode: {res['error']}"); sys.exit(1)

print(f"[+] Da tao: output/stego_spread.wav")
print(f"    Su dung {res['n_segs_used']} segment: {res['segments_used']}")

dec = spread_decode("output/stego_spread.wav", n_bits)
match = (dec["decoded"] == message)
print(f"[+] Giai ma: '{dec['decoded']}' | Khop: {match}")

snr, changed = compute_snr("input/audio_original.wav", "output/stego_spread.wav")
print(f"[+] SNR: {snr:.2f} dB | Mau thay doi: {changed}")

with open("results/spread_basic.txt", "w") as f:
    f.write(f"original:{message}\n")
    f.write(f"decoded:{dec['decoded']}\n")
    f.write(f"match:{match}\n")
    f.write(f"n_segs_used:{res['n_segs_used']}\n")
    f.write(f"snr:{snr:.2f}\n")
    f.write(f"bai1_ok:{ok1}\n")
    f.write(f"bai2_ok:{ok2}\n")

print(f"\n[*] Ghi: results/spread_basic.txt")
print("[*] Hay chay 'checkwork' de kiem tra CW1.")
