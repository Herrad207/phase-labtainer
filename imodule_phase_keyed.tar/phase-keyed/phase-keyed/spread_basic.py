#!/usr/bin/env python3
"""
CW1: Spread Spectrum co ban.

Thay vi nhung tat ca 48 bit vao segment 0 (S0-only),
Spread phan tan: byte 0 -> S0, byte 1 -> S1, ..., byte 5 -> S5.
Script nay tu dong chay va in bang so sanh de sinh vien quan sat.
"""
import numpy as np
import scipy.io.wavfile as wavfile
import os, sys

sys.path.insert(0, '.')
from encoder_lib import encode, decode, save_wav
from spread_lib import spread_encode, spread_decode, compute_snr

os.makedirs("results", exist_ok=True)
os.makedirs("output", exist_ok=True)

message = "SECRET"
bits = np.unpackbits(np.frombuffer(message.encode(), dtype=np.uint8))

print("\n" + "="*65)
print("[*] CW1: SPREAD SPECTRUM CO BAN")
print("="*65)
print(f"[-] Tin nhan  : '{message}' = {len(bits)} bit = {len(bits)//8} byte")
print(f"[-] S0-only   : tat ca {len(bits)} bit vao 1 segment (bin 1500..1547)")
print(f"[-] Spread    : moi byte vao 1 segment rieng")
print(f"                byte 0 (S, E) -> S0 | byte 1 (C, R) -> S1 | ...")
print("="*65 + "\n")

# ── S0-only ──────────────────────────────────────────────────────
print("[*] Dang ma hoa S0-only...")
res_s0 = encode("input/audio_original.wav", message, seg_len=4096, start_bin=1500)
save_wav(res_s0["output"], res_s0["fs"],
         "output/stego_s0only.wav", res_s0["orig_dtype"])
dec_s0 = decode("output/stego_s0only.wav", len(message),
                seg_len=4096, start_bin=1500)
snr_s0, ch_s0 = compute_snr("input/audio_original.wav", "output/stego_s0only.wav")

# ── Spread ───────────────────────────────────────────────────────
print("[*] Dang ma hoa Spread...")
res_sp = spread_encode("input/audio_original.wav", bits, "output/stego_spread.wav")
dec_sp = spread_decode("output/stego_spread.wav", len(bits))
snr_sp, ch_sp = compute_snr("input/audio_original.wav", "output/stego_spread.wav")

# ── In bang so sanh ──────────────────────────────────────────────
print()
print(f"  {'Phuong phap':<14} {'Giai ma':<10} {'Khop':<8} {'SNR':>8} {'Segment dung':>14} {'Mau doi':>10}")
print("  " + "-"*68)
print(f"  {'S0-only':<14} {repr(dec_s0['decoded']):<10} {str(dec_s0['decoded']==message):<8} {snr_s0:>7.2f}dB {'1 / nhieu'!s:>14} {ch_s0:>10,}")
print(f"  {'Spread':<14} {repr(dec_sp['decoded']):<10} {str(dec_sp['decoded']==message):<8} {snr_sp:>7.2f}dB {str(res_sp['n_segs_used'])+' / '+str(res_sp['n_segs_used']):>14} {ch_sp:>10,}")
print()
print(f"  [i] Segment Spread su dung: {res_sp['segments_used']}")
print(f"  [i] Spread phan tan tin tren {res_sp['n_segs_used']} segment rieng biet")
print(f"  [i] Ket qua: ca hai giai ma dung '{message}' => Spread hoat dong chinh xac")

# ── Ghi ket qua ──────────────────────────────────────────────────
with open("results/spread_basic.txt", "w") as f:
    f.write(f"original:{message}\n")
    f.write(f"s0only_decoded:{dec_s0['decoded']}\n")
    f.write(f"s0only_match:{dec_s0['decoded']==message}\n")
    f.write(f"spread_decoded:{dec_sp['decoded']}\n")
    f.write(f"spread_match:{dec_sp['decoded']==message}\n")
    f.write(f"spread_segs_used:{res_sp['n_segs_used']}\n")

print(f"\n[*] Ghi: results/spread_basic.txt")
print(f"[*] Ghi: output/stego_spread.wav")
print("[*] Hay chay lenh 'checkwork' de kiem tra CW1.\n")
