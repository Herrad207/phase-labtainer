#!/usr/bin/env python3
"""
CW7: Kiem tra kha nang chong brute force cua key-based encoding.
Thu 1000 password ngau nhien, dem bao nhieu cho false positive.
"""
import numpy as np
import string, random, os, sys

sys.path.insert(0, '.')
from spread_lib import spread_encode, spread_decode

os.makedirs("results", exist_ok=True)
os.makedirs("output", exist_ok=True)

message = "SECRET"
bits = np.unpackbits(np.frombuffer(message.encode(), dtype=np.uint8))
correct_pw = "mykey123"
N_KEYS = 1000

print("="*65)
print("[*] CW7: KIEM TRA CHONG BRUTE FORCE")
print("="*65)
print(f"Thu {N_KEYS} password ngau nhien 8 ky tu.")
print("False positive: decode ra >= 80% ky tu ASCII printable (32-126).")
print("Ky vong: < 10 false positive (< 1%)")
print()

# Encode voi correct key truoc
res = spread_encode("input/audio_original.wav", bits,
                    "output/stego_keyed_bf.wav", password=correct_pw)
if res.get("error"):
    print(f"[-] Loi encode: {res['error']}"); sys.exit(1)

# Cau hoi truoc khi chay
print("-"*65)
print("BAI 1: Tai sao false positive rate thap?")
print("  A. Vi moi key tao ra 1 permutation segment khac nhau")
print("     => bit doc ngau nhien => ky tu ngoai ASCII printable")
print("  B. Vi PRNG khong du ngau nhien")
print("  C. Vi 1000 key la nhieu, tat nhien se tim ra dung key")
print("  D. Vi audio co nhieu")
print()
ans1 = input("[?] Chon dap an (A/B/C/D): ").strip().upper()
ok1 = (ans1 == 'A')
if ok1:
    print("    [+] DUNG! Sai segment -> bit ngau nhien -> ~50% co ky tu ngoai printable.")
else:
    print("    [-] Dap an A. Sai key -> sai segment -> bit ngau nhien -> rac.")
print()

# Chay brute force
print("="*65)
print(f"[*] Thu {N_KEYS} password...", end="", flush=True)

charset = string.ascii_letters + string.digits
false_positives = 0
fp_examples = []

for i in range(N_KEYS):
    if i % 200 == 0: print(".", end="", flush=True)
    pw = ''.join(random.choices(charset, k=8))
    dec = spread_decode("output/stego_keyed_bf.wav", len(bits), password=pw)
    decoded = dec.get("decoded", "")
    # False positive: >= 80% ky tu ASCII printable
    if len(decoded) > 0:
        printable_ratio = sum(1 for c in decoded if 32 <= ord(c) <= 126) / len(decoded)
        # False positive chinh xac: giai ma ra dung tin nhan goc
        if decoded == message:
            false_positives += 1
            if len(fp_examples) < 3:
                fp_examples.append((pw, decoded))

print(" Done!")
fp_rate = false_positives / N_KEYS * 100
print(f"\n[+] Ket qua: {false_positives}/{N_KEYS} false positive ({fp_rate:.2f}%)")
if fp_examples:
    print(f"[+] Vi du false positive:")
    for pw, dec in fp_examples:
        print(f"    pw='{pw}' -> '{dec}'")

print()
print("-"*65)
print(f"BAI 2: {false_positives} false positive / {N_KEYS} key = {fp_rate:.2f}%.")
print("Day co phai la muc do an toan du khong cho ung dung thuc te?")
print("  A. Khong - < 1% van co nghia la cu 100 lan thu se tim ra 1 lan")
print("  B. Du - brute force key space thuc te la 2^256, 1000 key la rat it")
print("  C. Tuy thuoc ung dung")
print()
ans2 = input("[?] Chon dap an (A/B/C/D): ").strip().upper()
ok2 = (ans2 == 'B')
if ok2:
    print("    [+] DUNG! 1000/2^256 xac suat tim dung key = ~0, an toan hoan toan.")
else:
    print("    [-] Dap an B. Key space SHA256 la 2^256 nen brute force bat kha thi.")
print()

with open("results/keyspace.txt", "w") as f:
    f.write(f"total_keys_tried:{N_KEYS}\n")
    f.write(f"false_positives:{false_positives}\n")
    f.write(f"false_positive_rate:{fp_rate:.2f}\n")
    f.write(f"bai1_ok:{ok1}\n")
    f.write(f"bai2_ok:{ok2}\n")

print(f"[*] Ghi: results/keyspace.txt")
print("[*] Hay chay 'checkwork' de kiem tra CW7.")
