#!/usr/bin/env python3
"""
CW7: Kiem tra kha nang chong brute force.

Thu 1000 password ngau nhien 8 ky tu.
False positive: decode ra dung 'SECRET' (xac suat rat thap).
"""
import numpy as np
import string, random, os, sys

sys.path.insert(0, '.')
from spread_lib import spread_encode, spread_decode

os.makedirs("results", exist_ok=True)
os.makedirs("output", exist_ok=True)

message    = "SECRET"
bits       = np.unpackbits(np.frombuffer(message.encode(), dtype=np.uint8))
correct_pw = "mykey123"
N_KEYS     = 1000

print("\n" + "="*65)
print("[*] CW7: KIEM TRA CHONG BRUTE FORCE")
print("="*65)
print(f"[-] Encode '{message}' voi key='{correct_pw}'")
print(f"[-] Thu {N_KEYS} password ngau nhien 8 ky tu [a-zA-Z0-9]")
print(f"[-] Dem false positive: bao nhieu password cho ra '{message}'")
print("="*65 + "\n")

# Encode
res = spread_encode("input/audio_original.wav", bits,
                    "output/stego_keyed_bf.wav", password=correct_pw)
if res.get("error"):
    print(f"[-] Loi encode: {res['error']}"); sys.exit(1)

# Brute force
charset = string.ascii_letters + string.digits
false_positives = 0
fp_examples = []
printable_count = 0  # dem bao nhieu pw cho ky tu printable (theo doi them)

print(f"[*] Dang thu {N_KEYS} password", end="", flush=True)

for i in range(N_KEYS):
    if i % 100 == 0 and i > 0:
        print(".", end="", flush=True)

    pw  = ''.join(random.choices(charset, k=8))
    dec = spread_decode("output/stego_keyed_bf.wav", len(bits), password=pw)
    decoded = dec.get("decoded", "")

    # False positive chinh xac: decode ra dung message goc
    if decoded == message:
        false_positives += 1
        fp_examples.append(pw)

    # Theo doi phu: ky tu printable
    if len(decoded) > 0:
        ratio = sum(1 for c in decoded if 32 <= ord(c) <= 126) / len(decoded)
        if ratio >= 0.8:
            printable_count += 1

print(" Xong!")
print()

fp_rate = false_positives / N_KEYS * 100

# In ket qua chi tiet
print(f"  [+] Ket qua sau {N_KEYS} lan thu:")
print(f"      False positive (decode ra '{message}') : {false_positives} / {N_KEYS} = {fp_rate:.2f}%")
print(f"      Decode ra ky tu printable (>= 80%)     : {printable_count} / {N_KEYS} = {printable_count/N_KEYS*100:.1f}%")
print()

if fp_examples:
    print(f"  [!] Cac password tinh co the decode dung:")
    for pw in fp_examples[:5]:
        print(f"      '{pw}'")
else:
    print(f"  [+] Khong co password nao decode ra dung '{message}'")
print()
print(f"  [i] Printable cao (~{printable_count/N_KEYS*100:.0f}%) la binh thuong:")
print(f"      Khi bit ngau nhien, xac suat 1 byte nam trong [32-126] la 95/256 ~ 37%")
print(f"      Ky tu 'printable' khong co nghia la decode dung, chi la khi vo tinh cho ky tu hien thi duoc")
print(f"  [i] False positive thap ({fp_rate:.2f}%) xac nhan key-based an toan")
print(f"  [i] Key space SHA256 = 2^256 ~ 10^77, 1000 key ~ 0% cua key space")

# Ghi ket qua
with open("results/keyspace.txt", "w") as f:
    f.write(f"total_keys_tried:{N_KEYS}\n")
    f.write(f"false_positives:{false_positives}\n")
    f.write(f"false_positive_rate:{fp_rate:.2f}\n")
    f.write(f"printable_count:{printable_count}\n")

print(f"\n[*] Ghi: results/keyspace.txt")
print("[*] Hay chay lenh 'checkwork' de kiem tra CW7.\n")
