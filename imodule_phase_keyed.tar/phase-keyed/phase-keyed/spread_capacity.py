#!/usr/bin/env python3
"""CW3: So sanh capacity (dung luong toi da) giua S0-only va Spread."""
import numpy as np
import scipy.io.wavfile as wavfile
import sys, os

sys.path.insert(0, '.')
from encoder_lib import encode, decode, save_wav
from spread_lib import spread_encode, spread_decode, _read_wav, _get_n_segs

os.makedirs("results", exist_ok=True)
os.makedirs("output", exist_ok=True)

print("="*65)
print("[*] CW3: SO SANH CAPACITY - S0-ONLY vs SPREAD")
print("="*65)

# Doc thong tin file
fs, data, _ = _read_wav("input/audio_original.wav")
n_segs = _get_n_segs(data)
seg_len = 4096
start_bin = 1500
bits_per_seg = seg_len//2 - start_bin - 1

print(f"[-] File audio: {len(data)} mau, {n_segs} segment")
print(f"[-] Moi segment S0: {bits_per_seg} bit trong bin [{start_bin}..{seg_len//2-1}]")
print()

# Cau hoi tinh toan truoc
print("-"*65)
print("BAI 1: S0-ONLY capacity")
print(f"       bits_per_seg = SEG_LEN/2 - start_bin - 1 = {seg_len}//2 - {start_bin} - 1 = {bits_per_seg}")
print(f"       S0-only dung dung 1 segment => max chars = {bits_per_seg} / 8 = ???")
print()
try:
    ans1 = int(input("[?] S0-only max chars: ").strip())
    ok1 = (ans1 == bits_per_seg // 8)
except: ok1 = False; ans1 = -1
correct1 = bits_per_seg // 8
print(f"    [{'+'if ok1 else '-'}] {'DUNG' if ok1 else f'Chua dung. Dap an: {correct1}'}")
print()

print("BAI 2: SPREAD capacity")
print(f"       Spread dung {n_segs} segment, moi segment chua 8 bit (1 byte).")
print(f"       => max chars = {n_segs} ky tu")
print()
try:
    ans2 = int(input("[?] Spread max chars: ").strip())
    ok2 = (ans2 == n_segs)
except: ok2 = False; ans2 = -1
print(f"    [{'+'if ok2 else '-'}] {'DUNG' if ok2 else f'Chua dung. Dap an: {n_segs}'}")
print()

# Kiem tra thuc te - tim max chars bang cach encode tang dan
print("="*65)
print("[*] KIEM TRA THUC TE (encode tang dan, dung khi loi)")
print("="*65)

# S0-only
s0_max = 0
for n in range(1, bits_per_seg // 8 + 10):
    test_msg = "A" * n
    res = encode("input/audio_original.wav", test_msg, seg_len=seg_len, start_bin=start_bin)
    if res["error"]: break
    s0_max = n
print(f"[+] S0-only thuc te : {s0_max} ky tu")

# Spread
sp_max = 0
for n in range(1, n_segs + 5):
    test_bits = np.zeros(n * 8, dtype=np.uint8)
    res = spread_encode("input/audio_original.wav", test_bits, "/tmp/test_spread_cap.wav")
    if res.get("error"): break
    sp_max = n
print(f"[+] Spread thuc te  : {sp_max} ky tu")
print(f"[+] Tang gap: {sp_max / max(s0_max,1):.1f}x")

with open("results/spread_capacity.txt", "w") as f:
    f.write(f"n_segments:{n_segs}\n")
    f.write(f"bits_per_seg_s0:{bits_per_seg}\n")
    f.write(f"s0only_max_chars:{s0_max}\n")
    f.write(f"spread_max_chars:{sp_max}\n")
    f.write(f"ratio:{sp_max/max(s0_max,1):.1f}\n")
    f.write(f"bai1_ok:{ok1}\n")
    f.write(f"bai2_ok:{ok2}\n")

print(f"\n[*] Ghi: results/spread_capacity.txt")
print("[*] Hay chay 'checkwork' de kiem tra CW3.")
