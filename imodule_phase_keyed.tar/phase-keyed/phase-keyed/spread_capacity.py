#!/usr/bin/env python3
"""
CW3: So sanh dung luong toi da - S0-only vs Spread.

S0-only: chi dung 1 segment => bi gioi han boi so bin trong S0.
Spread : dung tat ca segment => dung luong tang ty le voi do dai audio.
"""
import numpy as np
import scipy.io.wavfile as wavfile
import os, sys

sys.path.insert(0, '.')
from encoder_lib import encode, decode, save_wav
from spread_lib import spread_encode, spread_decode, _read_wav, _get_n_segs

os.makedirs("results", exist_ok=True)
os.makedirs("output", exist_ok=True)

SEG_LEN   = 4096
START_BIN = 1500

print("\n" + "="*65)
print("[*] CW3: SO SANH DUNG LUONG - S0-ONLY vs SPREAD")
print("="*65)

# Thong tin audio
fs, data, _ = _read_wav("input/audio_original.wav")
n_segs = _get_n_segs(data)
bits_per_seg = SEG_LEN // 2 - START_BIN - 1

print(f"[-] File audio  : {len(data):,} mau = {n_segs} segment ({len(data)/fs:.1f} giay)")
print(f"[-] Moi segment : {bits_per_seg} bit trong bin [{START_BIN}..{SEG_LEN//2-1}]")
print()

# Ly thuyet
print("[*] TINH TOAN LY THUYET:")
s0_theory = bits_per_seg // 8
sp_theory = n_segs  # 8 bit/segment = 1 byte/segment
print(f"  S0-only : {bits_per_seg} bit / 8 = {s0_theory} ky tu")
print(f"  Spread  : {n_segs} segment x 1 byte/segment = {sp_theory} ky tu")
print()

# Kiem tra thuc te - encode tang dan
print("[*] KIEM TRA THUC TE (encode tang dan den khi loi)...")

s0_actual = 0
for n in range(1, s0_theory + 10):
    res = encode("input/audio_original.wav", "A"*n,
                 seg_len=SEG_LEN, start_bin=START_BIN)
    if res["error"]: break
    dec = decode("output/stego_cap_test.wav" if False else "/dev/null", n,
                 seg_len=SEG_LEN, start_bin=START_BIN)
    s0_actual = n
    if n % 10 == 0: print(f"    S0-only: {n} ky tu OK...", end="\r")

print(f"  [+] S0-only thuc te : {s0_actual} ky tu" + " "*20)

sp_actual = 0
test_bits = np.zeros(0, dtype=np.uint8)
for n in range(1, n_segs + 2):
    test_bits = np.zeros(n * 8, dtype=np.uint8)
    res = spread_encode("input/audio_original.wav",
                        test_bits, "/tmp/test_cap.wav")
    if res.get("error"): break
    sp_actual = n
    if n % 10 == 0: print(f"    Spread : {n} ky tu OK...", end="\r")

print(f"  [+] Spread thuc te  : {sp_actual} ky tu" + " "*20)
print()

# Bang tong hop
print(f"  {'':14} {'Ly thuyet':>12} {'Thuc te':>10} {'Ti le tang':>12}")
print("  " + "-"*52)
print(f"  {'S0-only':<14} {s0_theory:>12} {s0_actual:>10}")
print(f"  {'Spread':<14} {sp_theory:>12} {sp_actual:>10} {sp_actual/max(s0_actual,1):>10.1f}x")
print()
ratio = sp_actual / max(s0_actual, 1)
if ratio >= 1.0:
    print(f"  [i] Spread chua duoc {ratio:.1f}x nhieu ky tu hon S0-only")
    print(f"      Vi Spread tan dung tat ca {n_segs} segment (moi segment = 1 byte)")
else:
    print(f"  [i] Spread chua duoc IT HON S0-only ({sp_actual} < {s0_actual} ky tu)")
    print(f"      Ly do: S0-only nhung {bits_per_seg} BIT vao 1 segment ({bits_per_seg//8} byte/segment)")
    print(f"             Spread nhung 8 BIT vao moi segment (1 byte/segment)")
    print(f"             Audio ngan ({n_segs} segment) nen Spread bi gioi han boi so segment")
    print(f"      => Audio dai hon => Spread dat uu the lon hon!")

# Ghi ket qua
with open("results/spread_capacity.txt", "w") as f:
    f.write(f"n_segments:{n_segs}\n")
    f.write(f"audio_duration_sec:{len(data)/fs:.1f}\n")
    f.write(f"s0only_max_chars:{s0_actual}\n")
    f.write(f"spread_max_chars:{sp_actual}\n")
    f.write(f"ratio:{sp_actual/max(s0_actual,1):.1f}\n")

print(f"\n[*] Ghi: results/spread_capacity.txt")
print("[*] Hay chay lenh 'checkwork' de kiem tra CW3.\n")
