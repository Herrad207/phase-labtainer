#!/usr/bin/env python3
"""
CW8: Secure Encoder CLI - tich hop Spread + Key-based.
Su dung:
  python3 scripts/secure_encode.py input.wav "message" output.wav --password KEY
  python3 scripts/secure_decode.py stego.wav <num_chars> --password KEY
"""
import numpy as np
import argparse, os, sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from spread_lib import spread_encode, spread_decode

def secure_encode(input_wav, message, output_wav, password):
    """Encode voi Spread + Key-based segment selection."""
    bits = np.unpackbits(np.frombuffer(message.encode(), dtype=np.uint8))
    res = spread_encode(input_wav, bits, output_wav, password=password)
    if res.get("error"):
        return False, f"Loi: {res['error']}"
    return True, f"Da luu: {output_wav} (spread+key, {res['n_segs_used']} seg)"

def secure_decode(stego_wav, num_chars, password):
    """Decode voi key."""
    n_bits = num_chars * 8
    dec = spread_decode(stego_wav, n_bits, password=password)
    if dec.get("error"):
        return "", False, dec["error"]
    match = (dec["decoded"] == "SECRET") if num_chars == 6 else True
    return dec["decoded"], (len(dec["decoded"]) == num_chars), "OK"

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Secure Phase Encoder (Spread + Key)")
    sub = parser.add_subparsers(dest="cmd")

    enc = sub.add_parser("encode")
    enc.add_argument("input");  enc.add_argument("message")
    enc.add_argument("output"); enc.add_argument("--password", default="default")

    dec_p = sub.add_parser("decode")
    dec_p.add_argument("stego"); dec_p.add_argument("num_chars", type=int)
    dec_p.add_argument("--password", default="default")

    args = parser.parse_args()

    if args.cmd == "encode":
        ok, msg = secure_encode(args.input, args.message, args.output, args.password)
        print(f"[{'+'if ok else '-'}] {msg}")
    elif args.cmd == "decode":
        decoded, match, status = secure_decode(args.stego, args.num_chars, args.password)
        print(f"[+] Decoded: '{decoded}' | Status: {status}")
    else:
        parser.print_help()
