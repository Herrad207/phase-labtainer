"""encoder_lib.py — Thu vien ma hoa pha Phase Coding (dung chung Lab 10/11/13)."""
import numpy as np
import scipy.io.wavfile as wavfile

def encode(input_wav, message, seg_len=4096, start_bin=1500):
    fs, data = wavfile.read(input_wav)
    orig_dtype = data.dtype
    if data.ndim > 1: data = data[:, 0]
    data = data.astype(np.float64)
    bits = np.unpackbits(np.frombuffer(message.encode('utf-8'), dtype=np.uint8))
    n_segs = int(np.floor(len(data) / seg_len))
    if n_segs == 0: return {"error": "Audio too short", "output": None, "fs": fs, "orig_dtype": orig_dtype}
    segs = data[:n_segs*seg_len].reshape((n_segs, seg_len))
    F = np.fft.fft(segs); M, P = np.abs(F), np.angle(F)
    carrier = 10000000.0
    for i, b in enumerate(bits):
        if i >= seg_len//2 - start_bin: break
        ph = np.pi/2 if b else -np.pi/2
        P[0, start_bin+i] = ph; P[0, seg_len-(start_bin+i)] = -ph
        M[0, start_bin+i] = carrier; M[0, seg_len-(start_bin+i)] = carrier
    out = np.copy(data)
    out[:n_segs*seg_len] = np.fft.ifft(M*np.exp(1j*P)).real.flatten()
    return {"error": None, "output": out, "fs": fs, "orig_dtype": orig_dtype}

def decode(input_wav, num_chars, seg_len=4096, start_bin=1500):
    try:
        fs, data = wavfile.read(input_wav)
        if data.ndim > 1: data = data[:, 0]
        data = data.astype(np.float64)
        n_segs = int(np.floor(len(data) / seg_len))
        if n_segs == 0: return {"error": "Audio too short", "decoded": ""}
        segs = data[:n_segs*seg_len].reshape((n_segs, seg_len))
        P = np.angle(np.fft.fft(segs))
        bits = np.array([1 if P[0, start_bin+i] > 0 else 0 for i in range(num_chars*8)])
        chars = bits.reshape((-1,8)).dot(1<<np.arange(7,-1,-1)).astype(np.uint8)
        return {"error": None, "decoded": ''.join(chr(c) for c in chars if 32<=c<=126)}
    except Exception as e:
        return {"error": str(e), "decoded": ""}

def save_wav(audio_data, fs, filename, dtype):
    import numpy as np
    if dtype == np.int16: audio_data = np.clip(audio_data, -32768, 32767)
    wavfile.write(filename, fs, audio_data.astype(dtype))
