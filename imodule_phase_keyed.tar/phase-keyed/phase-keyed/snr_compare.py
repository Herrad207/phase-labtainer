#!/usr/bin/env python3
"""CW2: So sanh SNR giua S0-only va spread encoding."""
import numpy as np
import csv, os, sys

sys.path.insert(0, '.')
import encoder_lib, spread_lib

os.makedirs("results", exist_ok=True)
os.makedirs("output", exist_ok=True)

message = "SECRET"
print("=" * 60)
print("[*] CW2: SO SANH SNR - S0-ONLY vs SPREAD")
print("=" * 60)

# S0-only
res_s0 = encoder_lib.encode("input/audio_original.wav", message, seg_len=4096, start_bin=1500)
encoder_lib.save_wav(res_s0["output"], res_s0["fs"], "output/stego_s0only.wav", res_s0["orig_dtype"])

# Spread (bits_per_seg=8)
spread_lib.spread_encode("input/audio_original.wav", message, "output/stego_spread_snr.wav", bits_per_seg=8)

snr_s0  = spread_lib.compute_snr("input/audio_original.wav", "output/stego_s0only.wav")
snr_sp  = spread_lib.compute_snr("input/audio_original.wav", "output/stego_spread_snr.wav")
chg_s0  = spread_lib.count_changed_samples("input/audio_original.wav", "output/stego_s0only.wav")
chg_sp  = spread_lib.count_changed_samples("input/audio_original.wav", "output/stego_spread_snr.wav")

print(f"\n  {'Method':<12} {'SNR (dB)':<14} {'Changed samples'}")
print("  " + "-"*42)
print(f"  {'S0-only':<12} {snr_s0:<14.2f} {chg_s0}")
print(f"  {'Spread':<12} {snr_sp:<14.2f} {chg_sp}")

print()
if snr_sp >= snr_s0:
    print("[+] SNR Spread >= S0-only: spread phan tan nang luong tot hon")
else:
    print(f"[~] SNR Spread thap hon S0-only ({snr_sp:.1f} vs {snr_s0:.1f} dB)")
    print("    Vi spread thay doi nhieu segment hon, tong nang luong tang")

with open("results/spread_snr.csv", "w", newline='') as f:
    writer = csv.writer(f)
    writer.writerow(["method", "snr_db", "changed_samples"])
    writer.writerow(["s0only", f"{snr_s0:.4f}", chg_s0])
    writer.writerow(["spread", f"{snr_sp:.4f}", chg_sp])

print(f"\n[*] Ghi: results/spread_snr.csv")
print("[*] Hay chay 'checkwork' de kiem tra CW2.")
