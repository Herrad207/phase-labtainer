"""
spread_lib.py — Thu vien Spread Spectrum + Key-based embedding.
Dung chung boi cac script CW trong Lab 13.
"""
import numpy as np
import scipy.io.wavfile as wavfile
import hashlib

SEG_LEN   = 4096
START_BIN = 1500
CARRIER   = 10000000.0

# ─── Low-level helpers ───────────────────────────────────────────
def _read_wav(path):
    fs, data = wavfile.read(path)
    orig = data.dtype
    if data.ndim > 1: data = data[:, 0]
    return fs, data.astype(np.float64), orig

def _write_wav(path, data, fs, dtype):
    if dtype == np.int16: data = np.clip(data, -32768, 32767)
    wavfile.write(path, fs, data.astype(dtype))

def _get_n_segs(data): return int(np.floor(len(data) / SEG_LEN))

def _fft_segs(data, n):
    segs = data[:n*SEG_LEN].reshape((n, SEG_LEN))
    F = np.fft.fft(segs)
    return np.abs(F), np.angle(F)

def _ifft_reconstruct(data, M, P, n):
    out = np.copy(data)
    segs_new = np.fft.ifft(M * np.exp(1j * P)).real
    out[:n*SEG_LEN] = segs_new.flatten()
    return out

# ─── Key-based permutation ───────────────────────────────────────
def key_to_permutation(password, n_bits, n_bins=None):
    """
    SHA256(password) -> seed -> PRNG -> 2 permutations:
      seg_perm: thu tu segment se dung
      bin_perm: offset bin trong moi segment
    """
    seed_bytes = hashlib.sha256(password.encode()).digest()
    seed = int.from_bytes(seed_bytes[:8], 'big')
    rng = np.random.RandomState(seed % (2**31))

    if n_bins is None: n_bins = SEG_LEN // 2 - START_BIN - 1
    bin_offsets = rng.permutation(n_bins)[:n_bits]
    return bin_offsets

def key_to_seg_order(password, n_segs_available, n_chunks):
    """Chon n_chunks segment theo thu tu xac dinh boi key."""
    seed_bytes = hashlib.sha256((password + "_seg").encode()).digest()
    seed = int.from_bytes(seed_bytes[:8], 'big')
    rng = np.random.RandomState(seed % (2**31))
    seg_indices = rng.choice(n_segs_available, size=n_chunks, replace=False)
    return np.sort(seg_indices)  # sap xep de decoder co the tim lai

# ─── Spread Spectrum Encoding ────────────────────────────────────
def spread_encode(input_wav, bits, output_wav, password=None):
    """
    Phan tan N bit vao nhieu segment.
    Layout: moi segment chua 8 bit (1 byte).
    Neu co password: dung key_to_seg_order chon segment.
    Neu khong: dung S0, S1, S2, ... theo thu tu.

    Args:
        bits: numpy array of bits (uint8)
    Returns:
        dict with keys: error, n_segs_used, segments_used
    """
    fs, data, orig = _read_wav(input_wav)
    n_segs = _get_n_segs(data)
    if n_segs == 0:
        return {"error": "Audio too short"}

    bits = np.array(bits, dtype=np.uint8)
    n_bits = len(bits)
    BITS_PER_SEG = 8
    n_chunks = int(np.ceil(n_bits / BITS_PER_SEG))

    if n_chunks > n_segs:
        return {"error": f"Can {n_chunks} segment nhung chi co {n_segs}"}

    # Chon segment
    if password:
        seg_indices = key_to_seg_order(password, n_segs, n_chunks)
    else:
        seg_indices = np.arange(n_chunks)

    segs = data[:n_segs*SEG_LEN].reshape((n_segs, SEG_LEN)).copy()
    F = np.fft.fft(segs)
    M, P = np.abs(F), np.angle(F)

    for chunk_idx, seg_idx in enumerate(seg_indices):
        chunk_bits = bits[chunk_idx*BITS_PER_SEG : (chunk_idx+1)*BITS_PER_SEG]
        if len(chunk_bits) == 0: break
        # Pad neu chunk cuoi khong du 8 bit
        if len(chunk_bits) < BITS_PER_SEG:
            chunk_bits = np.pad(chunk_bits, (0, BITS_PER_SEG - len(chunk_bits)))
        for i, b in enumerate(chunk_bits):
            bin_idx = START_BIN + i
            if bin_idx >= SEG_LEN // 2: break
            ph = np.pi/2 if b else -np.pi/2
            P[seg_idx, bin_idx] = ph
            P[seg_idx, SEG_LEN - bin_idx] = -ph
            M[seg_idx, bin_idx] = CARRIER
            M[seg_idx, SEG_LEN - bin_idx] = CARRIER

    out = _ifft_reconstruct(data, M, P, n_segs)
    _write_wav(output_wav, out, fs, orig)
    return {"error": None, "n_segs_used": n_chunks, "segments_used": seg_indices.tolist()}

def spread_decode(stego_wav, n_bits, password=None):
    """
    Giai ma spread spectrum.
    Returns: dict with keys: error, bits, decoded (str)
    """
    fs, data, _ = _read_wav(stego_wav)
    n_segs = _get_n_segs(data)
    if n_segs == 0:
        return {"error": "Audio too short", "bits": None, "decoded": ""}

    BITS_PER_SEG = 8
    n_chunks = int(np.ceil(n_bits / BITS_PER_SEG))

    if n_chunks > n_segs:
        return {"error": "Khong du segment", "bits": None, "decoded": ""}

    if password:
        seg_indices = key_to_seg_order(password, n_segs, n_chunks)
    else:
        seg_indices = np.arange(n_chunks)

    segs = data[:n_segs*SEG_LEN].reshape((n_segs, SEG_LEN))
    P = np.angle(np.fft.fft(segs))

    bits = []
    for seg_idx in seg_indices:
        for i in range(BITS_PER_SEG):
            bin_idx = START_BIN + i
            if bin_idx >= SEG_LEN // 2: break
            bits.append(1 if P[seg_idx, bin_idx] > 0 else 0)

    bits = np.array(bits[:n_bits], dtype=np.uint8)
    # Pad neu can
    if len(bits) < n_bits:
        bits = np.pad(bits, (0, n_bits - len(bits)))

    chars = bits.reshape((-1,8)).dot(1<<np.arange(7,-1,-1)).astype(np.uint8)
    decoded = ''.join(chr(c) for c in chars if 32<=c<=126)
    return {"error": None, "bits": bits, "decoded": decoded}

# ─── Interleaving ────────────────────────────────────────────────
def interleave_encode(input_wav, bits, output_wav):
    """
    Xen ke: moi segment chua DUNG 1 bit (bit i -> segment i).
    Khac voi spread: spread chua 8 bit/segment.
    """
    fs, data, orig = _read_wav(input_wav)
    n_segs = _get_n_segs(data)
    bits = np.array(bits, dtype=np.uint8)
    n_bits = len(bits)

    if n_bits > n_segs:
        return {"error": f"Can {n_bits} segment nhung chi co {n_segs}"}

    segs = data[:n_segs*SEG_LEN].reshape((n_segs, SEG_LEN)).copy()
    F = np.fft.fft(segs); M, P = np.abs(F), np.angle(F)

    for i, b in enumerate(bits):
        ph = np.pi/2 if b else -np.pi/2
        P[i, START_BIN] = ph;  P[i, SEG_LEN - START_BIN] = -ph
        M[i, START_BIN] = CARRIER; M[i, SEG_LEN - START_BIN] = CARRIER

    out = _ifft_reconstruct(data, M, P, n_segs)
    _write_wav(output_wav, out, fs, orig)
    return {"error": None, "n_segs_used": n_bits}

def interleave_decode(stego_wav, n_bits):
    fs, data, _ = _read_wav(stego_wav)
    n_segs = _get_n_segs(data)
    segs = data[:n_segs*SEG_LEN].reshape((n_segs, SEG_LEN))
    P = np.angle(np.fft.fft(segs))
    bits = np.array([1 if P[i, START_BIN] > 0 else 0
                     for i in range(min(n_bits, n_segs))], dtype=np.uint8)
    if len(bits) < n_bits:
        bits = np.pad(bits, (0, n_bits - len(bits)))
    chars = bits.reshape((-1,8)).dot(1<<np.arange(7,-1,-1)).astype(np.uint8)
    decoded = ''.join(chr(c) for c in chars if 32<=c<=126)
    return {"bits": bits, "decoded": decoded}

# ─── SNR utility ─────────────────────────────────────────────────
def compute_snr(original_wav, stego_wav):
    _, orig, _ = _read_wav(original_wav)
    _, stego, _ = _read_wav(stego_wav)
    n = min(len(orig), len(stego))
    noise = stego[:n] - orig[:n]
    signal_power = np.mean(orig[:n]**2)
    noise_power  = np.mean(noise**2)
    if noise_power == 0: return float('inf'), 0
    snr_db = 10 * np.log10(signal_power / noise_power)
    changed = np.sum(np.abs(noise) > 0.5)
    return snr_db, changed
