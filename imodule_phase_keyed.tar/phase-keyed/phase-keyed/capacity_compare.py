#!/usr/bin/env python3
"""CW3: So sanh dung luong S0-only vs spread."""
import numpy as np
import scipy.io.wavfile as wavfile
import os, sys

sys.path.insert(0, '.')
import encoder_lib, spread_lib

os.makedirs("results", exist_ok=True)

SEG_LEN = 4096; START_BIN = 1500
_, data = wavfile.read("input/audio_original.wav")
n_segs = int(np.floor(len(data) / SEG_LEN))
bits_per_seg_avail = SEG_LEN // 2 - START_BIN - 1

print("=" * 60)
print("[*] CW3: SO SANH DUNG LUONG S0-ONLY vs SPREAD")
print("=" * 60)
print(f"[-] File: {n_segs} segment, {bits_per_seg_avail} bit kha dung/segment")

# Ly thuyet
s0_theory   = bits_per_seg_avail // 8
spr_theory  = n_segs * bits_per_seg_avail // 8
print(f"\n  S0-only  (ly thuyet): {bits_per_seg_avail} bit = {s0_theory} ky tu")
print(f"  Spread   (ly thuyet): {n_segs} x {bits_per_seg_avail} = {n_segs * bits_per_seg_avail} bit = {spr_theory} ky tu")

# Thuc te: encode tang dan den khi loi
print("\n  [*] Do luong thuc te (encode tang dan)...")

def find_max(encode_fn, decode_fn):
    lo, hi = 1, 300
    last_ok = 0
    while lo <= hi:
        mid = (lo + hi) // 2
        msg = "A" * mid
        r = encode_fn("input/audio_original.wav", msg, "/tmp/cap_test.wav")
        if r.get("error"):
            hi = mid - 1; continue
        d = decode_fn("/tmp/cap_test.wav", mid)
        if d.get("decoded","") == msg:
            last_ok = mid; lo = mid + 1
        else:
            hi = mid - 1
    return last_ok

s0_actual  = find_max(
    lambda i,m,o: encoder_lib.encode(i, m, seg_len=SEG_LEN, start_bin=START_BIN),
    lambda w,n:   encoder_lib.decode(w, n, seg_len=SEG_LEN, start_bin=START_BIN)
)
spr_actual = find_max(
    lambda i,m,o: spread_lib.spread_encode(i, m, o, bits_per_seg=8),
    lambda w,n:   spread_lib.spread_decode(w, n, bits_per_seg=8)
)

print(f"\n  S0-only  (thuc te): {s0_actual} ky tu")
print(f"  Spread   (thuc te): {spr_actual} ky tu")
print(f"  Tang gap: {spr_actual/max(s0_actual,1):.1f}x")

with open("results/spread_capacity.txt", "w") as f:
    f.write(f"n_segments:{n_segs}\n")
    f.write(f"bits_per_seg_available:{bits_per_seg_avail}\n")
    f.write(f"s0only_theory_chars:{s0_theory}\n")
    f.write(f"spread_theory_chars:{spr_theory}\n")
    f.write(f"s0only_max_chars:{s0_actual}\n")
    f.write(f"spread_max_chars:{spr_actual}\n")
    f.write(f"capacity_multiplier:{spr_actual/max(s0_actual,1):.2f}\n")

print(f"\n[*] Ghi: results/spread_capacity.txt")
print("[*] Hay chay 'checkwork' de kiem tra CW3.")
