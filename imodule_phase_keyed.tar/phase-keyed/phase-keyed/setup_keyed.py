#!/usr/bin/env python3
"""Tao file am thanh khoi tao cho Lab 13. Chi tao input/, KHONG tao results/output/."""
import numpy as np
import scipy.io.wavfile as wavfile
import sys, os

sys.path.insert(0, '.')
from encoder_lib import encode, save_wav, decode

os.makedirs("input", exist_ok=True)

sr = 44100
t = np.arange(sr * 5) / sr

try:
    amp1 = PARAM_AMP_1
    amp2 = PARAM_AMP_2
except NameError:
    amp1 = 8000
    amp2 = 4000

music = (amp1 * np.sin(2*np.pi*440*t) +
         amp2 * np.sin(2*np.pi*880*t) +
         500 * np.random.randn(len(t)))

audio = np.clip(music, -32768, 32767).astype(np.int16)
wavfile.write("input/audio_original.wav", sr, audio)

# Tao stego chuan bang S0-only (de so sanh voi spread)
res = encode("input/audio_original.wav", "SECRET", seg_len=4096, start_bin=1500)
if res["error"] is None:
    save_wav(res["output"], res["fs"], "input/stego_s0only.wav", res["orig_dtype"])

dec = decode("input/stego_s0only.wav", 6, seg_len=4096, start_bin=1500)
if dec["error"] is None:
    with open("input/verify.txt", "w") as f:
        f.write(f"decoded:{dec['decoded']}\nmatch:{dec['decoded']=='SECRET'}\n")
    print(f"[+] S0-only stego: '{dec['decoded']}' - Khop: {dec['decoded']=='SECRET'}")

print("[+] San sang cho Lab 13!")
