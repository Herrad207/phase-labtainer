#!/bin/bash
cd $HOME

# Tao session token moi (chong gian lan bang results cu)
python3 -c "import uuid; print(str(uuid.uuid4())[:8])" > .lab_token
TOKEN=$(cat .lab_token)
echo "[+] Session token: $TOKEN"

# Xoa results cu
rm -rf results/ output/
mkdir -p results output

# Tao file am thanh khoi tao
python3 setup_keyed.py

rm -f setup_keyed.py
