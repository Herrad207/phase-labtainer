#!/usr/bin/env python3
"""CW8: Test E2E Secure Encoder CLI."""
import os, sys

sys.path.insert(0, '.')
sys.path.insert(0, 'scripts')

from scripts.secure_encode import secure_encode, secure_decode

os.makedirs("results", exist_ok=True)
os.makedirs("output", exist_ok=True)

message = "SECRET"
correct_pw = "lab13test"
wrong_pw   = "badpassword"
input_wav  = "input/audio_original.wav"
stego_wav  = "output/stego_secure.wav"

print("="*60)
print("[*] CW8: KIEM TRA E2E SECURE ENCODER (SPREAD + KEY)")
print("="*60)

# Encode
ok_enc, msg_enc = secure_encode(input_wav, message, stego_wav, correct_pw)
print(f"[{'+'if ok_enc else '-'}] Encode: {msg_enc}")
if not ok_enc: sys.exit(1)

# Decode dung key
dec_c, match_c, status_c = secure_decode(stego_wav, len(message), correct_pw)
print(f"[+] Decode (DUNG key '{correct_pw}'): '{dec_c}' | Khop: {match_c}")

# Decode sai key
dec_w, match_w, status_w = secure_decode(stego_wav, len(message), wrong_pw)
print(f"[+] Decode (SAI  key '{wrong_pw}'): '{dec_w}' | Khop: {match_w}")

both_ok = match_c and not match_w
print(f"\n[+] Ca hai dieu kien dat: {both_ok}")

with open("results/secure_e2e.txt", "w") as f:
    f.write(f"message:{message}\n")
    f.write(f"correct_decoded:{dec_c}\n")
    f.write(f"correct_match:{match_c}\n")
    f.write(f"wrong_decoded:{dec_w}\n")
    f.write(f"wrong_match:{match_w}\n")

print(f"\n[*] Ghi: results/secure_e2e.txt")
print("[*] Hay chay 'checkwork' de kiem tra CW8.")
