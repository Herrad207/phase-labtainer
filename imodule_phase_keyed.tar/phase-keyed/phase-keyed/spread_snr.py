#!/usr/bin/env python3
"""
CW2: So sanh SNR - S0-only vs Spread Spectrum.

SNR (Signal-to-Noise Ratio): do bien doi am thanh.
SNR cao hon = it bien doi = kho phat hien hon ve mat ky thuat.
"""
import numpy as np
import csv, os, sys

sys.path.insert(0, '.')
from encoder_lib import encode, save_wav
from spread_lib import spread_encode, compute_snr

os.makedirs("results", exist_ok=True)
os.makedirs("output", exist_ok=True)

message = "SECRET"
bits = np.unpackbits(np.frombuffer(message.encode(), dtype=np.uint8))

print("\n" + "="*65)
print("[*] CW2: SO SANH SNR - S0-ONLY vs SPREAD")
print("="*65)
print("[-] SNR (dB) = 10 * log10(nang_luong_tin / nang_luong_nhieu)")
print("[-] SNR cao hon  => bien doi am thanh it hon => kho phat hien hon")
print("[-] Mau thay doi => so sample bi anh huong boi ma hoa")
print("="*65 + "\n")

# S0-only
print("[*] Dang tinh S0-only...")
res_s0 = encode("input/audio_original.wav", message, seg_len=4096, start_bin=1500)
save_wav(res_s0["output"], res_s0["fs"],
         "output/stego_s0_snr.wav", res_s0["orig_dtype"])
snr_s0, changed_s0 = compute_snr("input/audio_original.wav",
                                   "output/stego_s0_snr.wav")

# Spread
print("[*] Dang tinh Spread...")
spread_encode("input/audio_original.wav", bits, "output/stego_spread_snr.wav")
snr_sp, changed_sp = compute_snr("input/audio_original.wav",
                                   "output/stego_spread_snr.wav")

# In bang
print()
print(f"  {'Phuong phap':<14} {'SNR (dB)':>10} {'Mau thay doi':>14} {'Nhan xet'}")
print("  " + "-"*62)
winner_snr = "S0-only" if snr_s0 >= snr_sp else "Spread"
print(f"  {'S0-only':<14} {snr_s0:>10.2f} {changed_s0:>14,}  {'<-- SNR tot hon' if winner_snr=='S0-only' else ''}")
print(f"  {'Spread':<14} {snr_sp:>10.2f} {changed_sp:>14,}  {'<-- SNR tot hon' if winner_snr=='Spread' else ''}")
print()
print(f"  [i] {winner_snr} co SNR cao hon ({abs(snr_s0-snr_sp):.2f} dB chenh lech)")

if winner_snr == "S0-only":
    print(f"  [i] Ly do: S0-only bien doi 1 segment ({changed_s0:,} mau)")
    print(f"             Spread bien doi {changed_sp//changed_s0 if changed_s0 > 0 else '?'}x nhieu mau hon ({changed_sp:,} mau)")
    print(f"             Nhieu nang luong hon phan tan => SNR giam")
else:
    print(f"  [i] Ly do: Spread phan tan bien doi mong hon tren moi segment")
    print(f"             Moi segment it bi anh huong hon => SNR tot hon")

# Ghi ket qua
with open("results/spread_snr.csv", "w", newline='') as f:
    writer = csv.writer(f)
    writer.writerow(["method", "snr_db", "changed_samples"])
    writer.writerow(["s0only", f"{snr_s0:.2f}", changed_s0])
    writer.writerow(["spread", f"{snr_sp:.2f}", changed_sp])

print(f"\n[*] Ghi: results/spread_snr.csv")
print("[*] Hay chay lenh 'checkwork' de kiem tra CW2.\n")
