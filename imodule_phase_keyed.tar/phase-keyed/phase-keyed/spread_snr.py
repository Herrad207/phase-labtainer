#!/usr/bin/env python3
"""CW2: So sanh SNR giua S0-only va Spread Spectrum."""
import numpy as np
import scipy.io.wavfile as wavfile
import csv, os, sys

sys.path.insert(0, '.')
from encoder_lib import encode, save_wav
from spread_lib import spread_encode, compute_snr

os.makedirs("results", exist_ok=True)
os.makedirs("output", exist_ok=True)

message = "SECRET"
bits = np.unpackbits(np.frombuffer(message.encode(), dtype=np.uint8))

print("="*65)
print("[*] CW2: SO SANH SNR - S0-ONLY vs SPREAD SPECTRUM")
print("="*65)
print("SNR (Signal-to-Noise Ratio): do do bien doi am thanh.")
print("SNR cao hon = bien doi it hon = stego kho phat hien hon.")
print()

# S0-only
res_s0 = encode("input/audio_original.wav", message, seg_len=4096, start_bin=1500)
save_wav(res_s0["output"], res_s0["fs"], "output/stego_s0_cw2.wav", res_s0["orig_dtype"])
snr_s0, changed_s0 = compute_snr("input/audio_original.wav", "output/stego_s0_cw2.wav")

# Spread
spread_encode("input/audio_original.wav", bits, "output/stego_spread_cw2.wav")
snr_sp, changed_sp = compute_snr("input/audio_original.wav", "output/stego_spread_cw2.wav")

print(f"  S0-only : SNR = {snr_s0:.2f} dB | Mau thay doi = {changed_s0}")
print(f"  Spread  : SNR = {snr_sp:.2f} dB | Mau thay doi = {changed_sp}")
print()

# Cau hoi phan tich
print("-"*65)
print("PHAN TICH: Phuong phap nao co SNR cao hon? Tai sao?")
print("  A. S0-only cao hon vi tap trung bien doi vao 1 segment -> nang luong khu tru nho")
print("  B. Spread cao hon vi phan tan bien doi ra nhieu segment -> moi segment it bi anh huong hon")
print("  C. Tuong duong nhau")
print("  D. Khong xac dinh duoc")
print()
ans = input("[?] Chon dap an (A/B/C/D): ").strip().upper()

# Ca hai deu dung CUNG carrier_mag=10^7 nen SNR tuong tu
# Nhung spread doi nhieu segment hon -> changed_samples lon hon
actual_better = "S0-only" if snr_s0 >= snr_sp else "Spread"
ok = (ans == 'A' and snr_s0 >= snr_sp) or (ans == 'B' and snr_sp > snr_s0)

if ok:
    print(f"    [+] DUNG! {actual_better} co SNR cao hon ({max(snr_s0,snr_sp):.2f} vs {min(snr_s0,snr_sp):.2f} dB)")
else:
    print(f"    [-] Chua chinh xac. Thuc te: {actual_better} co SNR cao hon.")
    if snr_s0 >= snr_sp:
        print("        S0-only chi bien doi 1 segment -> it mau thay doi -> SNR tot hon.")
        print("        Spread phan tan ra nhieu segment -> nhieu mau thay doi -> SNR thap hon.")
    else:
        print("        Spread phan tan bien doi mong hon tren moi segment -> SNR tot hon.")
print()

with open("results/spread_snr.csv", "w", newline='') as f:
    writer = csv.writer(f)
    writer.writerow(["method", "snr", "changed_samples"])
    writer.writerow(["s0only", f"{snr_s0:.2f}", changed_s0])
    writer.writerow(["spread", f"{snr_sp:.2f}", changed_sp])

with open("results/spread_snr_analysis.txt", "w") as f:
    f.write(f"s0only_snr:{snr_s0:.2f}\n")
    f.write(f"spread_snr:{snr_sp:.2f}\n")
    f.write(f"answer:{ans}\n")
    f.write(f"analysis_ok:{ok}\n")

print(f"[*] Ghi: results/spread_snr.csv")
print("[*] Hay chay 'checkwork' de kiem tra CW2.")
