#!/usr/bin/env python3
"""
CW5: So sanh Interleaving (1 bit/segment) vs Spread (8 bit/segment).

Interleave: moi segment chua dung 1 bit => can 48 segment cho 'SECRET'.
Spread    : moi segment chua 8 bit (1 byte) => can 6 segment.
Nhieu segment hon => kho bi mat het khi crop.
"""
import numpy as np
import scipy.io.wavfile as wavfile
import csv, os, sys

sys.path.insert(0, '.')
from spread_lib import (spread_encode, spread_decode,
                        interleave_encode, interleave_decode,
                        compute_snr, _read_wav)

os.makedirs("results", exist_ok=True)
os.makedirs("output", exist_ok=True)

message = "SECRET"
bits    = np.unpackbits(np.frombuffer(message.encode(), dtype=np.uint8))

print("\n" + "="*65)
print("[*] CW5: INTERLEAVING vs SPREAD SPECTRUM")
print("="*65)
print(f"[-] Spread    : 8 bit vao 1 segment => can {len(bits)//8} segment")
print(f"[-] Interleave: 1 bit vao 1 segment => can {len(bits)} segment")
print()

# Encode
print("[*] Dang encode...")
r_sp = spread_encode(    "input/audio_original.wav", bits,
                         "output/stego_spread_cw5.wav")
r_il = interleave_encode("input/audio_original.wav", bits,
                         "output/stego_interleave.wav")

if r_sp.get("error") or r_il.get("error"):
    err = r_sp.get("error") or r_il.get("error")
    print(f"[-] Loi: {err}"); sys.exit(1)

# SNR
snr_sp, ch_sp = compute_snr("input/audio_original.wav", "output/stego_spread_cw5.wav")
snr_il, ch_il = compute_snr("input/audio_original.wav", "output/stego_interleave.wav")

# Decode binh thuong
dec_sp = spread_decode    ("output/stego_spread_cw5.wav", len(bits))
dec_il = interleave_decode("output/stego_interleave.wav", len(bits))
sp_ok  = (dec_sp["decoded"] == message)
il_ok  = (dec_il["decoded"] == message)

# Test crop = 4096 (cat S0)
_, d_sp, _ = _read_wav("output/stego_spread_cw5.wav")
_, d_il, _ = _read_wav("output/stego_interleave.wav")
import scipy.io.wavfile as wv
sr = 44100

wv.write("output/tmp_sp_il_crop.wav", sr, d_sp[4096:])
wv.write("output/tmp_il_il_crop.wav", sr, d_il[4096:])
dec_sp_c = spread_decode    ("output/tmp_sp_il_crop.wav", len(bits))
dec_il_c = interleave_decode("output/tmp_il_il_crop.wav", len(bits))
sp_crop  = (dec_sp_c["decoded"] == message)
il_crop  = (dec_il_c["decoded"] == message)

# Tinh nguong crop thuc te:
# Spread: dung 6 segment => cat 6*4096 = 24576 het Spread
# Interleave: dung 48 segment => cat 48*4096 = 196608 moi het Interleave
# Audio 5 giay = 220500 mau => 220500-196608 = 23892 mau con lai (van du)
crop_spread_max = r_sp['n_segs_used'] * 4096   # 6 * 4096 = 24576
crop_il_max     = r_il['n_segs_used'] * 4096   # 48 * 4096 = 196608

# Test crop spread_max (het spread, il chua het)
if crop_spread_max <= len(d_sp):
    wv.write("output/tmp_sp_bigcrop.wav", sr, d_sp[crop_spread_max:])
    wv.write("output/tmp_il_bigcrop.wav", sr, d_il[crop_spread_max:])
    dec_sp_b = spread_decode    ("output/tmp_sp_bigcrop.wav", len(bits))
    dec_il_b = interleave_decode("output/tmp_il_bigcrop.wav", len(bits))
    sp_bigcrop = (dec_sp_b["decoded"] == message)
    il_bigcrop = (dec_il_b["decoded"] == message)
    crop_label = f"Crop {crop_spread_max}"
else:
    sp_bigcrop = False; il_bigcrop = False
    crop_label = f"Crop {crop_spread_max}"

# In bang
print()
print(f"  {'':14} {'Decode':<8} {'Crop 4096':<11} {crop_label:<14} "
      f"{'SNR':>8} {'Segment dung':>14}")
print("  " + "-"*74)
print(f"  {'Spread':<14} {str(sp_ok):<8} {str(sp_crop):<11} {str(sp_bigcrop):<14} "
      f"{snr_sp:>7.2f}dB {r_sp['n_segs_used']:>14}")
print(f"  {'Interleave':<14} {str(il_ok):<8} {str(il_crop):<11} {str(il_bigcrop):<14} "
      f"{snr_il:>7.2f}dB {r_il['n_segs_used']:>14}")
print()
print(f"  [i] Spread dung {r_sp['n_segs_used']} segment => can cat >= {crop_spread_max:,} mau de mat het")
print(f"  [i] Interleave dung {r_il['n_segs_used']} segment => can cat >= {crop_il_max:,} mau de mat het")
if il_bigcrop and not sp_bigcrop:
    print(f"  [i] Tai crop={crop_spread_max}: Interleave con song, Spread da guc!")
    print(f"      => Interleave chiu duoc crop lon hon nho dung nhieu segment hon.")
elif not il_bigcrop and not sp_bigcrop:
    print(f"  [i] Tai crop={crop_spread_max}: ca hai deu guc (lech khung FFT).")
    print(f"      Interleave giai phap ly tuong can THEM Sync Marker (Lab 11).")
    print(f"      Ly thuyet: Interleave can cat {crop_il_max:,} mau (= {r_il['n_segs_used']} segment) moi mat het.")

# Ghi ket qua
with open("results/interleave_test.csv", "w", newline='') as f:
    writer = csv.writer(f)
    writer.writerow(["method", "decode_ok", "crop_4096_ok",
                     f"crop_{crop_spread_max}_ok", "snr_db", "segs_used"])
    writer.writerow(["spread",     sp_ok, sp_crop, sp_bigcrop,
                     f"{snr_sp:.2f}", r_sp['n_segs_used']])
    writer.writerow(["interleave", il_ok, il_crop, il_bigcrop,
                     f"{snr_il:.2f}", r_il['n_segs_used']])

print(f"\n[*] Ghi: results/interleave_test.csv")
print("[*] Hay chay lenh 'checkwork' de kiem tra CW5.\n")
