#!/usr/bin/env python3
"""
CW5: So sanh Interleaving (1 bit/segment) vs Spread (8 bit/segment).

Interleave: moi segment chua dung 1 bit => can 48 segment cho 'SECRET'.
Spread    : moi segment chua 8 bit (1 byte) => can 6 segment.
Nhieu segment hon => kho bi mat het khi crop.
"""
import numpy as np
import scipy.io.wavfile as wavfile
import csv, os, sys

sys.path.insert(0, '.')
from spread_lib import (spread_encode, spread_decode,
                        interleave_encode, interleave_decode,
                        compute_snr, _read_wav)

os.makedirs("results", exist_ok=True)
os.makedirs("output", exist_ok=True)

message = "SECRET"
bits    = np.unpackbits(np.frombuffer(message.encode(), dtype=np.uint8))

print("\n" + "="*65)
print("[*] CW5: INTERLEAVING vs SPREAD SPECTRUM")
print("="*65)
print(f"[-] Spread    : 8 bit vao 1 segment => can {len(bits)//8} segment")
print(f"[-] Interleave: 1 bit vao 1 segment => can {len(bits)} segment")
print()

# Encode
print("[*] Dang encode...")
r_sp = spread_encode(    "input/audio_original.wav", bits,
                         "output/stego_spread_cw5.wav")
r_il = interleave_encode("input/audio_original.wav", bits,
                         "output/stego_interleave.wav")

if r_sp.get("error") or r_il.get("error"):
    err = r_sp.get("error") or r_il.get("error")
    print(f"[-] Loi: {err}"); sys.exit(1)

# SNR
snr_sp, ch_sp = compute_snr("input/audio_original.wav", "output/stego_spread_cw5.wav")
snr_il, ch_il = compute_snr("input/audio_original.wav", "output/stego_interleave.wav")

# Decode binh thuong
dec_sp = spread_decode    ("output/stego_spread_cw5.wav", len(bits))
dec_il = interleave_decode("output/stego_interleave.wav", len(bits))
sp_ok  = (dec_sp["decoded"] == message)
il_ok  = (dec_il["decoded"] == message)

# Test crop = 4096 (cat S0)
_, d_sp, _ = _read_wav("output/stego_spread_cw5.wav")
_, d_il, _ = _read_wav("output/stego_interleave.wav")
import scipy.io.wavfile as wv
sr = 44100

wv.write("output/tmp_sp_il_crop.wav", sr, d_sp[4096:])
wv.write("output/tmp_il_il_crop.wav", sr, d_il[4096:])
dec_sp_c = spread_decode    ("output/tmp_sp_il_crop.wav", len(bits))
dec_il_c = interleave_decode("output/tmp_il_il_crop.wav", len(bits))
sp_crop  = (dec_sp_c["decoded"] == message)
il_crop  = (dec_il_c["decoded"] == message)

# Test crop = 4096 * 6 = 24576 (cat het 6 segment Spread)
wv.write("output/tmp_sp_bigcrop.wav", sr, d_sp[24576:])
wv.write("output/tmp_il_bigcrop.wav", sr, d_il[24576:])
dec_sp_b = spread_decode    ("output/tmp_sp_bigcrop.wav", len(bits))
dec_il_b = interleave_decode("output/tmp_il_bigcrop.wav", len(bits))
sp_bigcrop = (dec_sp_b["decoded"] == message)
il_bigcrop = (dec_il_b["decoded"] == message)

# In bang
print()
print(f"  {'':14} {'Decode':<8} {'Crop 4096':<11} {'Crop 24576':<12} "
      f"{'SNR':>8} {'Segment dung':>14}")
print("  " + "-"*72)
print(f"  {'Spread':<14} {str(sp_ok):<8} {str(sp_crop):<11} {str(sp_bigcrop):<12} "
      f"{snr_sp:>7.2f}dB {r_sp['n_segs_used']:>14}")
print(f"  {'Interleave':<14} {str(il_ok):<8} {str(il_crop):<11} {str(il_bigcrop):<12} "
      f"{snr_il:>7.2f}dB {r_il['n_segs_used']:>14}")
print()
print(f"  [i] Spread dung {r_sp['n_segs_used']} segment => mat khi crop >= {r_sp['n_segs_used']*4096:,} mau")
print(f"  [i] Interleave dung {r_il['n_segs_used']} segment => mat khi crop >= {r_il['n_segs_used']*4096:,} mau")
if il_ok and not sp_bigcrop:
    print(f"  [i] Interleave van song sot crop 24576 ma Spread da guc!")

# Ghi ket qua
with open("results/interleave_test.csv", "w", newline='') as f:
    writer = csv.writer(f)
    writer.writerow(["method", "decode_ok", "crop_4096_ok",
                     "crop_24576_ok", "snr_db", "segs_used"])
    writer.writerow(["spread",     sp_ok, sp_crop, sp_bigcrop,
                     f"{snr_sp:.2f}", r_sp['n_segs_used']])
    writer.writerow(["interleave", il_ok, il_crop, il_bigcrop,
                     f"{snr_il:.2f}", r_il['n_segs_used']])

print(f"\n[*] Ghi: results/interleave_test.csv")
print("[*] Hay chay lenh 'checkwork' de kiem tra CW5.\n")
