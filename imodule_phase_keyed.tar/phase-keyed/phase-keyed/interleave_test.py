#!/usr/bin/env python3
"""CW5: So sanh Interleaving (1 bit/segment) vs Spread (8 bit/segment)."""
import numpy as np
import scipy.io.wavfile as wavfile
import csv, os, sys

sys.path.insert(0, '.')
from spread_lib import (spread_encode, spread_decode,
                        interleave_encode, interleave_decode,
                        compute_snr, _read_wav)

os.makedirs("results", exist_ok=True)
os.makedirs("output", exist_ok=True)

message = "SECRET"
bits = np.unpackbits(np.frombuffer(message.encode(), dtype=np.uint8))
n_bits = len(bits)

print("="*65)
print("[*] CW5: INTERLEAVING vs SPREAD SPECTRUM")
print("="*65)
print(f"Spread    : 8 bit vao 1 segment => can {n_bits//8} segment")
print(f"Interleave: 1 bit vao 1 segment => can {n_bits} segment")
print()

# Cau hoi tinh toan truoc
print("-"*65)
print("BAI 1: So segment can thiet")
print(f"'SECRET' = 48 bit.")
print(f"Interleave: moi segment chua bao nhieu bit? => can bao nhieu segment?")
print()
try:
    ans1 = int(input("[?] So segment Interleave can: ").strip())
    ok1 = (ans1 == n_bits)
except: ok1 = False
print(f"    [{'+'if ok1 else '-'}] {'DUNG' if ok1 else f'Chua dung. Can {n_bits} segment (1 bit/seg)'}")
print()

# Encode ca 2
r_sp = spread_encode("input/audio_original.wav", bits, "output/stego_spread_cw5.wav")
r_il = interleave_encode("input/audio_original.wav", bits, "output/stego_interleave.wav")

if r_sp.get("error") or r_il.get("error"):
    print(f"[-] Loi: {r_sp.get('error') or r_il.get('error')}"); sys.exit(1)

# SNR
snr_sp, ch_sp = compute_snr("input/audio_original.wav", "output/stego_spread_cw5.wav")
snr_il, ch_il = compute_snr("input/audio_original.wav", "output/stego_interleave.wav")

# Decode binh thuong
dec_sp = spread_decode("output/stego_spread_cw5.wav", n_bits)
dec_il = interleave_decode("output/stego_interleave.wav", n_bits)
sp_ok = (dec_sp["decoded"] == message)
il_ok = (dec_il["decoded"] == message)

# Test crop = 4096 (cat S0)
fs, data_sp, _ = _read_wav("output/stego_spread_cw5.wav")
fs, data_il, _ = _read_wav("output/stego_interleave.wav")

import scipy.io.wavfile as wavfile
wavfile.write("output/tmp_sp_crop.wav", fs, data_sp[4096:])
wavfile.write("output/tmp_il_crop.wav", fs, data_il[4096:])

dec_sp_crop = spread_decode("output/tmp_sp_crop.wav", n_bits)
dec_il_crop = interleave_decode("output/tmp_il_crop.wav", n_bits)
sp_crop_ok = (dec_sp_crop["decoded"] == message)
il_crop_ok = (dec_il_crop["decoded"] == message)

print(f"  {'Method':<12} {'Decode OK':<12} {'Crop 4096':<12} {'SNR':>10} {'Seg dung':>10}")
print("  " + "-"*60)
print(f"  {'Spread':<12} {str(sp_ok):<12} {str(sp_crop_ok):<12} {snr_sp:>9.2f}dB {r_sp['n_segs_used']:>10}")
print(f"  {'Interleave':<12} {str(il_ok):<12} {str(il_crop_ok):<12} {snr_il:>9.2f}dB {r_il['n_segs_used']:>10}")
print()

print("-"*65)
print("PHAN TICH: Uu diem cua Interleave so voi Spread la gi?")
print("  A. Interleave nhanh hon")
print("  B. Interleave dung it segment hon")
print("  C. Interleave tang kha nang chong crop vi phan tan ra nhieu segment hon")
print("  D. Interleave co SNR tot hon")
print()
ans2 = input("[?] Chon dap an (A/B/C/D): ").strip().upper()
ok2 = (ans2 == 'C')
if ok2:
    print("    [+] DUNG! 48 segment (Interleave) phan tan hon 6 segment (Spread)")
    print("        => Phai cat nhieu hon moi mat het tin hieu.")
else:
    print("    [-] Dap an C. Interleave dung nhieu segment hon => kho bi mat het.")
print()

with open("results/interleave_test.csv", "w", newline='') as f:
    writer = csv.writer(f)
    writer.writerow(["method", "decode_ok", "crop_4096_ok", "snr", "segs_used"])
    writer.writerow(["spread", sp_ok, sp_crop_ok, f"{snr_sp:.2f}", r_sp['n_segs_used']])
    writer.writerow(["interleave", il_ok, il_crop_ok, f"{snr_il:.2f}", r_il['n_segs_used']])

with open("results/interleave_analysis.txt", "w") as f:
    f.write(f"analysis_ok:{ok2}\n")
    f.write(f"bai1_ok:{ok1}\n")

print(f"[*] Ghi: results/interleave_test.csv")
print("[*] Hay chay 'checkwork' de kiem tra CW5.")
